# Website feature → API → Flutter status (written from the API docs/code, not from running the app)
| Feature | Endpoint | Status / limitation |
|---|---|---|
| Featured / latest / trending / popular rows | /movies/featured, latest, trending, popular | Implemented. Trending hidden when empty. Section order is fixed in the app (API exposes no ordering). |
| Categories | /categories | Chips on Home; tap opens filtered grid |
| Browse, search, sort, pagination | /movies (q, genre, sort, page) | Implemented (infinite scroll, pull-to-refresh). Filters sheet (language, country, genre, release year) implemented from /languages, /countries, /categories. |
| Search suggestions | /search/suggest | Implemented (debounced) |
| Movie detail (metadata, synopsis, cast, screenshots, trailer, downloads) | /movies/{slug} | Implemented. Trailer opens in YouTube/browser (no in-app player). No backdrop image exists in the API; the poster is used. |
| Related movies | /movies/{slug}/related | Implemented |
| Reviews: read/write/edit/delete/report | /movies/{slug}/reviews, /reviews/{id}, /reviews/{id}/report | Implemented; new reviews may be pending moderation |
| Register / login / logout / logout-all | /auth/* | Implemented |
| Password reset | /auth/password/forgot, reset | Implemented (email must be configured on the server) |
| Profile name, password change | /me, /me/password | Implemented. Email change not exposed in UI. |
| Watchlist, favorites | /me/watchlist, /me/favorites | Implemented. API has no "is in list" flag, so the app loads the id set (up to 500 items) after login. |
| History | /me/recent, POST /movies/{slug}/view | Implemented |
| Recommendations | /me/recommendations | Implemented; hidden when the API returns none |
| Preferences | /me/preferences | Only a notifications flag is exposed (no push is implemented) |
| About / Contact / Privacy / Copyright | – (no API endpoint) | Open the website pages in the browser. In-app rendering needs a pages endpoint. |
| Maintenance, feature flags | /config | Implemented, validated, safe defaults |
| Banners, announcements, theme, section order, nav links | – | **Not available in the API** (see SYNC_AND_RELEASES.md) |
| ETag / Last-Modified | – | API sends `no-store`; not usable |
| Push notifications | – | Not available |
| Player: audio-language and subtitle-language pickers | – (read from tracks inside the downloaded file) | Implemented in code, untested. Lists only embedded tracks; hard-coded subtitles can't be switched; no subtitle endpoint in the API. |
| Android app media: streaming, direct download (private storage), offline playback, resume, retry, locked/unavailable states | /movies/{slug}/app-media, /media/{token} | Implemented in code (website update required), untested. Separate from website download links. |
| Audio/subtitle tracks from admin | same endpoint (`audio[]`, `subtitles[]`) | Implemented; subtitles saved offline with downloads; external audio works online only. |
| Settings: theme (dark/light/system), download location (phone/SD card), Wi-Fi only, subtitle size, clear cache, delete downloads, storage used | – (device settings) | Implemented in code, untested. No free-space readout; no UI-language switch. |
