# What syncs automatically and what needs a new app release
## Syncs without a new APK (after the app refetches: launch, pull-to-refresh, or returning after 5+ min)
Movies added/edited/removed in the website admin; posters, metadata, categories, featured flags, download options; reviews (after moderation); maintenance mode and the feature flags in `/config` (registration, reviews, recommendations, password reset, suggestions); user watchlist/favorites/history/reviews/profile (written to the server first, so the website shows the same data).
Deleted movies: a 404 removes the cached copy and shows "Movie unavailable".
## Needs the backend to add endpoints first (documented gaps; the app has no code for them)
Homepage section order/visibility, banners and promo images, announcements, theme values, navigation links, in-app page content, push notifications, cache validators (ETag/Last-Modified). Until then these are fixed in the app.
## Needs a new app release
New screens/components, new native features or permissions, dependency or Flutter upgrades, layout/design changes, new API versions that break v1, translations. The app never downloads or runs code from the server; configuration is validated and rendered by built-in widgets only.
