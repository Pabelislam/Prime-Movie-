# Android app media: how it fits together
**Website** keeps its movie info and the existing "Download" buttons (external pages/links, `download.php` redirect) exactly as before. **App** uses a separate, optional set of authorised sources per movie, stored in the same database and linked to the same movie ID (no duplicate movies).

## Admin (website): Movies → edit → "Android App Media"
Per version: quality (480p/720p/1080p/4K), format (mp4/mkv/webm/hls/dash), size in bytes (auto-filled for uploaded files), source, switches *Streaming* / *Offline download* / *Login required*, status (active/disabled/unavailable), audio tracks, subtitles. "Available on": website, app, or both (Publish Settings).
- **Source** is either an `https://` URL (your CDN/server) or a file name that you upload by FTP/cPanel to `storage/app_media/` (never public; delivered only through signed API links).
- **Audio lines:** `Bangla | bn | 1` = label, language code, position of that audio track inside the file (1 = first). An external audio file may be given instead of the number. Labels only help if the file really contains those tracks; unmatched entries are not shown in the app.
- **Subtitle lines:** `English | en | vtt | https://.../en.vtt` or a file name in `storage/app_media/`. vtt/srt/ass supported.
- HLS/DASH cannot be switched to offline download (the form rejects it).

## API (needs website update deployed)
`GET /api/v1/movies/{slug}/app-media` → versions with `stream_url`, `download_url`, `audio[]`, `subtitles[]`, `locked`, `status`. `GET /api/v1/media/{token}` delivers the file/track (Range supported). Details in the website's `docs/API.md`.

## What the app does with it
Stream/download buttons per version; Downloads tab; offline playback; audio + subtitle pickers; resume; retry with fresh links; locked/unavailable states shown clearly.

## Limits (honest list)
- Anyone with a valid signed link can fetch the file until it expires (4–6 h); links are bound to the file, not to the device. External URLs cannot be hidden once the app follows the redirect: use private files or your CDN's own signed URLs for restricted content.
- No DRM, no encrypted/offline HLS. Audio switching works only for tracks actually inside the file (or separate audio URLs).
- Changing sources in the admin updates the app after its next refresh, no APK needed. New player features need a new app release.

## Hybrid media update (uploads, cloud storage, inspection)
Admin can now **Upload media** (chunked, resumable; to hosting or S3/R2 directly from the browser) or **Add media URL** (direct file, HLS, DASH, provider reference) and click **Inspect** to read resolution/duration/audio/subtitle tracks (needs ffprobe on the server for files; manifests are parsed without it). Tracks are marked *detected* or *manual*; the app lists only tracks that exist in the chosen version. Setup, CORS, limits and costs: the website's `docs/STORAGE_DEPLOYMENT.md`.
App side: shows resolution/duration/verified badge, the server's reason when a version is unavailable or offline download is not offered (e.g. HLS/DASH/provider sources), maps admin-labelled audio/subtitle entries onto the file's real tracks, checks free phone storage before downloading (SD-card space is not checked), and never offers offline download for streaming-only protocols.
Not implemented: transcoding, offline HLS/DASH, DRM, ExoPlayer/Media3 platform channel (the app uses media_kit/libmpv, which handles HLS/DASH, MKV and multiple tracks; switching engines is a possible later change if device testing shows problems).
