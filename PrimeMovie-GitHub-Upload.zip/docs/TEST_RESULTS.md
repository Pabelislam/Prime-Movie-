# Test results — NOTHING WAS EXECUTED
No Flutter/Dart SDK was available, so `flutter pub get`, `flutter analyze`, `flutter test` and `flutter build apk` were **not run**. No command has passed. Also untested: the app against the real API (which itself was never run, see the website's TEST_REPORT.md).

Only check performed: a bracket-balance script over all .dart files (not a compiler).

Tests written, not run (`test/`): API client (envelope parsing, 429, non-JSON errors, single-flight refresh, rejected refresh sign-out, no Authorization on public calls), models + RemoteConfig validation, repository caching (fresh, offline fallback, 404 not masked, config defaults, pagination), widgets (error/empty/card) and form validators.
Not written: integration tests on a device/emulator, watchlist-sync test against a live server, deep-link test.

Manual procedure once the API is live: 1) health URL opens; 2) register/login on the app, confirm the user appears in website Admin → API; 3) add a movie to the watchlist in the app, confirm with `GET /me/watchlist`; 4) edit a movie title in the website admin, pull-to-refresh in the app; 5) airplane mode → cached lists show the banner; 6) delete a movie in admin → app shows "Movie unavailable"; 7) revoke sessions in Admin → API → app returns to signed-out.

Downloads feature: nothing run. Manual test: download a small test video option; confirm notification progress, pause/resume, file appears in Gallery under Movies/PrimeMovie and in MX Player, plays offline in airplane mode in the Downloads tab, delete removes the file, and an option whose link is an HTML page shows the 'use your browser' message. Also test with low free storage.

Also written, not run: test/languages_test.dart, test/downloads_test.dart. Filters sheet, downloads, player (media_kit) have no automated UI tests; use the manual procedures above.

App-media update: still nothing executed. New tests written, not run: test/downloads_test.dart (round trip, offline args, app-media parsing, HLS never downloadable, locked). Manual checklist: website links unchanged; stream an MP4 (seek works only if the server supports Range); stream HLS; download completes in private storage; pause/resume/cancel/retry/delete; airplane-mode playback; expired link then Retry; audio/subtitle switch with a dual-audio MKV; locked version when signed out; unavailable version message; unauthorized token returns 401; large file; network drop mid-download.

Settings update: nothing executed. New test files written, not run: test/settings_test.dart. Manual checklist: switch Dark/Light/System and check every screen for unreadable text (the colour refactor replaced fixed colours with theme lookups across 8 files without a compiler); download to Phone and to SD card (with and without a card inserted); Wi-Fi only pauses on mobile data; delete all downloads removes files; clear cache keeps downloads; subtitle size changes in the player.

Hybrid-media update: nothing executed. Tests written, not run: test/downloads_test.dart additions (verification/resolution/embedded subtitle parsing, HLS never downloadable, unavailable reason). Needs the website staging flow first (upload → inspect → /app-media → stream → download → offline). `disk_space_plus` API usage is unverified.

Design update (Cinematic): nothing executed. Widget tests written, not run: test/anim_test.dart (FadeUp, GradientButton states, SlidingSegments, ExpandableText, passwordStrength). The redesign rewrote auth, home and movie screens and touched six others without a compiler: expect small compile fixes on first build, and check every screen visually in both Dark and Light themes and with large fonts.
