# API integration
Source of truth: the website's `/api/v1` (see the website project's `docs/API.md` / `openapi.json`). This app calls only documented endpoints.

- Envelope `{success,data,meta}` / `{success:false,error:{code,message,details}}` is unwrapped in `ApiClient`. Errors become `ApiError(status, code, message, details)`; 429 exposes `retryAfter`; no HTTP response = `offline`/`timeout`.
- Auth: bearer access token (15 min) + single-use rotating refresh token (30 days) in Android Keystore-backed `flutter_secure_storage`. On 401 the client refreshes once (single-flight, shared by concurrent requests), retries the request once, and on a rejected refresh clears tokens and signs the user out. No loops.
- Timeouts: connect 10 s, receive/send 20 s. Safe retries are manual (Retry buttons/pull-to-refresh); non-idempotent calls are never auto-retried.
- TLS: normal certificate validation; cleartext disabled in the manifest and `network_security_config.xml`.
- Logging: none of tokens/credentials is logged (no logging interceptor is installed).
- Cache (SQLite, non-sensitive JSON only): network first; on offline/timeout/5xx the saved copy is shown with a "Showing saved data" banner. A 404 (movie removed) is never masked and invalidates the cached copy. Tokens are never stored there.
- Download/watch options use `downloads[].url` (the site's `/download/{id}` gate) opened in the external browser; http(s) only.
