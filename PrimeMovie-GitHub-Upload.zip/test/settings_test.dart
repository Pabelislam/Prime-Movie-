import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:primemovie/data/settings.dart';

void main() {
  test('AppSettings round trip and defaults', () {
    const s = AppSettings(themeMode: ThemeMode.light, downloadLocation: 'sd', wifiOnly: true, subtitleSize: SubtitleSize.large);
    final r = AppSettings.fromJson(s.toJson());
    expect(r.themeMode, ThemeMode.light);
    expect(r.downloadLocation, 'sd');
    expect(r.wifiOnly, isTrue);
    expect(r.subtitleSize, SubtitleSize.large);
    expect(r.subtitleFontSize, 30);
  });

  test('AppSettings tolerates malformed stored data', () {
    final r = AppSettings.fromJson({'theme': 'purple', 'loc': '/etc', 'wifi': 'yes', 'sub': 99});
    expect(r.themeMode, ThemeMode.dark);
    expect(r.downloadLocation, 'phone', reason: 'only "phone" or "sd" are ever accepted');
    expect(r.wifiOnly, isFalse);
    expect(r.subtitleSize, SubtitleSize.medium);
    expect(AppSettings.fromJson('garbage').themeMode, ThemeMode.dark);
  });
}
