import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:primemovie/core/theme.dart';
import 'package:primemovie/features/auth_screens.dart';
import 'package:primemovie/widgets/anim.dart';

Widget wrap(Widget w) => MaterialApp(theme: Pm.dark(), home: Scaffold(body: Center(child: w)));

void main() {
  testWidgets('FadeUp shows its child after the entrance animation', (t) async {
    await t.pumpWidget(wrap(const FadeUp(index: 2, child: Text('hello'))));
    await t.pump(const Duration(milliseconds: 800));
    expect(find.text('hello'), findsOneWidget);
  });

  testWidgets('GradientButton shows a spinner, then a check, then calls onSuccess', (t) async {
    var done = false;
    await t.pumpWidget(wrap(SizedBox(width: 220, child: GradientButton(label: 'Sign in', onPressed: () async { await Future.delayed(const Duration(milliseconds: 100)); return true; }, onSuccess: () => done = true))));
    await t.tap(find.text('Sign in'));
    await t.pump(const Duration(milliseconds: 20));
    expect(find.byType(CircularProgressIndicator), findsOneWidget);
    await t.pump(const Duration(milliseconds: 200));
    expect(find.byIcon(Icons.check_rounded), findsOneWidget);
    await t.pump(const Duration(milliseconds: 800));
    expect(done, isTrue);
  });

  testWidgets('GradientButton returns to idle when the action fails', (t) async {
    await t.pumpWidget(wrap(SizedBox(width: 220, child: GradientButton(label: 'Go', onPressed: () async => false))));
    await t.tap(find.text('Go'));
    await t.pump(const Duration(milliseconds: 50));
    expect(find.text('Go'), findsOneWidget);
  });

  testWidgets('SlidingSegments reports the tapped index', (t) async {
    var picked = -1;
    await t.pumpWidget(wrap(SizedBox(width: 300, child: SlidingSegments(labels: const ['480p', '720p', '1080p'], selected: 0, onChanged: (i) => picked = i))));
    await t.tap(find.text('1080p'));
    expect(picked, 2);
  });

  testWidgets('ExpandableText offers Read more only for long text', (t) async {
    await t.pumpWidget(wrap(const SizedBox(width: 200, child: ExpandableText('short text'))));
    expect(find.text('Read more'), findsNothing);
    await t.pumpWidget(wrap(SingleChildScrollView(child: SizedBox(width: 200, child: ExpandableText('long text ' * 80, lines: 2)))));
    expect(find.text('Read more'), findsOneWidget);
    await t.tap(find.text('Read more'));
    await t.pumpAndSettle();
    expect(find.text('Show less'), findsOneWidget);
  });

  test('passwordStrength grows with length and variety', () {
    expect(passwordStrength('abc'), 0);
    expect(passwordStrength('abcdefgh'), 1);
    expect(passwordStrength('abcdefg1'), 2);
    expect(passwordStrength('abcdefg1hijk'), 3);
  });
}
