import 'package:flutter_test/flutter_test.dart';
import 'package:primemovie/data/downloads.dart';
import 'package:primemovie/data/models.dart';

void main() {
  test('DownloadItem survives a database round trip and reports active states', () {
    const i = DownloadItem(id: 'dl_app_9', movieId: 1, sourceId: 9, slug: 's', title: 'T', quality: '1080p', url: 'https://x.test/api/v1/media/t', createdAt: 1, status: DlStatus.paused, progress: .4, path: '/p', totalBytes: 1000000000);
    final r = DownloadItem.fromMap(i.toMap());
    expect(r.id, 'dl_app_9');
    expect(r.sourceId, 9);
    expect(r.status, DlStatus.paused);
    expect(r.active, isTrue);
    expect(r.sizeProgress, '381 MB of 954 MB');
    expect(r.copyWith(status: DlStatus.completed).active, isFalse);
  });

  test('offline player args keep audio labels and only existing subtitle files', () {
    const i = DownloadItem(
        id: 'dl_app_9', movieId: 1, sourceId: 9, slug: 's', title: 'T', quality: '720p', url: 'u', createdAt: 1, status: DlStatus.completed, path: '/movie.mp4',
        meta: '{"audio":[{"label":"Bangla","language":"bn","track_index":1}],"subs":[{"label":"English","language":"en","format":"vtt","local":"/does/not/exist.vtt"}]}');
    final a = i.toPlayerArgs()!;
    expect(a.isLocal, isTrue);
    expect(a.audio.single.label, 'Bangla');
    expect(a.audio.single.trackIndex, 1);
    expect(a.subtitles, isEmpty, reason: 'a missing subtitle file must be skipped, not crash');
  });

  test('AppMediaSource parsing and download rules', () {
    final s = AppMediaSource.fromJson({
      'id': 3, 'quality': '1080p', 'format': 'mp4', 'file_size': 1900000000, 'stream_enabled': true, 'download_enabled': true, 'requires_login': true,
      'locked': false, 'status': 'active', 'stream_url': 'https://x.test/api/v1/media/a', 'download_url': 'https://x.test/api/v1/media/b',
      'audio': [{'id': 1, 'label': 'Bangla', 'language': 'bn', 'track_index': 1, 'default': true}],
      'subtitles': [{'id': 2, 'label': 'English', 'language': 'en', 'format': 'srt', 'url': 'https://x.test/api/v1/media/c'}],
    });
    expect(s.canStream, isTrue);
    expect(s.canDownload, isTrue);
    expect(s.audio.single.trackIndex, 1);
    expect(s.subtitles.single.format, 'srt');
    final hls = AppMediaSource.fromJson({'id': 4, 'quality': '720p', 'format': 'hls', 'stream_enabled': true, 'download_enabled': true, 'status': 'active', 'stream_url': 'u', 'download_url': 'd'});
    expect(hls.canDownload, isFalse, reason: 'HLS playlists are never treated as a single downloadable file');
    final locked = AppMediaSource.fromJson({'id': 5, 'quality': '480p', 'format': 'mp4', 'locked': true, 'status': 'active'});
    expect(locked.canStream, isFalse);
    expect(locked.canDownload, isFalse);
  });

  hybridMediaTests();

  test('formatBytes', () {
    expect(formatBytes(null), '');
    expect(formatBytes(900 * 1024 * 1024), '900 MB');
    expect(formatBytes(1900000000), '1.8 GB');
  });
}

void hybridMediaTests() {
  test('hybrid media fields: verification, resolution, embedded subtitles, offline reason', () {
    final s = AppMediaSource.fromJson({
      'id': 8, 'quality': '1080p', 'format': 'mp4', 'protocol': 'file', 'file_size': 1000, 'resolution': {'width': 1920, 'height': 1080}, 'duration_seconds': 7260,
      'verification': {'status': 'verified', 'message': 'ok'}, 'stream_enabled': true, 'download_enabled': true, 'locked': false, 'status': 'active',
      'stream_url': 'https://x.test/api/v1/media/a', 'download_url': 'https://x.test/api/v1/media/b',
      'audio': [{'id': 1, 'label': 'Bangla', 'language': 'bn', 'codec': 'aac', 'origin': 'detected', 'track_index': 1}],
      'subtitles': [{'id': 2, 'label': 'English', 'language': 'en', 'format': 'embedded', 'origin': 'detected', 'embedded_index': 2, 'url': null}],
      'capabilities': {'offline_unavailable_reason': null},
    });
    expect(s.verified, isTrue);
    expect(s.height, 1080);
    expect(s.audio.single.origin, 'detected');
    expect(s.subtitles.single.url, isNull);
    expect(s.subtitles.single.embeddedIndex, 2);
  });

  test('HLS source can stream but never download, and shows the server reason', () {
    final s = AppMediaSource.fromJson({
      'id': 9, 'quality': '720p', 'format': 'hls', 'protocol': 'hls', 'stream_enabled': true, 'download_enabled': false, 'status': 'active',
      'stream_url': 'https://x.test/api/v1/media/a', 'download_url': 'https://x.test/api/v1/media/b',
      'capabilities': {'offline_unavailable_reason': 'Offline download is not available for this type of source.'},
    });
    expect(s.canStream, isTrue);
    expect(s.canDownload, isFalse);
    expect(s.offlineReason, isNotNull);
  });

  test('a source that failed verification is shown as unavailable with its reason', () {
    final s = AppMediaSource.fromJson({'id': 10, 'quality': '480p', 'format': 'mp4', 'status': 'unavailable', 'unavailable_reason': 'The file could not be read as a video.', 'verification': {'status': 'failed'}});
    expect(s.canStream, isFalse);
    expect(s.unavailableReason, contains('could not be read'));
  });
}
