import 'package:flutter_test/flutter_test.dart';
import 'package:primemovie/core/languages.dart';

void main() {
  test('language codes map to names', () {
    expect(languageName('ben'), 'Bangla');
    expect(languageName('bn'), 'Bangla');
    expect(languageName('HIN'), 'Hindi');
    expect(languageName('eng'), 'English');
    expect(languageName('en-US'), 'English');
    expect(languageName('und'), isNull);
    expect(languageName(null), isNull);
  });

  test('track labels use language, title, or a numbered fallback', () {
    expect(trackLabel(language: 'hin', title: null, index: 1), 'Hindi');
    expect(trackLabel(language: 'eng', title: 'Commentary', index: 2), 'English - Commentary');
    expect(trackLabel(language: 'eng', title: 'English', index: 2), 'English');
    expect(trackLabel(language: null, title: 'Dubbed', index: 3), 'Dubbed');
    expect(trackLabel(language: null, title: null, index: 4), 'Track 4');
  });
}
