import 'package:flutter_test/flutter_test.dart';
import 'package:primemovie/data/models.dart';

void main() {
  test('Movie.fromJson parses list and detail payloads and tolerates missing fields', () {
    final m = Movie.fromJson({
      'id': 5, 'slug': 'x-2024', 'title': 'X', 'release_year': 2024, 'rating': 7.5, 'views': 10, 'featured': true,
      'genres': [{'id': 1, 'name': 'Action', 'slug': 'action'}],
      'cast': ['A', 'B'],
      'downloads': [{'id': 9, 'quality': '1080p', 'url': 'https://s.test/download/9'}],
      'review_summary': {'count': 2, 'average': 4.5},
    });
    expect(m.id, 5);
    expect(m.genres.single.slug, 'action');
    expect(m.cast, ['A', 'B']);
    expect(m.downloads.single.id, 9);
    expect(m.reviewSummary!.average, 4.5);
    expect(m.isDetail, isTrue);
    final bare = Movie.fromJson({'id': '7', 'slug': 's', 'title': 'T', 'rating': null, 'poster_url': ''});
    expect(bare.id, 7);
    expect(bare.rating, isNull);
    expect(bare.posterUrl, isNull);
  });

  test('RemoteConfig validates values and falls back to defaults on garbage', () {
    expect(RemoteConfig.fromJson('nonsense').maintenance, isFalse);
    final c = RemoteConfig.fromJson({
      'site_name': '  PrimeMovie  ', 'maintenance': true,
      'features': {'registration': false, 'reviews': 'yes'},
      'api': {'min_supported_app_version': 'javascript:alert(1)'},
      'limits': {'max_per_page': 9999},
    });
    expect(c.siteName, 'PrimeMovie');
    expect(c.maintenance, isTrue);
    expect(c.registration, isFalse);
    expect(c.reviews, isTrue, reason: 'non-bool flag falls back to default');
    expect(c.minAppVersion, '1.0.0');
    expect(c.maxPerPage, 50);
  });

  test('requiresUpdate compares semantic versions', () {
    const c = RemoteConfig(minAppVersion: '1.2.0');
    expect(c.requiresUpdate('1.1.9'), isTrue);
    expect(c.requiresUpdate('1.2.0'), isFalse);
    expect(c.requiresUpdate('2.0.0'), isFalse);
  });
}
