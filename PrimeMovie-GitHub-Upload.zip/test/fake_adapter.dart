import 'dart:async';
import 'dart:convert';
import 'dart:typed_data';
import 'package:dio/dio.dart';

typedef Handler = FutureOr<FakeReply> Function(RequestOptions o);

class FakeReply {
  final int status;
  final Object? body;
  const FakeReply(this.status, this.body);
}

/// Dio adapter that answers from a function, so tests never touch the network.
class FakeAdapter implements HttpClientAdapter {
  final Handler handler;
  final List<RequestOptions> calls = [];
  FakeAdapter(this.handler);

  @override
  Future<ResponseBody> fetch(RequestOptions options, Stream<Uint8List>? requestStream, Future<void>? cancelFuture) async {
    calls.add(options);
    final r = await handler(options);
    return ResponseBody.fromString(jsonEncode(r.body), r.status, headers: {Headers.contentTypeHeader: ['application/json']});
  }

  @override
  void close({bool force = false}) {}
}

Map<String, dynamic> ok(Object? data, [Map<String, dynamic> meta = const {}]) => {'success': true, 'data': data, 'meta': meta};
Map<String, dynamic> err(String code, String msg, [Map<String, dynamic>? details]) => {'success': false, 'error': {'code': code, 'message': msg, if (details != null) 'details': details}, 'meta': {}};
