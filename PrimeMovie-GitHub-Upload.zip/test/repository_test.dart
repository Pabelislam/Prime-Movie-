import 'package:dio/dio.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:primemovie/core/api_client.dart';
import 'package:primemovie/core/cache.dart';
import 'package:primemovie/data/repositories.dart';
import 'fake_adapter.dart';

ContentRepository repo(FakeAdapter a, CacheStore cache) {
  final d = Dio(BaseOptions(baseUrl: 'https://x.test/api/v1/', validateStatus: (_) => true))..httpClientAdapter = a;
  return ContentRepository(ApiClient(tokens: MemoryTokenStore(), dio: d, bare: d), cache);
}

Map<String, dynamic> movieJson(String slug) => {'id': 1, 'slug': slug, 'title': 'T', 'description': 'D', 'downloads': []};

void main() {
  test('network success is cached and marked fresh', () async {
    final cache = MemoryCache();
    final r = repo(FakeAdapter((o) => FakeReply(200, ok(movieJson('a')))), cache);
    final c = await r.movie('a');
    expect(c.fromCache, isFalse);
    expect((await cache.get('movie:a')), isNotNull);
  });

  test('offline falls back to the cached copy and flags fromCache', () async {
    final cache = MemoryCache();
    await repo(FakeAdapter((o) => FakeReply(200, ok(movieJson('a')))), cache).movie('a');
    final offline = repo(FakeAdapter((o) => throw DioException(requestOptions: o, type: DioExceptionType.connectionError)), cache);
    final c = await offline.movie('a');
    expect(c.fromCache, isTrue);
    expect(c.data.slug, 'a');
  });

  test('offline with nothing cached rethrows', () async {
    final offline = repo(FakeAdapter((o) => throw DioException(requestOptions: o, type: DioExceptionType.connectionError)), MemoryCache());
    expect(() => offline.movie('zzz'), throwsA(isA<ApiError>()));
  });

  test('404 (deleted movie) is never masked by the cache', () async {
    final cache = MemoryCache();
    await repo(FakeAdapter((o) => FakeReply(200, ok(movieJson('a')))), cache).movie('a');
    final gone = repo(FakeAdapter((o) => FakeReply(404, err('not_found', 'Movie not found.'))), cache);
    await expectLater(gone.movie('a'), throwsA(isA<ApiError>().having((e) => e.status, 'status', 404)));
    final offline = repo(FakeAdapter((o) => throw DioException(requestOptions: o, type: DioExceptionType.connectionError)), cache);
    await expectLater(offline.movie('a'), throwsA(isA<ApiError>()), reason: 'deleted record must not resurface from cache');
  });

  test('config() never throws and returns defaults when the server fails', () async {
    final r = repo(FakeAdapter((o) => FakeReply(500, err('server_error', 'x'))), MemoryCache());
    expect((await r.config()).maintenance, isFalse);
  });

  test('movie list pagination metadata is parsed', () async {
    final r = repo(FakeAdapter((o) => FakeReply(200, ok([movieJson('a')], {'page': 1, 'total': 30, 'has_more': true}))), MemoryCache());
    final p = await r.movies(const MovieQuery(q: 'a'));
    expect(p.items.length, 1);
    expect(p.hasMore, isTrue);
    expect(p.total, 30);
  });
}
