import 'package:dio/dio.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:primemovie/core/api_client.dart';
import 'fake_adapter.dart';

ApiClient make(FakeAdapter a, {FakeAdapter? bare, TokenStore? store}) {
  final d = Dio(BaseOptions(baseUrl: 'https://x.test/api/v1/', validateStatus: (_) => true))..httpClientAdapter = a;
  final b = Dio(BaseOptions(baseUrl: 'https://x.test/api/v1/', validateStatus: (_) => true))..httpClientAdapter = bare ?? a;
  return ApiClient(tokens: store ?? MemoryTokenStore(), dio: d, bare: b);
}

void main() {
  test('unwraps success envelope and meta', () async {
    final c = make(FakeAdapter((o) => FakeReply(200, ok([1, 2], {'total': 2}))));
    final r = await c.get('movies', auth: false);
    expect(r.data, [1, 2]);
    expect(r.meta['total'], 2);
  });

  test('maps error envelope, details and 429 retry_after', () async {
    final c = make(FakeAdapter((o) => FakeReply(429, err('rate_limited', 'Slow down', {'retry_after': 12}))));
    try {
      await c.get('movies', auth: false);
      fail('should throw');
    } on ApiError catch (e) {
      expect(e.status, 429);
      expect(e.code, 'rate_limited');
      expect(e.isRateLimited, isTrue);
      expect(e.retryAfter, 12);
    }
  });

  test('non-JSON server error becomes a bad_response ApiError', () async {
    final c = make(FakeAdapter((o) => const FakeReply(502, '<html>bad gateway</html>')));
    expect(() => c.get('movies', auth: false), throwsA(isA<ApiError>().having((e) => e.status, 'status', 502)));
  });

  test('401 triggers exactly one refresh, then retries once with the new token', () async {
    final store = MemoryTokenStore();
    await store.write(const Tokens('old', 'r1'));
    var refreshCalls = 0;
    final main = FakeAdapter((o) {
      final auth = o.headers['Authorization'];
      if (auth == 'Bearer new') return FakeReply(200, ok({'id': 'u1'}));
      return FakeReply(401, err('invalid_token', 'expired'));
    });
    final bare = FakeAdapter((o) {
      refreshCalls++;
      return FakeReply(200, ok({'tokens': {'access_token': 'new', 'refresh_token': 'r2'}}));
    });
    final c = make(main, bare: bare, store: store);
    final results = await Future.wait([c.get('me'), c.get('me/watchlist'), c.get('me/recent')]);
    expect(results.length, 3);
    expect(refreshCalls, 1, reason: 'concurrent 401s must share a single refresh');
    expect((await store.read())!.refresh, 'r2');
  });

  test('rejected refresh clears tokens and signals session expiry; no retry loop', () async {
    final store = MemoryTokenStore();
    await store.write(const Tokens('old', 'r1'));
    var expired = 0;
    final main = FakeAdapter((o) => FakeReply(401, err('invalid_token', 'expired')));
    final bare = FakeAdapter((o) => FakeReply(401, err('invalid_refresh_token', 'bad')));
    final c = make(main, bare: bare, store: store)..onSessionExpired = () => expired++;
    await expectLater(c.get('me'), throwsA(isA<ApiError>()));
    expect(await store.read(), isNull);
    expect(expired, 1);
    expect(main.calls.length, 1);
  });

  test('public requests never send Authorization', () async {
    final store = MemoryTokenStore();
    await store.write(const Tokens('a', 'r'));
    final main = FakeAdapter((o) => FakeReply(200, ok([])));
    await make(main, store: store).get('movies', auth: false);
    expect(main.calls.single.headers.containsKey('Authorization'), isFalse);
  });
}
