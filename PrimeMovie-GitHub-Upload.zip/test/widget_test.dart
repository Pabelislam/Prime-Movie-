import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:primemovie/core/api_client.dart';
import 'package:primemovie/core/theme.dart';
import 'package:primemovie/data/models.dart';
import 'package:primemovie/features/auth_screens.dart';
import 'package:primemovie/widgets/common.dart';

Widget wrap(Widget w) => MaterialApp(theme: Pm.dark(), home: Scaffold(body: w));

void main() {
  testWidgets('ErrorView shows offline message and retry', (t) async {
    var taps = 0;
    await t.pumpWidget(wrap(ErrorView(error: const ApiError(null, 'offline', "Can't reach the server."), onRetry: () => taps++)));
    expect(find.text("You're offline"), findsOneWidget);
    await t.tap(find.text('Retry'));
    expect(taps, 1);
  });

  testWidgets('EmptyView renders title and message', (t) async {
    await t.pumpWidget(wrap(const EmptyView(icon: Icons.search_off, title: 'No movies found', message: 'Try again')));
    expect(find.text('No movies found'), findsOneWidget);
    expect(find.text('Try again'), findsOneWidget);
  });

  testWidgets('MovieCard shows title and year without a poster', (t) async {
    await t.pumpWidget(wrap(const SizedBox(width: 120, child: MovieCard(movie: Movie(id: 1, slug: 's', title: 'Inception', releaseYear: 2010)))));
    expect(find.text('Inception'), findsOneWidget);
    expect(find.text('2010'), findsOneWidget);
  });

  test('password and email validators', () {
    expect(validatePassword('short1'), isNotNull);
    expect(validatePassword('longenough'), isNotNull);
    expect(validatePassword('Passw0rd123'), isNull);
    expect(validateEmail('nope'), isNotNull);
    expect(validateEmail('a@b.co'), isNull);
  });
}
