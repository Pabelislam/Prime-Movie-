#!/usr/bin/env bash
# One-time setup: generates the Android/Gradle scaffolding that matches YOUR installed Flutter version,
# then applies this project's manifest and network security config.
set -euo pipefail
cd "$(dirname "$0")/.."
flutter create --org site.primemovie --project-name primemovie --platforms android .
cp android_overrides/AndroidManifest.xml android/app/src/main/AndroidManifest.xml
# app icon (adaptive + legacy launcher icons) and the native dark splash with the PrimeMovie logo
rm -f android/app/src/main/res/mipmap-*/ic_launcher.webp
cp -r android_overrides/res/. android/app/src/main/res/
mkdir -p android/app/src/main/res/xml
cp android_overrides/xml/network_security_config.xml android/app/src/main/res/xml/
# keep the generated Kotlin namespace, but publish under the intended application ID
sed -i -E 's/applicationId( =)? ?"site\.primemovie\.primemovie"/applicationId\1 "site.primemovie.app"/' android/app/build.gradle* || true
# Saving into Movies/PrimeMovie without storage permissions needs Android 10 (API 29) or newer
sed -i -E 's/minSdk(Version)?( =)? ?(flutter\.minSdkVersion|[0-9]+)/minSdk\1\2 29/' android/app/build.gradle* || true
echo "Check that minSdk is 29 in android/app/build.gradle(.kts)."
echo "Now: check applicationId in android/app/build.gradle(.kts) is site.primemovie.app, then run: flutter pub get && flutter analyze && flutter test"
