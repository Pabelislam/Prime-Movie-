# PrimeMovie — Flutter Android app

Native Flutter client for the existing PrimeMovie website API (`https://primemovie.site/api/v1/`). Not a WebView. No separate backend or database: all movie, account, watchlist, history and review data comes from the website.

**Status: source only.** The environment that produced this project had no Flutter SDK, so `flutter pub get/analyze/test/build` were NOT run. Expect to fix small compile errors on first build; see `docs/TEST_RESULTS.md`.

## Requirements (verify against your install)
Flutter stable ≥ 3.22 (Dart ≥ 3.4), JDK 17, Android SDK platform 34+ with build-tools, Android Studio (Koala or newer). Gradle/AGP versions come from `flutter create` for your Flutter version, so they always match.

## First-time setup
```bash
cd PrimeMovie-Flutter-Android
./tool/setup.sh          # flutter create (android scaffolding) + applies manifest/network config, sets applicationId site.primemovie.app
flutter pub get
flutter analyze
flutter test
```
Open the folder in Android Studio (Flutter plugin) → run on an emulator/device.

## API base URL
Default `https://primemovie.site/api/v1`. Change at build time:
`flutter run --dart-define=API_BASE_URL=https://staging.example.com/api/v1` (same flag for `build`). The site must already have the API from the website upgrade deployed (GET `<base>/health` must answer).

## Builds
```bash
flutter build apk --debug                       # build/app/outputs/flutter-apk/app-debug.apk
flutter build apk --release                     # needs signing (below)
flutter build appbundle --release               # build/app/outputs/bundle/release/app-release.aab (Google Play)
```
### Signing
1. `keytool -genkey -v -keystore ~/primemovie-release.jks -keyalg RSA -keysize 2048 -validity 10000 -alias primemovie`
2. Copy `android_overrides/key.properties.example` to `android/key.properties`, fill in values (git-ignored).
3. In `android/app/build.gradle(.kts)` add a `signingConfigs.release` that reads `key.properties` and use it in `buildTypes.release` (Flutter docs: "Build and release an Android app").
4. **Back up the .jks and passwords in at least two offline places.** If lost, you can never update the app under the same Play listing (unless you use Play App Signing, which is recommended: enroll when uploading the first AAB).
Future updates: keep `applicationId` (`site.primemovie.app`) and the same key; raise `version:` in pubspec.yaml (`1.0.1+2`).

## Deep links
`https://primemovie.site/movie/<slug>` opens the movie page in the app. For verified App Links the website must serve `/.well-known/assetlinks.json` with your signing certificate SHA-256 (not part of this task; without it Android shows an "open with" chooser instead).

## App icon / splash
Not generated, because the real logo file was not supplied (I did not invent a fake brand mark). Put your square 1024x1024 PNG logo at `assets/icon.png`, then run `dart run flutter_launcher_icons` (already configured in pubspec.yaml). Splash background color: `#0A0B0F`.

## Structure
`lib/core` (config, theme from the site's CSS variables, API client, SQLite cache) · `lib/data` (models, repositories, remote-config validation) · `lib/features` (home, browse/search, detail, auth, library/profile) · `lib/widgets` · `test/`.
Docs: `docs/API_INTEGRATION.md`, `docs/FEATURE_MAP.md`, `docs/SYNC_AND_RELEASES.md`, `docs/TEST_RESULTS.md`.

## Streaming and downloads (app-only media)
The app does **not** use the website's external download links for in-app downloads. Each movie can have separate *Android App Media* versions (configured in the website admin, see `docs/APP_MEDIA.md`). The movie page shows "Watch & download in the app" (Play / Download / Play offline) and, below it, the unchanged "Website download links", which still open the browser.
- **Play** streams through the in-app player (HLS, MP4, MKV, WebM as the player supports; seeking depends on the server supporting Range requests).
- **Download** saves the file into **app-private storage** (notification, pause/resume, background). Subtitle files are saved with it, so they work offline. Downloaded files can be played only in this app. Optional switch on the Downloads screen: also copy new downloads to `Movies/PrimeMovie` (visible to Gallery/MX Player/PlayIt; then other apps can copy them).
- HLS/DASH are streaming-only; no offline HLS and no DRM handling.
- Signed links expire (stream 4 h, download 6 h). Pause/resume within that window continues the file; a failed/expired download restarts from the beginning after "Retry" with a fresh link.
- Free-space is not checked before starting (no plugin for it); a full disk surfaces as a failed download with a message. Large files rely on the native downloader's retries.
- Resume position is remembered on the device (not synced between devices).
Requirements: Android 10+ (minSdk 29 via `tool/setup.sh`). Only offer media you are authorised to distribute; Google Play reviews this.

## Player: audio and subtitle languages
The offline player uses `media_kit` (libmpv), so one file can carry several audio tracks (e.g. Bangla/Hindi/English dual-audio MKV) and soft subtitles. **Audio** (note icon) and **CC** buttons list the languages found inside the file; the choice applies immediately. Limits: only tracks embedded in the downloaded file are listed; burned-in (hard-coded) subtitles can't be toggled; the site's API has no subtitle files, so separate .srt/.vtt downloads would need a backend field first. Adds ~10-20 MB per ABI to the APK (use `--split-per-abi` or an AAB). Package versions/API names (`setAudioTrack`, `setSubtitleTrack`, `NoVideoControls`) were written from memory: check on first build.

## Settings (Profile → Settings)
- **Theme:** Dark (default, matches the website), Light, or System. The light palette is a light version of the same design (same red accent and radii).
- **Download location:** Phone storage or SD card. Both are app-specific folders (no storage permission, private to the app); SD card is offered only when Android reports a removable volume, otherwise it shows as "not detected". Applies to new downloads; if the SD card is missing when a download starts, the user gets a clear message instead of a silent failure. Files on the SD card are removed if the app is uninstalled.
- **Download over Wi-Fi only**, **also copy to Movies/PrimeMovie** (optional, off by default), **storage used by downloads**, **delete all downloads**.
- **Subtitle size** (small/medium/large), **clear cache** (keeps downloads and settings), **forget playback positions**.
Not included: free-space numbers (needs an extra plugin), app language switch (UI is English), background-data limits beyond Wi-Fi only. Package/API names (`getExternalStorageDirectories`, `BaseDirectory.root`, `requiresWiFi`) must be verified on first build.

## Design
Cinematic design with animations: see `docs/DESIGN.md`. Animations respect the phone's reduce-motion setting.
