# GitHub upload guide

1. Extract this ZIP on your phone or computer.
2. Open your `Prime-Movie-` repository on GitHub.
3. Upload the **contents of the extracted folder** to the repository root. Do not upload only this ZIP if you want GitHub Actions to build the app.
4. Keep the folder structure intact, especially `lib/`, `test/`, `tool/`, `android_overrides/`, and `.github/workflows/`.
5. Commit the files to the `main` branch.
6. Open the repository's **Actions** tab. The workflow named **PrimeMovie Android Build** will run.
7. If the workflow succeeds, open its run and download the `primemovie-android-apk` artifact.

Important:
- This is source code, not a prebuilt APK.
- The first build may fail if the source has compile errors or a dependency/API mismatch. Fix reported errors before treating the APK as production-ready.
- The workflow uses Flutter 3.24.5 and generates the Android platform folder using `tool/setup.sh`.
- Do not upload signing keys, passwords, or private API secrets.
