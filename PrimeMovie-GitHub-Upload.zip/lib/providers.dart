import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'core/api_client.dart';
import 'core/cache.dart';
import 'data/models.dart';
import 'data/repositories.dart';

final tokenStoreProvider = Provider<TokenStore>((_) => SecureTokenStore());
final cacheProvider = Provider<CacheStore>((_) => SqliteCache());

final apiClientProvider = Provider<ApiClient>((ref) {
  final c = ApiClient(tokens: ref.watch(tokenStoreProvider));
  c.onSessionExpired = () => ref.read(authProvider.notifier).sessionExpired();
  return c;
});

final contentRepoProvider = Provider((ref) => ContentRepository(ref.watch(apiClientProvider), ref.watch(cacheProvider)));
final accountRepoProvider = Provider((ref) => AccountRepository(ref.watch(apiClientProvider), ref.watch(cacheProvider)));

final configProvider = FutureProvider<RemoteConfig>((ref) => ref.watch(contentRepoProvider).config());

// ---- auth ----
class AuthState {
  final UserProfile? user;
  final bool loading;
  final String? error; // set when restore failed for a network reason
  const AuthState({this.user, this.loading = true, this.error});
  bool get signedIn => user != null;
}

class AuthNotifier extends Notifier<AuthState> {
  @override
  AuthState build() {
    Future.microtask(restore);
    return const AuthState();
  }

  AccountRepository get _repo => ref.read(accountRepoProvider);

  Future<void> restore() async {
    try {
      state = AuthState(user: await _repo.restore(), loading: false);
    } on ApiError catch (e) {
      state = AuthState(loading: false, error: e.message);
    }
  }

  Future<void> login(String email, String password) async => state = AuthState(user: await _repo.login(email, password), loading: false);
  Future<void> register(String email, String name, String password) async => state = AuthState(user: await _repo.register(email, name, password), loading: false);

  Future<void> logout() async {
    await _repo.logout();
    _clearUserData();
    state = const AuthState(loading: false);
  }

  Future<void> logoutAll() async {
    await _repo.logoutAll();
    _clearUserData();
    state = const AuthState(loading: false);
  }

  void sessionExpired() {
    _clearUserData();
    state = const AuthState(loading: false);
  }

  void setUser(UserProfile u) => state = AuthState(user: u, loading: false);

  void _clearUserData() {
    ref.invalidate(watchlistIdsProvider);
    ref.invalidate(favoriteIdsProvider);
    ref.invalidate(recommendationsProvider);
  }
}

final authProvider = NotifierProvider<AuthNotifier, AuthState>(AuthNotifier.new);

// ---- home content ----
final collectionProvider = FutureProvider.family<Paged<Movie>, String>((ref, kind) => ref.watch(contentRepoProvider).collection(kind));
final languagesProvider = FutureProvider<List<String>>((ref) => ref.watch(contentRepoProvider).languages());
final countriesProvider = FutureProvider<List<String>>((ref) => ref.watch(contentRepoProvider).countries());
final categoriesProvider = FutureProvider<List<Genre>>((ref) => ref.watch(contentRepoProvider).categories());
final movieDetailProvider = FutureProvider.family<Cached<Movie>, String>((ref, slug) => ref.watch(contentRepoProvider).movie(slug));
final appMediaProvider = FutureProvider.autoDispose.family<List<AppMediaSource>, String>((ref, slug) => ref.watch(contentRepoProvider).appMedia(slug));
final relatedProvider = FutureProvider.family<List<Movie>, String>((ref, slug) => ref.watch(contentRepoProvider).related(slug));
final reviewsProvider = FutureProvider.family<Paged<Review>, String>((ref, slug) => ref.watch(contentRepoProvider).reviews(slug));
final recommendationsProvider = FutureProvider<List<Movie>>((ref) async {
  if (!ref.watch(authProvider).signedIn) return [];
  return ref.watch(accountRepoProvider).recommendations();
});

// ---- user lists ----
class IdSetNotifier extends AsyncNotifier<Set<int>> {
  IdSetNotifier(this.type);
  final String type;

  @override
  Future<Set<int>> build() async {
    if (!ref.watch(authProvider).signedIn) return <int>{};
    return ref.watch(accountRepoProvider).listIds(type);
  }

  /// Server first; the local set only changes after the API confirms, so app and website never disagree.
  Future<void> toggle(int movieId) async {
    final cur = state.valueOrNull ?? <int>{};
    final repo = ref.read(accountRepoProvider);
    if (cur.contains(movieId)) {
      await repo.removeFromList(type, movieId);
      state = AsyncData({...cur}..remove(movieId));
    } else {
      await repo.addToList(type, movieId);
      state = AsyncData({...cur, movieId});
    }
    ref.invalidate(libraryProvider(type));
    ref.invalidate(recommendationsProvider);
  }
}

final watchlistIdsProvider = AsyncNotifierProvider<IdSetNotifier, Set<int>>(() => IdSetNotifier('watchlist'));
final favoriteIdsProvider = AsyncNotifierProvider<IdSetNotifier, Set<int>>(() => IdSetNotifier('favorites'));

final libraryProvider = FutureProvider.family<Paged<Movie>, String>((ref, type) {
  final repo = ref.watch(accountRepoProvider);
  return type == 'recent' ? repo.recent() : repo.list(type);
});

// ---- paged browse/search ----
class PagedState {
  final List<Movie> items;
  final bool hasMore, loading, fromCache;
  final int total;
  final ApiError? error;
  const PagedState({this.items = const [], this.hasMore = true, this.loading = false, this.fromCache = false, this.total = 0, this.error});
  PagedState copy({List<Movie>? items, bool? hasMore, bool? loading, bool? fromCache, int? total, ApiError? error, bool clearError = false}) =>
      PagedState(items: items ?? this.items, hasMore: hasMore ?? this.hasMore, loading: loading ?? this.loading, fromCache: fromCache ?? this.fromCache, total: total ?? this.total, error: clearError ? null : (error ?? this.error));
}

class MovieListNotifier extends FamilyNotifier<PagedState, MovieQuery> {
  int _page = 0;
  bool _busy = false;

  @override
  PagedState build(MovieQuery arg) {
    Future.microtask(loadMore);
    return const PagedState(loading: true);
  }

  Future<void> loadMore() async {
    if (_busy || !state.hasMore) return;
    _busy = true;
    state = state.copy(loading: true, clearError: true);
    try {
      final p = await ref.read(contentRepoProvider).movies(arg.withPage(_page + 1));
      _page = p.page;
      state = state.copy(items: [...state.items, ...p.items], hasMore: p.hasMore, loading: false, total: p.total, fromCache: p.fromCache);
    } on ApiError catch (e) {
      state = state.copy(loading: false, error: e);
    } finally {
      _busy = false;
    }
  }

  Future<void> refresh() async {
    await ref.read(contentRepoProvider).invalidateContent();
    _page = 0;
    state = const PagedState(loading: true);
    await loadMore();
  }
}

final movieListProvider = NotifierProvider.family<MovieListNotifier, PagedState, MovieQuery>(MovieListNotifier.new);
