import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../core/api_client.dart';
import '../core/theme.dart';
import 'anim.dart';
import '../data/models.dart';

class Poster extends StatelessWidget {
  final String? url;
  final String label;
  final double radius;
  const Poster({super.key, required this.url, required this.label, this.radius = Pm.cardRadius});

  @override
  Widget build(BuildContext context) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(radius),
      child: AspectRatio(
        aspectRatio: Pm.posterRatio,
        child: url == null
            ? const _PosterFallback()
            : CachedNetworkImage(
                imageUrl: url!,
                fit: BoxFit.cover,
                fadeInDuration: const Duration(milliseconds: 150),
                memCacheWidth: 400,
                placeholder: (_, __) => Container(color: context.pm.card),
                errorWidget: (_, __, ___) => const _PosterFallback(),
                imageBuilder: (_, img) => Semantics(label: 'Poster of $label', image: true, child: Image(image: img, fit: BoxFit.cover)),
              ),
      ),
    );
  }
}

class _PosterFallback extends StatelessWidget {
  const _PosterFallback();
  @override
  Widget build(BuildContext context) => Container(color: context.pm.card, child: Center(child: Icon(Icons.movie_outlined, color: context.pm.muted, size: 40)));
}

class MovieCard extends StatelessWidget {
  final Movie movie;
  final double? width;
  const MovieCard({super.key, required this.movie, this.width});

  @override
  Widget build(BuildContext context) {
    final lang = movie.language;
    return Semantics(
      button: true,
      label: '${movie.title}${movie.releaseYear != null ? ', ${movie.releaseYear}' : ''}',
      child: PressScale(
        onTap: () => context.push('/movie/${movie.slug}'),
        child: SizedBox(
          width: width,
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Stack(children: [
              Poster(url: movie.posterUrl, label: movie.title),
              if (movie.quality != null || lang != null)
                Positioned(left: 6, top: 6, child: Wrap(spacing: 4, children: [
                  if (movie.quality != null) _Badge(movie.quality!, Pm.brand),
                  if (lang != null) _Badge(lang, Colors.black87),
                ])),
              if (movie.rating != null)
                Positioned(right: 6, bottom: 6, child: _Badge('★ ${movie.rating!.toStringAsFixed(1)}', Colors.black87, color: Pm.star)),
            ]),
            const SizedBox(height: 6),
            Text(movie.title, maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 13, height: 1.25)),
            if (movie.releaseYear != null) Text('${movie.releaseYear}', style: TextStyle(color: context.pm.muted, fontSize: 12)),
          ]),
        ),
      ),
    );
  }
}

class _Badge extends StatelessWidget {
  final String text;
  final Color bg;
  final Color color;
  const _Badge(this.text, this.bg, {this.color = Colors.white});
  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
        decoration: BoxDecoration(color: bg, borderRadius: BorderRadius.circular(4)),
        child: Text(text, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(color: color, fontSize: 10, fontWeight: FontWeight.w700)),
      );
}

class SectionHeader extends StatelessWidget {
  final String title;
  final VoidCallback? onMore;
  const SectionHeader(this.title, {super.key, this.onMore});
  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.fromLTRB(16, 20, 8, 10),
        child: Row(children: [
          Container(width: 4, height: 18, decoration: BoxDecoration(gradient: Pm.brandGradient, borderRadius: BorderRadius.circular(2))),
          const SizedBox(width: 8),
          Expanded(child: Text(title, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w800))),
          if (onMore != null) TextButton(onPressed: onMore, child: const Text('See all')),
        ]),
      );
}

class MovieRow extends StatelessWidget {
  final List<Movie> movies;
  const MovieRow(this.movies, {super.key});
  @override
  Widget build(BuildContext context) => SizedBox(
        height: 248,
        child: ListView.separated(
          scrollDirection: Axis.horizontal,
          padding: const EdgeInsets.symmetric(horizontal: 16),
          itemCount: movies.length,
          separatorBuilder: (_, __) => const SizedBox(width: 12),
          itemBuilder: (_, i) => FadeUp(index: i, child: MovieCard(movie: movies[i], width: 120)),
        ),
      );
}

/// Responsive poster grid: 2 columns on phones, more on tablets.
SliverGridDelegate posterGrid(BuildContext context) => const SliverGridDelegateWithMaxCrossAxisExtent(
      maxCrossAxisExtent: 170,
      childAspectRatio: 0.52,
      crossAxisSpacing: 12,
      mainAxisSpacing: 14,
    );

class LoadingView extends StatelessWidget {
  const LoadingView({super.key});
  @override
  Widget build(BuildContext context) => const Center(child: Padding(padding: EdgeInsets.all(32), child: CircularProgressIndicator(color: Pm.brand)));
}

class EmptyView extends StatelessWidget {
  final IconData icon;
  final String title;
  final String? message;
  final Widget? action;
  const EmptyView({super.key, required this.icon, required this.title, this.message, this.action});
  @override
  Widget build(BuildContext context) => Center(
        child: Padding(
          padding: const EdgeInsets.all(32),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Icon(icon, size: 56, color: context.pm.muted),
            const SizedBox(height: 12),
            Text(title, textAlign: TextAlign.center, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w800)),
            if (message != null) ...[const SizedBox(height: 6), Text(message!, textAlign: TextAlign.center, style: TextStyle(color: context.pm.muted))],
            if (action != null) ...[const SizedBox(height: 16), action!],
          ]),
        ),
      );
}

class ErrorView extends StatelessWidget {
  final Object error;
  final VoidCallback onRetry;
  const ErrorView({super.key, required this.error, required this.onRetry});
  @override
  Widget build(BuildContext context) {
    final e = error is ApiError ? error as ApiError : null;
    final offline = e?.isNetwork ?? false;
    final msg = e == null ? 'Something went wrong. Please try again.' : (e.isRateLimited && e.retryAfter != null ? 'Too many requests. Try again in ${e.retryAfter}s.' : e.message);
    return EmptyView(
      icon: offline ? Icons.wifi_off_rounded : Icons.error_outline,
      title: offline ? "You're offline" : 'Something went wrong',
      message: msg,
      action: FilledButton.icon(onPressed: onRetry, icon: const Icon(Icons.refresh), label: const Text('Retry')),
    );
  }
}

class OfflineBanner extends StatelessWidget {
  const OfflineBanner({super.key});
  @override
  Widget build(BuildContext context) => Container(
        width: double.infinity,
        color: context.pm.card2,
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
        child: Row(children: [Icon(Icons.cloud_off, size: 16, color: context.pm.muted), SizedBox(width: 8), Text('Showing saved data', style: TextStyle(color: context.pm.muted, fontSize: 12))]),
      );
}

void toast(BuildContext c, String m) => ScaffoldMessenger.of(c).showSnackBar(SnackBar(content: Text(m)));
String errText(Object e) => e is ApiError ? e.message : 'Something went wrong. Please try again.';
