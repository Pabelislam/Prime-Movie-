import 'dart:async';
import 'dart:ui';
import 'package:flutter/material.dart';
import '../core/theme.dart';

bool reduceMotion(BuildContext c) => MediaQuery.maybeOf(c)?.disableAnimations ?? false;

/// Fades and slides a child up when it first appears. Use [index] to stagger items in a list.
class FadeUp extends StatefulWidget {
  final Widget child;
  final int index;
  final Duration duration;
  final double dy;
  const FadeUp({super.key, required this.child, this.index = 0, this.duration = const Duration(milliseconds: 520), this.dy = 18});
  @override
  State<FadeUp> createState() => _FadeUpState();
}

class _FadeUpState extends State<FadeUp> with SingleTickerProviderStateMixin {
  late final AnimationController _c = AnimationController(vsync: this, duration: widget.duration);
  late final Animation<double> _a = CurvedAnimation(parent: _c, curve: Curves.easeOutCubic);
  Timer? _t;

  @override
  void initState() {
    super.initState();
    _t = Timer(Duration(milliseconds: 60 * widget.index.clamp(0, 12)), () { if (mounted) _c.forward(); });
  }

  @override
  void dispose() {
    _t?.cancel();
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (reduceMotion(context)) return widget.child;
    return AnimatedBuilder(
      animation: _a,
      child: widget.child,
      builder: (_, child) => Opacity(opacity: _a.value, child: Transform.translate(offset: Offset(0, (1 - _a.value) * widget.dy), child: child)),
    );
  }
}

/// Tap feedback: shrinks slightly while pressed.
class PressScale extends StatefulWidget {
  final Widget child;
  final VoidCallback? onTap;
  final double scale;
  const PressScale({super.key, required this.child, this.onTap, this.scale = .95});
  @override
  State<PressScale> createState() => _PressScaleState();
}

class _PressScaleState extends State<PressScale> {
  bool _down = false;
  @override
  Widget build(BuildContext context) => GestureDetector(
        behavior: HitTestBehavior.opaque,
        onTapDown: (_) => setState(() => _down = true),
        onTapCancel: () => setState(() => _down = false),
        onTapUp: (_) => setState(() => _down = false),
        onTap: widget.onTap,
        child: AnimatedScale(scale: _down && !reduceMotion(context) ? widget.scale : 1, duration: const Duration(milliseconds: 120), curve: Curves.easeOut, child: widget.child),
      );
}

/// Shimmering placeholder block for loading states.
class Skeleton extends StatefulWidget {
  final double? width, height;
  final double radius;
  const Skeleton({super.key, this.width, this.height, this.radius = 10});
  @override
  State<Skeleton> createState() => _SkeletonState();
}

class _SkeletonState extends State<Skeleton> with SingleTickerProviderStateMixin {
  late final AnimationController _c = AnimationController(vsync: this, duration: const Duration(milliseconds: 1300))..repeat();
  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final p = context.pm;
    return AnimatedBuilder(
      animation: _c,
      builder: (_, __) => Container(
        width: widget.width,
        height: widget.height,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(widget.radius),
          gradient: LinearGradient(colors: [p.card, p.border, p.card], stops: const [.25, .5, .75], begin: Alignment(-1.5 + 3 * _c.value, 0), end: Alignment(-.5 + 3 * _c.value, 0)),
        ),
      ),
    );
  }
}

/// Frosted-glass surface.
class Glass extends StatelessWidget {
  final Widget child;
  final double radius;
  final EdgeInsets padding;
  const Glass({super.key, required this.child, this.radius = 22, this.padding = const EdgeInsets.all(16)});
  @override
  Widget build(BuildContext context) {
    final dark = Theme.of(context).brightness == Brightness.dark;
    return ClipRRect(
      borderRadius: BorderRadius.circular(radius),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 14, sigmaY: 14),
        child: Container(
          padding: padding,
          decoration: BoxDecoration(color: (dark ? const Color(0xFF111319) : Colors.white).withOpacity(.78), borderRadius: BorderRadius.circular(radius), border: Border.all(color: (dark ? Colors.white : Colors.black).withOpacity(.08))),
          child: child,
        ),
      ),
    );
  }
}

/// Primary button: animated red gradient, spinner while working, check mark on success.
/// [onPressed] returns true on success (the check shows briefly, then [onSuccess] runs) or false/throws to stay idle.
class GradientButton extends StatefulWidget {
  final String label;
  final IconData? icon;
  final Future<bool> Function()? onPressed;
  final VoidCallback? onSuccess;
  final bool pulse;
  const GradientButton({super.key, required this.label, this.icon, this.onPressed, this.onSuccess, this.pulse = false});
  @override
  State<GradientButton> createState() => _GradientButtonState();
}

enum _Bs { idle, loading, done }

class _GradientButtonState extends State<GradientButton> with TickerProviderStateMixin {
  late final AnimationController _g = AnimationController(vsync: this, duration: const Duration(seconds: 3))..repeat(reverse: true);
  late final AnimationController _p = AnimationController(vsync: this, duration: const Duration(milliseconds: 1800))..repeat();
  _Bs _s = _Bs.idle;
  bool _down = false;

  @override
  void dispose() {
    _g.dispose();
    _p.dispose();
    super.dispose();
  }

  Future<void> _tap() async {
    if (_s != _Bs.idle || widget.onPressed == null) return;
    setState(() => _s = _Bs.loading);
    bool ok = false;
    try {
      ok = await widget.onPressed!();
    } catch (_) {
      ok = false;
    }
    if (!mounted) return;
    if (ok) {
      setState(() => _s = _Bs.done);
      await Future.delayed(const Duration(milliseconds: 650));
      if (mounted) widget.onSuccess?.call();
    } else {
      setState(() => _s = _Bs.idle);
    }
  }

  @override
  Widget build(BuildContext context) {
    final still = reduceMotion(context);
    return Semantics(
      button: true,
      label: widget.label,
      child: GestureDetector(
        onTapDown: (_) => setState(() => _down = true),
        onTapCancel: () => setState(() => _down = false),
        onTapUp: (_) => setState(() => _down = false),
        onTap: _tap,
        child: AnimatedScale(
          scale: _down && !still ? .97 : 1,
          duration: const Duration(milliseconds: 110),
          child: AnimatedBuilder(
            animation: Listenable.merge([_g, _p]),
            builder: (_, __) => Container(
              height: 50,
              alignment: Alignment.center,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(14),
                gradient: _s == _Bs.done
                    ? const LinearGradient(colors: [Color(0xFF1B873F), Color(0xFF2BA84F)])
                    : LinearGradient(colors: const [Pm.brand2, Pm.brand, Pm.brand2], begin: Alignment(-1 + 2 * _g.value, 0), end: Alignment(1 + 2 * _g.value, 0)),
                boxShadow: widget.pulse && !still && _s == _Bs.idle ? [BoxShadow(color: Pm.brand.withOpacity(.45 * (1 - _p.value)), blurRadius: 4 + 14 * _p.value, spreadRadius: 10 * _p.value)] : const [],
              ),
              child: AnimatedSwitcher(
                duration: const Duration(milliseconds: 220),
                child: switch (_s) {
                  _Bs.loading => const SizedBox(key: ValueKey('l'), width: 22, height: 22, child: CircularProgressIndicator(strokeWidth: 2.4, color: Colors.white)),
                  _Bs.done => const Icon(Icons.check_rounded, key: ValueKey('d'), color: Colors.white, size: 28),
                  _Bs.idle => Row(key: const ValueKey('i'), mainAxisSize: MainAxisSize.min, children: [
                      if (widget.icon != null) ...[Icon(widget.icon, color: Colors.white, size: 22), const SizedBox(width: 6)],
                      Text(widget.label, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700, fontSize: 15)),
                    ]),
                },
              ),
            ),
          ),
        ),
      ),
    );
  }
}

/// Carousel dots: the active one stretches into a pill.
class AnimatedDots extends StatelessWidget {
  final int count, index;
  final MainAxisAlignment align;
  const AnimatedDots({super.key, required this.count, required this.index, this.align = MainAxisAlignment.center});
  @override
  Widget build(BuildContext context) => Row(mainAxisAlignment: align, children: [
        for (var i = 0; i < count; i++)
          AnimatedContainer(
            duration: const Duration(milliseconds: 300),
            curve: Curves.easeOut,
            margin: const EdgeInsets.symmetric(horizontal: 2.5),
            width: i == index ? 18 : 6,
            height: 6,
            decoration: BoxDecoration(color: i == index ? Pm.brand : Colors.white38, borderRadius: BorderRadius.circular(3)),
          ),
      ]);
}

/// Pill selector whose highlight slides to the chosen item.
class SlidingSegments extends StatelessWidget {
  final List<String> labels;
  final int selected;
  final ValueChanged<int> onChanged;
  const SlidingSegments({super.key, required this.labels, required this.selected, required this.onChanged});
  @override
  Widget build(BuildContext context) {
    final p = context.pm;
    return Container(
      padding: const EdgeInsets.all(3),
      decoration: BoxDecoration(color: p.card2, borderRadius: BorderRadius.circular(14)),
      child: LayoutBuilder(builder: (_, c) {
        final w = (c.maxWidth) / labels.length;
        return Stack(children: [
          AnimatedPositioned(duration: const Duration(milliseconds: 300), curve: Curves.easeOutCubic, left: w * selected, width: w, top: 0, bottom: 0, child: Container(decoration: BoxDecoration(color: Pm.brand, borderRadius: BorderRadius.circular(11)))),
          Row(children: [
            for (var i = 0; i < labels.length; i++)
              Expanded(child: GestureDetector(behavior: HitTestBehavior.opaque, onTap: () => onChanged(i), child: Padding(padding: const EdgeInsets.symmetric(vertical: 9), child: Center(child: AnimatedDefaultTextStyle(duration: const Duration(milliseconds: 250), style: TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: i == selected ? Colors.white : p.muted), child: Text(labels[i])))))),
          ]),
        ]);
      }),
    );
  }
}

/// Text that shows a few lines and expands smoothly on "Read more".
class ExpandableText extends StatefulWidget {
  final String text;
  final int lines;
  const ExpandableText(this.text, {super.key, this.lines = 4});
  @override
  State<ExpandableText> createState() => _ExpandableTextState();
}

class _ExpandableTextState extends State<ExpandableText> {
  bool _open = false;
  @override
  Widget build(BuildContext context) {
    final style = TextStyle(color: context.pm.muted, height: 1.6);
    return LayoutBuilder(builder: (_, c) {
      final tp = TextPainter(text: TextSpan(text: widget.text, style: style), maxLines: widget.lines, textDirection: TextDirection.ltr)..layout(maxWidth: c.maxWidth);
      final overflow = tp.didExceedMaxLines;
      return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        AnimatedSize(duration: const Duration(milliseconds: 350), curve: Curves.easeOutCubic, alignment: Alignment.topCenter, child: Text(widget.text, style: style, maxLines: _open ? null : widget.lines, overflow: _open ? TextOverflow.visible : TextOverflow.ellipsis)),
        if (overflow) GestureDetector(onTap: () => setState(() => _open = !_open), child: Padding(padding: const EdgeInsets.only(top: 6), child: Text(_open ? 'Show less' : 'Read more', style: const TextStyle(color: Pm.brand2, fontWeight: FontWeight.w700)))),
      ]);
    });
  }
}

/// Slowly drifting poster tiles used behind the sign-in screens. Uses real posters when given, soft colour blocks otherwise.
class DriftingPosters extends StatefulWidget {
  final List<String?> posters;
  const DriftingPosters({super.key, this.posters = const []});
  @override
  State<DriftingPosters> createState() => _DriftingPostersState();
}

class _DriftingPostersState extends State<DriftingPosters> with SingleTickerProviderStateMixin {
  late final AnimationController _c = AnimationController(vsync: this, duration: const Duration(seconds: 18))..repeat(reverse: true);
  static const _tints = [Color(0xFF26364D), Color(0xFF4D2634), Color(0xFF264D3A), Color(0xFF4D4226), Color(0xFF3A2650), Color(0xFF264D4D)];
  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _c,
      builder: (_, __) => Transform.translate(
        offset: Offset(0, -90 * _c.value),
        child: Transform.rotate(
          angle: -.14,
          child: OverflowBox(
            maxWidth: MediaQuery.of(context).size.width * 1.5,
            maxHeight: MediaQuery.of(context).size.height * 1.5,
            child: Opacity(
              opacity: .5,
              child: Wrap(spacing: 10, runSpacing: 10, children: [
                for (var i = 0; i < 18; i++) Container(width: 100, height: 150, decoration: BoxDecoration(color: _tints[i % _tints.length], borderRadius: BorderRadius.circular(12))),
              ]),
            ),
          ),
        ),
      ),
    );
  }
}
