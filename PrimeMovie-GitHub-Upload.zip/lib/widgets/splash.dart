import 'dart:math' as math;
import 'package:flutter/material.dart';
import '../core/theme.dart';
import 'anim.dart';

/// First-launch splash: the PrimeMovie logo pops in with a red glow and a light sweep, the name and tagline fade up,
/// and a loading bar fills at the bottom. Fades out and calls [onDone]. Shortened when the phone has reduce-motion on.
class SplashOverlay extends StatefulWidget {
  final VoidCallback onDone;
  const SplashOverlay({super.key, required this.onDone});
  @override
  State<SplashOverlay> createState() => _SplashOverlayState();
}

class _SplashOverlayState extends State<SplashOverlay> with SingleTickerProviderStateMixin {
  late final AnimationController _c = AnimationController(vsync: this);
  bool _started = false;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    if (_started) return;
    _started = true;
    _c.duration = Duration(milliseconds: reduceMotion(context) ? 700 : 3000);
    _c.forward().whenComplete(() {
      if (mounted) widget.onDone();
    });
  }

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final pal = PmPalette.dark;
    return Directionality(
      textDirection: TextDirection.ltr,
      child: AnimatedBuilder(
        animation: _c,
        builder: (context, _) {
          final t = _c.value;
          double iv(double a, double b, [Curve curve = Curves.linear]) => curve.transform(((t - a) / (b - a)).clamp(0.0, 1.0));

          final pop = iv(0.0, 0.4, Curves.easeOutBack);
          final logoFade = iv(0.0, 0.25, Curves.easeOut);
          final glow = (iv(0.05, 0.45, Curves.easeOut) * (0.75 + 0.25 * math.sin(t * math.pi * 6))).clamp(0.0, 1.0);
          final sweep = -0.3 + 1.6 * iv(0.42, 0.78, Curves.easeInOut);
          final nameIn = iv(0.35, 0.6, Curves.easeOutCubic);
          final bar = iv(0.05, 0.9, Curves.easeInOut);
          final barVisible = iv(0.05, 0.25);
          final out = 1.0 - iv(0.88, 1.0, Curves.easeIn);

          return Opacity(
            opacity: out,
            child: Material(
              color: pal.bg,
              child: Stack(
                fit: StackFit.expand,
                children: [
                  // soft red glow behind the logo
                  Align(
                    child: Container(
                      width: 300,
                      height: 300,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        gradient: RadialGradient(colors: [Pm.brand.withOpacity(0.38 * glow), Pm.brand.withOpacity(0)]),
                      ),
                    ),
                  ),
                  // logo (black artwork tinted white, with a red light sweep)
                  Align(
                    child: Opacity(
                      opacity: logoFade,
                      child: Transform.scale(
                        scale: 0.55 + 0.45 * pop,
                        child: ShaderMask(
                          blendMode: BlendMode.srcIn,
                          shaderCallback: (rect) => LinearGradient(
                            colors: const [Colors.white, Colors.white, Pm.brand2, Colors.white, Colors.white],
                            stops: [0, (sweep - 0.2).clamp(0.0, 1.0), sweep.clamp(0.0, 1.0), (sweep + 0.2).clamp(0.0, 1.0), 1],
                          ).createShader(rect),
                          child: Image.asset(
                            'assets/logo.png',
                            width: 120,
                            height: 120,
                            fit: BoxFit.contain,
                            filterQuality: FilterQuality.high,
                            errorBuilder: (_, __, ___) => const Icon(Icons.movie_outlined, size: 96, color: Colors.white),
                          ),
                        ),
                      ),
                    ),
                  ),
                  // name + tagline
                  Align(
                    alignment: const Alignment(0, 0.32),
                    child: Opacity(
                      opacity: nameIn,
                      child: Transform.translate(
                        offset: Offset(0, 14 * (1 - nameIn)),
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            const Text('PrimeMovie', style: TextStyle(color: Pm.brand, fontSize: 28, fontWeight: FontWeight.w800, letterSpacing: 0.5)),
                            const SizedBox(height: 6),
                            Text('Unlimited movies, anywhere', style: TextStyle(color: pal.muted, fontSize: 14)),
                          ],
                        ),
                      ),
                    ),
                  ),
                  // loading bar at the bottom
                  Positioned(
                    left: 56,
                    right: 56,
                    bottom: MediaQuery.paddingOf(context).bottom + 56,
                    child: Opacity(
                      opacity: barVisible,
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          ClipRRect(
                            borderRadius: BorderRadius.circular(4),
                            child: SizedBox(
                              height: 4,
                              child: Stack(
                                children: [
                                  Container(color: Colors.white.withOpacity(0.10)),
                                  FractionallySizedBox(
                                    widthFactor: bar,
                                    alignment: Alignment.centerLeft,
                                    child: Container(decoration: const BoxDecoration(gradient: Pm.brandGradient)),
                                  ),
                                ],
                              ),
                            ),
                          ),
                          const SizedBox(height: 14),
                          Text('Loading…', style: TextStyle(color: pal.muted, fontSize: 12, letterSpacing: 1.2)),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}
