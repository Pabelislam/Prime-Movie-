import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../core/api_client.dart';
import '../core/config.dart';
import '../core/theme.dart';
import '../providers.dart';
import '../widgets/anim.dart';
import '../widgets/common.dart';
import 'detail_screen.dart';

class LibraryScreen extends ConsumerWidget {
  const LibraryScreen({super.key});
  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final auth = ref.watch(authProvider);
    if (auth.loading) return const Scaffold(body: LoadingView());
    if (!auth.signedIn) {
      return Scaffold(
        appBar: AppBar(title: const Text('My library')),
        body: EmptyView(
          icon: Icons.bookmarks_outlined,
          title: 'Sign in to see your library',
          message: auth.error ?? 'Your watchlist, favorites and history sync with the website.',
          action: FilledButton(onPressed: () => context.push('/login'), child: const Text('Sign in')),
        ),
      );
    }
    return DefaultTabController(
      length: 3,
      child: Scaffold(
        appBar: AppBar(title: const Text('My library'), bottom: const TabBar(indicatorColor: Pm.brand, tabs: [Tab(text: 'Watchlist'), Tab(text: 'Favorites'), Tab(text: 'History')])),
        body: const TabBarView(children: [_ListTab('watchlist'), _ListTab('favorites'), _ListTab('recent')]),
      ),
    );
  }
}

class _ListTab extends ConsumerWidget {
  final String type;
  const _ListTab(this.type);
  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final async = ref.watch(libraryProvider(type));
    return RefreshIndicator(
      color: Pm.brand,
      onRefresh: () async {
        ref.invalidate(libraryProvider(type));
        ref.invalidate(watchlistIdsProvider);
        ref.invalidate(favoriteIdsProvider);
        try {
          await ref.read(libraryProvider(type).future);
        } catch (_) {/* the error view below shows the failure */}
      },
      child: async.when(
        loading: () => const LoadingView(),
        error: (e, _) => ListView(children: [SizedBox(height: 400, child: ErrorView(error: e, onRetry: () => ref.invalidate(libraryProvider(type))))]),
        data: (p) => p.items.isEmpty
            ? ListView(children: [SizedBox(height: 400, child: EmptyView(icon: Icons.movie_outlined, title: type == 'recent' ? 'No history yet' : 'Nothing saved yet', message: type == 'recent' ? 'Movies you open will appear here.' : 'Use the buttons on a movie page to add it.'))])
            : CustomScrollView(slivers: [
                if (type == 'recent')
                  SliverToBoxAdapter(
                    child: Align(
                      alignment: Alignment.centerRight,
                      child: TextButton(
                        onPressed: () async {
                          final ok = await showDialog<bool>(
                            context: context,
                            builder: (c) => AlertDialog(
                              title: const Text('Clear history?'),
                              content: const Text('This removes your viewing history from the website and the app.'),
                              actions: [TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('Cancel')), TextButton(onPressed: () => Navigator.pop(c, true), child: const Text('Clear'))],
                            ),
                          );
                          if (ok == true) {
                            await ref.read(accountRepoProvider).clearRecent();
                            ref.invalidate(libraryProvider('recent'));
                          }
                        },
                        child: const Text('Clear history'),
                      ),
                    ),
                  ),
                SliverPadding(
                  padding: const EdgeInsets.fromLTRB(16, 16, 16, 110),
                  sliver: SliverGrid(gridDelegate: posterGrid(context), delegate: SliverChildBuilderDelegate((_, i) => FadeUp(index: i % 6, child: MovieCard(movie: p.items[i])), childCount: p.items.length)),
                ),
              ]),
      ),
    );
  }
}

class ProfileScreen extends ConsumerWidget {
  const ProfileScreen({super.key});

  Future<void> _link(BuildContext context, String path) => openExternal(context, '${AppConfig.siteOrigin}/$path');

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final auth = ref.watch(authProvider);
    final cfg = ref.watch(configProvider).valueOrNull;
    final u = auth.user;
    return Scaffold(
      appBar: AppBar(title: const Text('Profile')),
      body: ListView(children: [
        if (u == null)
          FadeUp(child: Padding(padding: const EdgeInsets.all(16), child: Container(padding: const EdgeInsets.all(18), decoration: BoxDecoration(color: context.pm.card, borderRadius: BorderRadius.circular(18), border: Border.all(color: context.pm.border)), child: Row(children: [Icon(Icons.person_outline, size: 36, color: context.pm.muted), const SizedBox(width: 12), const Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('Not signed in', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 16)), SizedBox(height: 2), Text('Sign in to sync your library', style: TextStyle(fontSize: 12))])), SizedBox(width: 120, child: GradientButton(label: 'Sign in', onPressed: () async { context.push('/login'); return false; }))]))))
        else ...[
          FadeUp(child: _ProfileHeader(name: u.displayName, email: u.email)),
          FadeUp(index: 1, child: ListTile(leading: const Icon(Icons.edit_outlined), title: const Text('Edit display name'), onTap: () => _editName(context, ref))),
          FadeUp(index: 2, child: ListTile(leading: const Icon(Icons.lock_outline), title: const Text('Change password'), onTap: () => _changePassword(context, ref))),
          FadeUp(index: 3, child: ListTile(leading: const Icon(Icons.rate_review_outlined), title: const Text('My reviews'), onTap: () => context.push('/my-reviews'))),
          const FadeUp(index: 4, child: _NotificationsSwitch()),
        ],
        const Divider(),
        ListTile(leading: const Icon(Icons.settings_outlined), title: const Text('Settings'), subtitle: const Text('Theme, download location, Wi-Fi only, subtitles'), trailing: const Icon(Icons.chevron_right), onTap: () => context.push('/settings')),
        ListTile(leading: const Icon(Icons.info_outline), title: const Text('About'), trailing: const Icon(Icons.open_in_new, size: 18), onTap: () => _link(context, 'about')),
        ListTile(leading: const Icon(Icons.mail_outline), title: const Text('Contact'), trailing: const Icon(Icons.open_in_new, size: 18), onTap: () => _link(context, 'contact')),
        ListTile(leading: const Icon(Icons.privacy_tip_outlined), title: const Text('Privacy policy'), trailing: const Icon(Icons.open_in_new, size: 18), onTap: () => _link(context, 'privacy-policy')),
        ListTile(leading: const Icon(Icons.copyright), title: const Text('Copyright / content removal'), trailing: const Icon(Icons.open_in_new, size: 18), onTap: () => _link(context, 'copyright')),
        if (u != null) ...[
          const Divider(),
          ListTile(leading: const Icon(Icons.logout), title: const Text('Sign out'), onTap: () => ref.read(authProvider.notifier).logout()),
          ListTile(leading: const Icon(Icons.devices_other), title: const Text('Sign out on all devices'), onTap: () => ref.read(authProvider.notifier).logoutAll()),
        ],
        Padding(padding: const EdgeInsets.all(16), child: Text('${cfg?.siteName ?? 'PrimeMovie'} • v1.0.0', textAlign: TextAlign.center, style: TextStyle(color: context.pm.muted, fontSize: 12))),
      ]),
    );
  }

  Future<void> _editName(BuildContext context, WidgetRef ref) async {
    final c = TextEditingController(text: ref.read(authProvider).user?.displayName);
    final name = await showDialog<String>(
      context: context,
      builder: (d) => AlertDialog(
        title: const Text('Display name'),
        content: TextField(controller: c, maxLength: 60, autofocus: true),
        actions: [TextButton(onPressed: () => Navigator.pop(d), child: const Text('Cancel')), TextButton(onPressed: () => Navigator.pop(d, c.text.trim()), child: const Text('Save'))],
      ),
    );
    c.dispose();
    if (name == null || name.length < 2) return;
    try {
      ref.read(authProvider.notifier).setUser(await ref.read(accountRepoProvider).updateName(name));
    } on ApiError catch (e) {
      if (context.mounted) toast(context, e.fieldMessage('display_name') ?? e.message);
    }
  }

  Future<void> _changePassword(BuildContext context, WidgetRef ref) async {
    final cur = TextEditingController(), next = TextEditingController();
    final ok = await showDialog<bool>(
      context: context,
      builder: (d) => AlertDialog(
        title: const Text('Change password'),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          TextField(controller: cur, obscureText: true, decoration: const InputDecoration(hintText: 'Current password')),
          const SizedBox(height: 8),
          TextField(controller: next, obscureText: true, decoration: const InputDecoration(hintText: 'New password (8+, letters and numbers)')),
        ]),
        actions: [TextButton(onPressed: () => Navigator.pop(d, false), child: const Text('Cancel')), TextButton(onPressed: () => Navigator.pop(d, true), child: const Text('Change'))],
      ),
    );
    final a = cur.text, b = next.text;
    cur.dispose();
    next.dispose();
    if (ok != true) return;
    try {
      await ref.read(accountRepoProvider).changePassword(a, b);
      if (context.mounted) toast(context, 'Password changed. Other devices were signed out.');
    } on ApiError catch (e) {
      if (context.mounted) toast(context, e.fieldMessage('new_password') ?? e.fieldMessage('current_password') ?? e.message);
    }
  }
}

class _NotificationsSwitch extends ConsumerStatefulWidget {
  const _NotificationsSwitch();
  @override
  ConsumerState<_NotificationsSwitch> createState() => _NotifState();
}

class _NotifState extends ConsumerState<_NotificationsSwitch> {
  bool? value;
  @override
  void initState() {
    super.initState();
    ref.read(accountRepoProvider).preferences().then((p) { if (mounted) setState(() => value = p['notifications'] == true); }).catchError((_) {});
  }

  @override
  Widget build(BuildContext context) => SwitchListTile(
        secondary: const Icon(Icons.notifications_none),
        title: const Text('Notifications preference'),
        subtitle: const Text('Saved to your account'),
        value: value ?? false,
        onChanged: value == null ? null : (v) async {
          final repo = ref.read(accountRepoProvider);
          try {
            final p = await repo.preferences();
            p['notifications'] = v;
            await repo.savePreferences(p); // PUT replaces all keys, so merge first
            setState(() => value = v);
          } on ApiError catch (e) {
            if (context.mounted) toast(context, e.message);
          }
        },
      );
}

class MyReviewsScreen extends ConsumerWidget {
  const MyReviewsScreen({super.key});
  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return Scaffold(
      appBar: AppBar(title: const Text('My reviews')),
      body: FutureBuilder(
        future: ref.read(accountRepoProvider).myReviews(),
        builder: (c, s) {
          if (s.connectionState != ConnectionState.done) return const LoadingView();
          if (s.hasError) return ErrorView(error: s.error!, onRetry: () => (c as Element).markNeedsBuild());
          final list = s.data!;
          if (list.isEmpty) return const EmptyView(icon: Icons.rate_review_outlined, title: 'No reviews yet');
          return ListView(children: [
            for (final r in list)
              ListTile(
                onTap: r.movieSlug == null ? null : () => context.push('/movie/${r.movieSlug}'),
                title: Text(r.movieTitle ?? 'Movie'),
                subtitle: Text('${'★' * r.rating}  ${r.status ?? ''}\n${r.body}', maxLines: 3, overflow: TextOverflow.ellipsis),
                isThreeLine: true,
              ),
          ]);
        },
      ),
    );
  }
}


/// Banner with a slowly moving red gradient and an avatar that pops in.
class _ProfileHeader extends StatefulWidget {
  final String name, email;
  const _ProfileHeader({required this.name, required this.email});
  @override
  State<_ProfileHeader> createState() => _ProfileHeaderState();
}

class _ProfileHeaderState extends State<_ProfileHeader> with SingleTickerProviderStateMixin {
  late final AnimationController _c = AnimationController(vsync: this, duration: const Duration(seconds: 6))..repeat(reverse: true);
  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final p = context.pm;
    return Column(children: [
      AnimatedBuilder(animation: _c, builder: (_, __) => Container(height: 120, decoration: BoxDecoration(gradient: LinearGradient(begin: Alignment(-1 + _c.value, -1), end: Alignment(1, 1 - _c.value), colors: [Pm.brand, p.bg])))),
      Transform.translate(
        offset: const Offset(0, -42),
        child: Column(children: [
          TweenAnimationBuilder<double>(
            tween: Tween(begin: 0, end: 1),
            duration: const Duration(milliseconds: 600),
            curve: Curves.easeOutBack,
            builder: (_, v, child) => Transform.scale(scale: v, child: child),
            child: Container(width: 84, height: 84, alignment: Alignment.center, decoration: BoxDecoration(shape: BoxShape.circle, color: p.bg, border: Border.all(color: Pm.brand, width: 3)), child: Text(widget.name.isEmpty ? '?' : widget.name[0].toUpperCase(), style: const TextStyle(fontSize: 32, fontWeight: FontWeight.w800))),
          ),
          const SizedBox(height: 8),
          Text(widget.name, style: const TextStyle(fontSize: 19, fontWeight: FontWeight.w800)),
          Text(widget.email, style: TextStyle(color: p.muted, fontSize: 12)),
        ]),
      ),
      const SizedBox(height: 0),
    ]);
  }
}
