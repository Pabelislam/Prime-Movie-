import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../core/theme.dart';
import '../data/downloads.dart';
import '../data/models.dart';
import '../data/settings.dart';
import '../data/storage_info.dart';
import '../widgets/anim.dart';
import '../widgets/common.dart';

class SettingsScreen extends ConsumerWidget {
  const SettingsScreen({super.key});

  Future<bool> _confirm(BuildContext context, String title, String body, String action) async =>
      await showDialog<bool>(
        context: context,
        builder: (c) => AlertDialog(
          title: Text(title),
          content: Text(body),
          actions: [TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('Cancel')), TextButton(onPressed: () => Navigator.pop(c, true), child: Text(action))],
        ),
      ) ??
      false;

  Widget _head(BuildContext context, String t) => Padding(padding: const EdgeInsets.fromLTRB(16, 20, 16, 6), child: Text(t, style: TextStyle(color: context.pm.muted, fontSize: 12, fontWeight: FontWeight.w800, letterSpacing: .6)));

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final s = ref.watch(settingsProvider).valueOrNull ?? const AppSettings();
    final n = ref.read(settingsProvider.notifier);
    final volumes = ref.watch(storageVolumesProvider).valueOrNull ?? const [StorageVolume('phone', 'Phone storage', null)];
    final hasSd = volumes.any((v) => v.id == 'sd');
    final downloads = ref.watch(downloadsProvider);
    final used = downloads.where((d) => d.path != null).fold<int>(0, (sum, d) {
      try {
        return sum + File(d.path!).lengthSync();
      } catch (_) {
        return sum;
      }
    });
    final gallery = ref.watch(saveToGalleryProvider).valueOrNull ?? false;

    return Scaffold(
      appBar: AppBar(title: const Text('Settings')),
      body: _stagger([
        _head(context, 'APPEARANCE'),
        ListTile(
          leading: const Icon(Icons.palette_outlined),
          title: const Text('Theme'),
          subtitle: SegmentedButton<ThemeMode>(
            style: const ButtonStyle(visualDensity: VisualDensity.compact),
            segments: const [
              ButtonSegment(value: ThemeMode.dark, label: Text('Dark'), icon: Icon(Icons.dark_mode_outlined)),
              ButtonSegment(value: ThemeMode.light, label: Text('Light'), icon: Icon(Icons.light_mode_outlined)),
              ButtonSegment(value: ThemeMode.system, label: Text('System'), icon: Icon(Icons.phone_android)),
            ],
            selected: {s.themeMode},
            onSelectionChanged: (v) => n.updateSettings((x) => x.copyWith(themeMode: v.first)),
          ),
        ),
        _head(context, 'DOWNLOADS'),
        ListTile(
          leading: const Icon(Icons.sd_storage_outlined),
          title: const Text('Download location'),
          subtitle: RadioGroupLike(
            value: s.downloadLocation,
            options: [('phone', 'Phone storage', true), ('sd', hasSd ? 'SD card' : 'SD card (not detected)', hasSd)],
            onChanged: (v) => n.updateSettings((x) => x.copyWith(downloadLocation: v)),
          ),
        ),
        const Padding(padding: EdgeInsets.fromLTRB(72, 0, 16, 8), child: Text('Applies to new downloads. Files stay private to this app either way.', style: TextStyle(fontSize: 12))),
        SwitchListTile(
          secondary: const Icon(Icons.wifi),
          title: const Text('Download over Wi-Fi only'),
          subtitle: const Text('Pauses downloads on mobile data'),
          value: s.wifiOnly,
          onChanged: (v) => n.updateSettings((x) => x.copyWith(wifiOnly: v)),
        ),
        SwitchListTile(
          secondary: const Icon(Icons.video_library_outlined),
          title: const Text('Also save a copy to Movies/PrimeMovie'),
          subtitle: const Text('Lets Gallery, MX Player and PlayIt see new downloads'),
          value: gallery,
          onChanged: (v) => ref.read(saveToGalleryProvider.notifier).set(v),
        ),
        FutureBuilder<int?>(
          future: freeSpaceBytes(),
          builder: (c, snap) => snap.data == null ? const SizedBox.shrink() : ListTile(leading: const Icon(Icons.storage_outlined), title: const Text('Free space on phone'), subtitle: Text(formatBytes(snap.data))),
        ),
        ListTile(
          leading: const Icon(Icons.folder_outlined),
          title: const Text('Downloaded movies'),
          subtitle: Text('${downloads.where((d) => d.status == DlStatus.completed).length} on this device • ${formatBytes(used).isEmpty ? '0 B' : formatBytes(used)} used'),
        ),
        ListTile(
          leading: const Icon(Icons.delete_sweep_outlined, color: Pm.errorRed),
          title: const Text('Delete all downloads', style: TextStyle(color: Pm.errorRed)),
          onTap: () async {
            if (downloads.isEmpty) {
              toast(context, 'There are no downloads to delete.');
              return;
            }
            if (await _confirm(context, 'Delete all downloads?', 'Every downloaded movie and its subtitles will be removed from your phone.', 'Delete all')) {
              final d = ref.read(downloadsProvider.notifier);
              for (final i in List.of(ref.read(downloadsProvider))) {
                await d.remove(i.id);
              }
              if (context.mounted) toast(context, 'All downloads deleted.');
            }
          },
        ),
        _head(context, 'PLAYBACK'),
        ListTile(
          leading: const Icon(Icons.closed_caption_outlined),
          title: const Text('Subtitle size'),
          subtitle: SegmentedButton<SubtitleSize>(
            style: const ButtonStyle(visualDensity: VisualDensity.compact),
            segments: const [
              ButtonSegment(value: SubtitleSize.small, label: Text('Small')),
              ButtonSegment(value: SubtitleSize.medium, label: Text('Medium')),
              ButtonSegment(value: SubtitleSize.large, label: Text('Large')),
            ],
            selected: {s.subtitleSize},
            onSelectionChanged: (v) => n.updateSettings((x) => x.copyWith(subtitleSize: v.first)),
          ),
        ),
        _head(context, 'DATA'),
        ListTile(
          leading: const Icon(Icons.cleaning_services_outlined),
          title: const Text('Clear cache'),
          subtitle: const Text('Removes saved lists and images. Downloads and settings are kept.'),
          onTap: () async {
            await clearContentCache(ref);
            if (context.mounted) toast(context, 'Cache cleared.');
          },
        ),
        ListTile(
          leading: const Icon(Icons.history_toggle_off),
          title: const Text('Forget playback positions'),
          subtitle: const Text('Movies will start from the beginning next time'),
          onTap: () async {
            if (await _confirm(context, 'Forget positions?', 'Saved resume points on this device will be removed.', 'Forget')) {
              await clearWatchPositions(ref);
              if (context.mounted) toast(context, 'Playback positions cleared.');
            }
          },
        ),
        _head(context, 'ABOUT'),
        const ListTile(leading: Icon(Icons.info_outline), title: Text('PrimeMovie'), subtitle: Text('Version 1.0.0')),
        const SizedBox(height: 24),
      ]),
    );
  }
}

Widget _stagger(List<Widget> c) => ListView(padding: const EdgeInsets.only(bottom: 110), children: [for (var k = 0; k < c.length; k++) FadeUp(index: k, child: c[k])]);

/// Small radio list used for the storage choice (kept simple so a missing SD card is shown disabled, not hidden).
class RadioGroupLike extends StatelessWidget {
  final String value;
  final List<(String, String, bool)> options; // id, label, enabled
  final ValueChanged<String> onChanged;
  const RadioGroupLike({super.key, required this.value, required this.options, required this.onChanged});

  @override
  Widget build(BuildContext context) => Column(children: [
        for (final o in options)
          InkWell(
            onTap: o.$3 ? () => onChanged(o.$1) : null,
            child: Padding(
              padding: const EdgeInsets.symmetric(vertical: 6),
              child: Row(children: [
                Icon(value == o.$1 ? Icons.radio_button_checked : Icons.radio_button_off, size: 20, color: !o.$3 ? context.pm.muted.withOpacity(.4) : (value == o.$1 ? Pm.brand : context.pm.muted)),
                const SizedBox(width: 10),
                Text(o.$2, style: TextStyle(color: o.$3 ? null : context.pm.muted.withOpacity(.6))),
              ]),
            ),
          ),
      ]);
}
