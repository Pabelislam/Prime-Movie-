import 'dart:async';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../core/theme.dart';
import '../data/models.dart';
import '../data/repositories.dart';
import '../providers.dart';
import '../widgets/anim.dart';
import '../widgets/common.dart';

class HomeScreen extends ConsumerStatefulWidget {
  const HomeScreen({super.key});
  @override
  ConsumerState<HomeScreen> createState() => _HomeState();
}

class _HomeState extends ConsumerState<HomeScreen> {
  int _tab = 0; // 0 = All, 1.. = a category

  Future<void> _refresh() async {
    await ref.read(contentRepoProvider).invalidateContent();
    ref.invalidate(configProvider);
    ref.invalidate(categoriesProvider);
    ref.invalidate(recommendationsProvider);
    ref.invalidate(libraryProvider('recent'));
    for (final k in const ['featured', 'trending', 'popular', 'latest']) {
      ref.invalidate(collectionProvider(k));
    }
    try {
      await ref.read(collectionProvider('latest').future);
    } catch (_) {/* error view handles it */}
  }

  @override
  Widget build(BuildContext context) {
    final cfg = ref.watch(configProvider).valueOrNull ?? RemoteConfig.defaults;
    final latest = ref.watch(collectionProvider('latest'));
    final featured = ref.watch(collectionProvider('featured')).valueOrNull?.items ?? const <Movie>[];
    final signedIn = ref.watch(authProvider).signedIn;
    final recent = signedIn ? (ref.watch(libraryProvider('recent')).valueOrNull?.items ?? const <Movie>[]) : const <Movie>[];

    final cats = ref.watch(categoriesProvider).valueOrNull ?? const <Genre>[];
    final user = ref.watch(authProvider).user;
    final tab = _tab.clamp(0, cats.length);

    return Scaffold(
      body: SafeArea(
        bottom: false,
        child: RefreshIndicator(
          color: Pm.brand,
          onRefresh: _refresh,
          child: latest.when(
            loading: () => const _HomeSkeleton(),
            error: (e, _) => ListView(children: [SizedBox(height: 520, child: ErrorView(error: e, onRetry: _refresh))]),
            data: (l) {
              final heroMovies = (featured.isNotEmpty ? featured : l.items).take(5).toList();
              var i = 0;
              Widget section(Widget w) => FadeUp(index: i++, child: w);
              return ListView(padding: const EdgeInsets.only(bottom: 120), children: [
                if (l.fromCache) const OfflineBanner(),
                FadeUp(child: _Greeting(name: user?.displayName, signedIn: signedIn)),
                FadeUp(index: 1, child: const _SearchBar()),
                FadeUp(index: 2, child: _Tabs(labels: ['All', for (final c in cats) c.name], selected: tab, onChanged: (v) => setState(() => _tab = v))),
                const SizedBox(height: 14),
                AnimatedSwitcher(
                  duration: const Duration(milliseconds: 320),
                  transitionBuilder: (c, a) => FadeTransition(opacity: a, child: c),
                  child: tab > 0
                      ? KeyedSubtree(key: ValueKey('cat-$tab'), child: _CategoryResults(genre: cats[tab - 1]))
                      : Column(key: const ValueKey('all'), crossAxisAlignment: CrossAxisAlignment.start, children: [
                          _HeroCarousel(movies: heroMovies),
                          if (recent.isNotEmpty) section(_Section(title: 'Recently watched', movies: recent.take(10).toList())),
                          section(_SectionAsync(title: 'Recently added', async: latest, more: () => context.push('/browse?sort=latest&title=Recently%20added'))),
                          section(_SectionAsync(title: 'Trending this week', async: ref.watch(collectionProvider('trending')), hideWhenEmpty: true)),
                          section(_SectionAsync(title: 'Popular', async: ref.watch(collectionProvider('popular')), hideWhenEmpty: true, more: () => context.push('/browse?sort=popularity&title=Popular'))),
                          if (signedIn && cfg.recommendations) section(const _Recommended()),
                        ]),
                ),
              ]);
            },
          ),
        ),
      ),
    );
  }
}

/// "Welcome back / Hello, Sam" row with the avatar; tapping it opens Profile (or Sign in for guests).
class _Greeting extends StatelessWidget {
  final String? name;
  final bool signedIn;
  const _Greeting({required this.name, required this.signedIn});
  @override
  Widget build(BuildContext context) {
    final p = context.pm;
    final first = (name ?? '').trim().split(RegExp(r'\s+')).first;
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 10, 8, 4),
      child: Row(children: [
        PressScale(
          onTap: () => signedIn ? context.go('/profile') : context.push('/login'),
          child: TweenAnimationBuilder<double>(
            tween: Tween(begin: 0, end: 1),
            duration: reduceMotion(context) ? Duration.zero : const Duration(milliseconds: 550),
            curve: Curves.easeOutBack,
            builder: (_, v, child) => Transform.scale(scale: v, child: child),
            child: Container(width: 44, height: 44, alignment: Alignment.center, decoration: const BoxDecoration(shape: BoxShape.circle, color: Pm.brand), child: signedIn && first.isNotEmpty ? Text(first[0].toUpperCase(), style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 18)) : const Icon(Icons.person_outline, color: Colors.white)),
          ),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(signedIn ? 'Welcome back' : 'Welcome', style: TextStyle(color: p.muted, fontSize: 12)),
            Text(signedIn && first.isNotEmpty ? 'Hello, $first' : 'Hello, Guest', maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 19, fontWeight: FontWeight.w800)),
          ]),
        ),
        IconButton(tooltip: 'Downloads', icon: const Icon(Icons.download_for_offline_outlined), onPressed: () => context.go('/downloads')),
      ]),
    );
  }
}

/// Pill search field (opens Search) whose hint types itself out.
class _SearchBar extends StatefulWidget {
  const _SearchBar();
  @override
  State<_SearchBar> createState() => _SearchBarState();
}

class _SearchBarState extends State<_SearchBar> {
  static const _hint = 'Search movies, genres…';
  int _n = 0;
  Timer? _t;

  @override
  void initState() {
    super.initState();
    _t = Timer.periodic(const Duration(milliseconds: 110), (_) {
      if (!mounted) return;
      setState(() => _n = (_n + 1) % (_hint.length + 14)); // types, pauses, restarts
    });
  }

  @override
  void dispose() {
    _t?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final p = context.pm;
    final shown = reduceMotion(context) ? _hint : _hint.substring(0, _n.clamp(0, _hint.length));
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 10, 16, 6),
      child: PressScale(
        scale: .985,
        onTap: () => context.go('/search'),
        child: Semantics(
          button: true,
          label: 'Search',
          child: Container(
            height: 48,
            padding: const EdgeInsets.symmetric(horizontal: 16),
            decoration: BoxDecoration(color: p.card2, borderRadius: BorderRadius.circular(24), border: Border.all(color: p.border)),
            child: Row(children: [
              Icon(Icons.search, color: p.muted, size: 20),
              const SizedBox(width: 8),
              Text(shown, style: TextStyle(color: p.muted)),
              Text(_n % 2 == 0 ? '|' : ' ', style: TextStyle(color: p.muted)),
            ]),
          ),
        ),
      ),
    );
  }
}

/// Category tabs with an underline that grows under the selected one.
class _Tabs extends StatelessWidget {
  final List<String> labels;
  final int selected;
  final ValueChanged<int> onChanged;
  const _Tabs({required this.labels, required this.selected, required this.onChanged});
  @override
  Widget build(BuildContext context) {
    final p = context.pm;
    return Container(
      height: 44,
      decoration: BoxDecoration(border: Border(bottom: BorderSide(color: p.border))),
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 16),
        itemCount: labels.length,
        separatorBuilder: (_, __) => const SizedBox(width: 22),
        itemBuilder: (_, i) {
          final on = i == selected;
          return Semantics(
            button: true,
            selected: on,
            child: GestureDetector(
              behavior: HitTestBehavior.opaque,
              onTap: () => onChanged(i),
              child: IntrinsicWidth(
                child: Column(mainAxisAlignment: MainAxisAlignment.end, children: [
                  Expanded(child: Center(child: AnimatedDefaultTextStyle(duration: const Duration(milliseconds: 250), style: TextStyle(fontSize: 14, fontWeight: on ? FontWeight.w800 : FontWeight.w500, color: on ? p.text : p.muted), child: Text(labels[i])))),
                  AnimatedContainer(duration: const Duration(milliseconds: 280), curve: Curves.easeOutCubic, height: 3, decoration: BoxDecoration(color: on ? Pm.brand : Colors.transparent, borderRadius: BorderRadius.circular(2))),
                ]),
              ),
            ),
          );
        },
      ),
    );
  }
}

/// Movies of the selected category tab (first page from the server) with a link to the full list.
class _CategoryResults extends ConsumerWidget {
  final Genre genre;
  const _CategoryResults({required this.genre});
  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final q = MovieQuery(genre: genre.slug, sort: 'latest');
    final s = ref.watch(movieListProvider(q));
    if (s.items.isEmpty && s.loading) return const Padding(padding: EdgeInsets.symmetric(vertical: 60), child: LoadingView());
    if (s.items.isEmpty && s.error != null) return SizedBox(height: 300, child: ErrorView(error: s.error!, onRetry: () => ref.read(movieListProvider(q).notifier).loadMore()));
    if (s.items.isEmpty) return SizedBox(height: 300, child: EmptyView(icon: Icons.movie_outlined, title: 'No ${genre.name} movies yet', message: 'Check back soon.'));
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      SectionHeader(genre.name, onMore: () => context.push('/browse?genre=${genre.slug}&title=${Uri.encodeComponent(genre.name)}')),
      Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16),
        child: GridView.builder(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          gridDelegate: posterGrid(context),
          itemCount: s.items.length,
          itemBuilder: (_, k) => FadeUp(index: k % 6, child: MovieCard(movie: s.items[k])),
        ),
      ),
    ]);
  }
}

class _HomeSkeleton extends StatelessWidget {
  const _HomeSkeleton();
  @override
  Widget build(BuildContext context) => ListView(physics: const NeverScrollableScrollPhysics(), children: [
        const Skeleton(height: 380, radius: 0),
        const SizedBox(height: 18),
        for (var r = 0; r < 2; r++) ...[
          const Padding(padding: EdgeInsets.fromLTRB(16, 8, 16, 10), child: Skeleton(width: 140, height: 18, radius: 6)),
          SizedBox(height: 170, child: ListView(scrollDirection: Axis.horizontal, padding: const EdgeInsets.symmetric(horizontal: 16), physics: const NeverScrollableScrollPhysics(), children: [for (var i = 0; i < 4; i++) const Padding(padding: EdgeInsets.only(right: 12), child: Skeleton(width: 112, height: 168))])),
        ],
      ]);
}

/// Full-bleed, auto-advancing featured carousel with a slow zoom on the poster and an animated dot indicator.
class _HeroCarousel extends ConsumerStatefulWidget {
  final List<Movie> movies;
  const _HeroCarousel({required this.movies});
  @override
  ConsumerState<_HeroCarousel> createState() => _HeroCarouselState();
}

class _HeroCarouselState extends ConsumerState<_HeroCarousel> {
  final _pc = PageController();
  Timer? _t;
  int _i = 0;
  bool _dragging = false;

  @override
  void initState() {
    super.initState();
    _t = Timer.periodic(const Duration(seconds: 4), (_) {
      if (!mounted || _dragging || widget.movies.length < 2 || reduceMotion(context)) return;
      _pc.animateToPage((_i + 1) % widget.movies.length, duration: const Duration(milliseconds: 650), curve: Curves.easeInOutCubic);
    });
  }

  @override
  void dispose() {
    _t?.cancel();
    _pc.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final movies = widget.movies;
    if (movies.isEmpty) return const SizedBox(height: 120);
    final h = (MediaQuery.of(context).size.height * .52).clamp(340.0, 460.0);
    final bg = context.pm.bg;
    return SizedBox(
      height: h,
      child: Stack(children: [
        NotificationListener<ScrollNotification>(
          onNotification: (n) {
            if (n is ScrollStartNotification && n.dragDetails != null) _dragging = true;
            if (n is ScrollEndNotification) _dragging = false;
            return false;
          },
          child: PageView.builder(controller: _pc, itemCount: movies.length, onPageChanged: (v) => setState(() => _i = v), itemBuilder: (_, k) => _HeroPage(movie: movies[k], active: k == _i, bg: bg)),
        ),
        Positioned(left: 16, bottom: 14, child: AnimatedDots(count: movies.length, index: _i, align: MainAxisAlignment.start)),
      ]),
    );
  }
}

class _HeroPage extends ConsumerWidget {
  final Movie movie;
  final bool active;
  final Color bg;
  const _HeroPage({required this.movie, required this.active, required this.bg});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final img = movie.posterFullUrl ?? movie.posterUrl;
    final meta = [if (movie.rating != null) '★ ${movie.rating!.toStringAsFixed(1)}', if (movie.releaseYear != null) '${movie.releaseYear}', if (movie.quality != null) movie.quality!].join('  •  ');
    return GestureDetector(
      onTap: () => context.push('/movie/${movie.slug}'),
      child: Stack(fit: StackFit.expand, children: [
        ClipRect(
          child: TweenAnimationBuilder<double>(
            key: ValueKey(active),
            tween: Tween(begin: 1.0, end: active && !reduceMotion(context) ? 1.1 : 1.0),
            duration: const Duration(seconds: 9),
            curve: Curves.linear,
            builder: (_, v, child) => Transform.scale(scale: v, child: child),
            child: img == null ? Container(color: context.pm.card) : CachedNetworkImage(imageUrl: img, fit: BoxFit.cover, alignment: Alignment.topCenter, memCacheWidth: 900, errorWidget: (_, __, ___) => Container(color: context.pm.card)),
          ),
        ),
        DecoratedBox(decoration: BoxDecoration(gradient: LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: [bg.withOpacity(.35), Colors.transparent, bg.withOpacity(.85), bg], stops: const [0, .3, .78, 1]))),
        Positioned(
          left: 16,
          right: 16,
          bottom: 40,
          child: AnimatedSwitcher(
            duration: const Duration(milliseconds: 500),
            child: !active
                ? const SizedBox.shrink(key: ValueKey('off'))
                : FadeUp(
                    key: ValueKey(movie.id),
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisSize: MainAxisSize.min, children: [
                      Container(padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 2), decoration: BoxDecoration(border: Border.all(color: Pm.brand), borderRadius: BorderRadius.circular(10)), child: const Text('FEATURED', style: TextStyle(color: Pm.errorRed, fontSize: 10, fontWeight: FontWeight.w800))),
                      const SizedBox(height: 8),
                      Text(movie.title, maxLines: 2, overflow: TextOverflow.ellipsis, style: TextStyle(fontSize: 28, fontWeight: FontWeight.w800, height: 1.1, color: context.pm.text)),
                      const SizedBox(height: 4),
                      Text(meta, style: TextStyle(color: context.pm.muted, fontSize: 12)),
                      const SizedBox(height: 14),
                      Row(children: [
                        SizedBox(width: 150, child: GradientButton(label: 'Watch', icon: Icons.play_arrow_rounded, pulse: true, onPressed: () async { context.push('/movie/${movie.slug}'); return false; })),
                        const SizedBox(width: 10),
                        PressScale(
                          onTap: () async {
                            if (!ref.read(authProvider).signedIn) { context.push('/login'); return; }
                            try {
                              final ids = ref.read(watchlistIdsProvider).valueOrNull ?? <int>{};
                              if (!ids.contains(movie.id)) await ref.read(watchlistIdsProvider.notifier).toggle(movie.id);
                              if (context.mounted) toast(context, 'Added to your watchlist');
                            } catch (_) {
                              if (context.mounted) toast(context, 'Could not update your watchlist.');
                            }
                          },
                          child: Container(height: 50, padding: const EdgeInsets.symmetric(horizontal: 16), decoration: BoxDecoration(color: Colors.white.withOpacity(.14), borderRadius: BorderRadius.circular(14), border: Border.all(color: Colors.white24)), child: const Row(mainAxisSize: MainAxisSize.min, children: [Icon(Icons.add, size: 20, color: Colors.white), SizedBox(width: 4), Text('My list', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w700))])),
                        ),
                      ]),
                    ]),
                  ),
          ),
        ),
      ]),
    );
  }
}

class _Section extends StatelessWidget {
  final String title;
  final List<Movie> movies;
  final VoidCallback? more;
  const _Section({required this.title, required this.movies, this.more});
  @override
  Widget build(BuildContext context) => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [SectionHeader(title, onMore: more), MovieRow(movies)]);
}

class _SectionAsync extends StatelessWidget {
  final String title;
  final AsyncValue<Paged<Movie>> async;
  final bool hideWhenEmpty;
  final VoidCallback? more;
  const _SectionAsync({required this.title, required this.async, this.hideWhenEmpty = false, this.more});
  @override
  Widget build(BuildContext context) => async.when(
        loading: () => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [SectionHeader(title), SizedBox(height: 168, child: ListView(scrollDirection: Axis.horizontal, padding: const EdgeInsets.symmetric(horizontal: 16), physics: const NeverScrollableScrollPhysics(), children: [for (var i = 0; i < 4; i++) const Padding(padding: EdgeInsets.only(right: 12), child: Skeleton(width: 112, height: 168))]))]),
        error: (_, __) => const SizedBox.shrink(), // one failing section never breaks the page
        data: (p) => p.items.isEmpty && hideWhenEmpty ? const SizedBox.shrink() : _Section(title: title, movies: p.items, more: more),
      );
}

class _Recommended extends ConsumerWidget {
  const _Recommended();
  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final r = ref.watch(recommendationsProvider).valueOrNull ?? const <Movie>[];
    return r.isEmpty ? const SizedBox.shrink() : _Section(title: 'Recommended for you', movies: r);
  }
}
