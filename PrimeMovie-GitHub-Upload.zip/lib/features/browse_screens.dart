import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../core/theme.dart';
import '../data/repositories.dart';
import '../providers.dart';
import '../widgets/anim.dart';
import '../widgets/common.dart';

/// Shared infinite-scroll grid used by Search and category/section browsing.
class MovieGrid extends ConsumerStatefulWidget {
  final MovieQuery query;
  const MovieGrid({super.key, required this.query});
  @override
  ConsumerState<MovieGrid> createState() => _MovieGridState();
}

class _MovieGridState extends ConsumerState<MovieGrid> {
  final _scroll = ScrollController();

  @override
  void initState() {
    super.initState();
    _scroll.addListener(() {
      if (_scroll.position.extentAfter < 600) ref.read(movieListProvider(widget.query).notifier).loadMore();
    });
  }

  @override
  void dispose() {
    _scroll.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final s = ref.watch(movieListProvider(widget.query));
    final n = ref.read(movieListProvider(widget.query).notifier);
    if (s.items.isEmpty && s.loading) return const LoadingView();
    if (s.items.isEmpty && s.error != null) return ErrorView(error: s.error!, onRetry: n.loadMore);
    if (s.items.isEmpty) {
      return EmptyView(icon: Icons.search_off, title: 'No movies found', message: widget.query.q != null ? 'Try fewer words or browse a category.' : 'Nothing here yet.');
    }
    return RefreshIndicator(
      color: Pm.brand,
      onRefresh: n.refresh,
      child: CustomScrollView(controller: _scroll, physics: const AlwaysScrollableScrollPhysics(), slivers: [
        if (s.fromCache) const SliverToBoxAdapter(child: OfflineBanner()),
        SliverPadding(
          padding: const EdgeInsets.fromLTRB(16, 16, 16, 110),
          sliver: SliverGrid(
            gridDelegate: posterGrid(context),
            delegate: SliverChildBuilderDelegate((_, i) => FadeUp(index: i % 6, child: MovieCard(movie: s.items[i])), childCount: s.items.length),
          ),
        ),
        SliverToBoxAdapter(
          child: s.loading
              ? const Padding(padding: EdgeInsets.all(16), child: Center(child: CircularProgressIndicator(color: Pm.brand)))
              : s.error != null
                  ? Padding(padding: const EdgeInsets.all(16), child: Center(child: OutlinedButton(onPressed: n.loadMore, child: Text('${errText(s.error!)} Tap to retry'))))
                  : const SizedBox(height: 24),
        ),
      ]),
    );
  }
}

class SearchScreen extends ConsumerStatefulWidget {
  const SearchScreen({super.key});
  @override
  ConsumerState<SearchScreen> createState() => _SearchScreenState();
}

class _SearchScreenState extends ConsumerState<SearchScreen> {
  final _c = TextEditingController();
  Timer? _debounce;
  String _q = '';
  String _sort = 'relevance';
  String? _language, _country, _genre;
  int? _year;
  List<String> _suggestions = [];

  @override
  void dispose() {
    _debounce?.cancel();
    _c.dispose();
    super.dispose();
  }

  void _onChanged(String v) {
    _debounce?.cancel();
    _debounce = Timer(const Duration(milliseconds: 350), () async {
      final q = v.trim();
      if (q.length >= 2 && (ref.read(configProvider).valueOrNull?.searchSuggest ?? true)) {
        try {
          final s = await ref.read(contentRepoProvider).suggest(q);
          if (mounted && _c.text.trim() == q) setState(() => _suggestions = s);
        } catch (_) {
          if (mounted) setState(() => _suggestions = []);
        }
      } else if (mounted) {
        setState(() => _suggestions = []);
      }
    });
  }

  void _submit(String v) {
    FocusScope.of(context).unfocus();
    setState(() {
      _q = v.trim();
      _suggestions = [];
    });
  }

  Future<void> _openFilters() async {
    FocusScope.of(context).unfocus();
    final result = await showModalBottomSheet<_Filters>(
      context: context,
      isScrollControlled: true,
      backgroundColor: context.pm.surface,
      builder: (_) => _FilterSheet(initial: _Filters(_language, _country, _genre, _year)),
    );
    if (result != null) {
      setState(() {
        _language = result.language;
        _country = result.country;
        _genre = result.genre;
        _year = result.year;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final query = MovieQuery(q: _q.isEmpty ? null : _q, sort: _q.isEmpty ? 'latest' : _sort, language: _language, country: _country, genre: _genre, year: _year);
    final activeFilters = [_language, _country, _genre, _year].where((e) => e != null).length;
    return Scaffold(
      appBar: AppBar(
        title: TextField(
          controller: _c,
          textInputAction: TextInputAction.search,
          onChanged: _onChanged,
          onSubmitted: _submit,
          decoration: InputDecoration(
            hintText: 'Search movies...',
            prefixIcon: Icon(Icons.search, color: context.pm.muted),
            suffixIcon: _c.text.isEmpty ? null : IconButton(tooltip: 'Clear', icon: const Icon(Icons.close), onPressed: () { _c.clear(); _submit(''); }),
            isDense: true,
          ),
        ),
        actions: [
          IconButton(
            tooltip: 'Filters',
            onPressed: _openFilters,
            icon: Badge(isLabelVisible: activeFilters > 0, label: Text('$activeFilters'), child: const Icon(Icons.tune)),
          ),
          PopupMenuButton<String>(
            tooltip: 'Sort',
            icon: const Icon(Icons.sort),
            onSelected: (v) => setState(() => _sort = v),
            itemBuilder: (_) => const [
              PopupMenuItem(value: 'relevance', child: Text('Relevance')),
              PopupMenuItem(value: 'latest', child: Text('Newest added')),
              PopupMenuItem(value: 'rating', child: Text('Top rated')),
              PopupMenuItem(value: 'popularity', child: Text('Most viewed')),
              PopupMenuItem(value: 'release_date', child: Text('Release year')),
              PopupMenuItem(value: 'title', child: Text('Title A-Z')),
            ],
          ),
        ],
      ),
      body: Stack(children: [
        MovieGrid(key: ValueKey(query.key), query: query),
        if (_suggestions.isNotEmpty)
          Positioned.fill(
            child: Material(
              color: context.pm.surface,
              child: ListView(children: [
                for (final s in _suggestions) ListTile(leading: Icon(Icons.search, color: context.pm.muted), title: Text(s), onTap: () { _c.text = s; _submit(s); }),
              ]),
            ),
          ),
      ]),
    );
  }
}

class BrowseScreen extends StatelessWidget {
  final MovieQuery query;
  final String title;
  const BrowseScreen({super.key, required this.query, required this.title});
  @override
  Widget build(BuildContext context) => Scaffold(appBar: AppBar(title: Text(title)), body: MovieGrid(query: query));
}


class _Filters {
  final String? language, country, genre;
  final int? year;
  const _Filters(this.language, this.country, this.genre, this.year);
}

class _FilterSheet extends ConsumerStatefulWidget {
  final _Filters initial;
  const _FilterSheet({required this.initial});
  @override
  ConsumerState<_FilterSheet> createState() => _FilterSheetState();
}

class _FilterSheetState extends ConsumerState<_FilterSheet> {
  late String? language = widget.initial.language, country = widget.initial.country, genre = widget.initial.genre;
  late int? year = widget.initial.year;

  Widget _group<T>(String title, List<T> options, T? selected, String Function(T) label, void Function(T?) onChanged) {
    if (options.isEmpty) return const SizedBox.shrink();
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Padding(padding: const EdgeInsets.fromLTRB(0, 14, 0, 6), child: Text(title, style: const TextStyle(fontWeight: FontWeight.w800))),
      Wrap(spacing: 8, runSpacing: 4, children: [
        for (final o in options) ChoiceChip(label: Text(label(o)), selected: selected == o, onSelected: (on) => setState(() => onChanged(on ? o : null))),
      ]),
    ]);
  }

  @override
  Widget build(BuildContext context) {
    final languages = ref.watch(languagesProvider).valueOrNull ?? const <String>[];
    final countries = ref.watch(countriesProvider).valueOrNull ?? const <String>[];
    final genres = ref.watch(categoriesProvider).valueOrNull ?? const [];
    final now = DateTime.now().year;
    final years = [for (var y = now; y >= now - 14; y--) y];
    return SafeArea(
      child: ConstrainedBox(
        constraints: BoxConstraints(maxHeight: MediaQuery.of(context).size.height * .85),
        child: Padding(
          padding: const EdgeInsets.fromLTRB(16, 16, 16, 12),
          child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('Filters', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
            Flexible(
              child: SingleChildScrollView(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  _group<String>('Language', languages, language, (s) => s, (v) => language = v),
                  _group<String>('Country', countries, country, (s) => s, (v) => country = v),
                  _group<String>('Genre', [for (final g in genres) g.slug], genre, (slug) => genres.firstWhere((g) => g.slug == slug).name, (v) => genre = v),
                  _group<int>('Release year', years, year, (y) => '$y', (v) => year = v),
                ]),
              ),
            ),
            const SizedBox(height: 12),
            Row(children: [
              Expanded(child: OutlinedButton(onPressed: () => Navigator.pop(context, const _Filters(null, null, null, null)), child: const Text('Clear all'))),
              const SizedBox(width: 8),
              Expanded(child: FilledButton(onPressed: () => Navigator.pop(context, _Filters(language, country, genre, year)), child: const Text('Apply'))),
            ]),
          ]),
        ),
      ),
    );
  }
}
