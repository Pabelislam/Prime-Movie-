import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../core/api_client.dart';
import '../core/theme.dart';
import '../data/models.dart';
import '../providers.dart';
import '../widgets/anim.dart';
import '../widgets/common.dart';

final _emailRe = RegExp(r'^[^@\s]+@[^@\s]+\.[^@\s]+$');

String? validatePassword(String? v) {
  final p = v ?? '';
  if (p.length < 8) return 'Use at least 8 characters.';
  if (!RegExp(r'[A-Za-z]').hasMatch(p) || !RegExp(r'\d').hasMatch(p)) return 'Include letters and numbers.';
  return null;
}

String? validateEmail(String? v) => _emailRe.hasMatch((v ?? '').trim()) ? null : 'Enter a valid email address.';

/// 0..3: how strong a password looks (length, mix of letters/digits, extra length or symbols).
int passwordStrength(String p) {
  var s = 0;
  if (p.length >= 8) s++;
  if (RegExp(r'[A-Za-z]').hasMatch(p) && RegExp(r'\d').hasMatch(p)) s++;
  if (p.length >= 12 || RegExp(r'[^A-Za-z0-9]').hasMatch(p)) s++;
  return s;
}

/// Shared Cinematic layout: drifting posters, dark fade, animated logo, frosted card.
class _AuthShell extends StatelessWidget {
  final String title;
  final String? subtitle;
  final List<Widget> children;
  final Widget? footer;
  final bool compactTop;
  const _AuthShell({required this.title, this.subtitle, this.footer, this.compactTop = false, required this.children});

  @override
  Widget build(BuildContext context) {
    final bg = context.pm.bg;
    return Scaffold(
      body: Stack(fit: StackFit.expand, children: [
        const Positioned.fill(child: ClipRect(child: DriftingPosters())),
        Positioned.fill(child: DecoratedBox(decoration: BoxDecoration(gradient: LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: [bg.withOpacity(.80), bg], stops: const [0, .62])))),
        SafeArea(
          child: SingleChildScrollView(
            padding: const EdgeInsets.fromLTRB(20, 12, 20, 28),
            child: Column(children: [
              Align(alignment: Alignment.centerLeft, child: context.canPop() ? IconButton(tooltip: 'Back', icon: const Icon(Icons.arrow_back), onPressed: () => context.pop()) : const SizedBox(height: 48)),
              SizedBox(height: compactTop ? 4 : 26),
              TweenAnimationBuilder<double>(
                tween: Tween(begin: 0, end: 1),
                duration: reduceMotion(context) ? Duration.zero : const Duration(milliseconds: 900),
                curve: Curves.easeOutCubic,
                builder: (_, v, __) => Opacity(opacity: v, child: Transform.scale(scale: .7 + .3 * v, child: Text('PrimeMovie', style: TextStyle(color: Pm.brand, fontSize: 34, fontWeight: FontWeight.w800, letterSpacing: 14 * (1 - v) + .5)))),
              ),
              FadeUp(index: 2, child: Padding(padding: const EdgeInsets.only(top: 4), child: Text('Unlimited movies, anywhere', style: TextStyle(color: context.pm.muted)))),
              SizedBox(height: compactTop ? 18 : 52),
              FadeUp(
                index: 3,
                child: Glass(
                  padding: const EdgeInsets.all(20),
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text(title, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w800)),
                    if (subtitle != null) Padding(padding: const EdgeInsets.only(top: 4), child: Text(subtitle!, style: TextStyle(color: context.pm.muted, fontSize: 13))),
                    const SizedBox(height: 16),
                    ...children,
                  ]),
                ),
              ),
              if (footer != null) FadeUp(index: 5, child: Padding(padding: const EdgeInsets.only(top: 18), child: footer!)),
            ]),
          ),
        ),
      ]),
    );
  }
}

class _Field extends StatelessWidget {
  final TextEditingController controller;
  final String label;
  final bool obscure;
  final Widget? suffix;
  final String? Function(String?)? validator;
  final String? serverError;
  final TextInputType? keyboard;
  final ValueChanged<String>? onChanged;
  const _Field({required this.controller, required this.label, this.obscure = false, this.suffix, this.validator, this.serverError, this.keyboard, this.onChanged});
  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.only(bottom: 12),
        child: TextFormField(
          controller: controller,
          obscureText: obscure,
          keyboardType: keyboard,
          validator: validator,
          onChanged: onChanged,
          autocorrect: false,
          decoration: InputDecoration(labelText: label, suffixIcon: suffix, errorText: serverError, floatingLabelStyle: const TextStyle(color: Pm.brand2), border: OutlineInputBorder(borderRadius: BorderRadius.circular(14)), enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide(color: context.pm.border)), focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: const BorderSide(color: Pm.brand, width: 1.6))),
        ),
      );
}

mixin _FormState<T extends StatefulWidget> on State<T> {
  String? formError;
  Map<String, String> fieldErrors = {};
  bool hidePw = true;

  /// Runs [job]; returns true on success. ApiErrors become inline messages.
  Future<bool> attempt(Future<void> Function() job) async {
    setState(() { formError = null; fieldErrors = {}; });
    try {
      await job();
      return true;
    } on ApiError catch (e) {
      if (mounted) {
        setState(() {
          formError = e.isRateLimited && e.retryAfter != null ? 'Too many attempts. Try again in ${e.retryAfter}s.' : e.message;
          fieldErrors = {for (final k in e.details.keys) k: e.details[k].toString()};
        });
      }
      return false;
    }
  }

  Widget errorBox() => AnimatedSize(
        duration: const Duration(milliseconds: 250),
        child: formError == null ? const SizedBox(width: double.infinity) : Padding(padding: const EdgeInsets.only(bottom: 12), child: Text(formError!, style: const TextStyle(color: Pm.errorRed))),
      );

  Widget eye() => IconButton(tooltip: hidePw ? 'Show password' : 'Hide password', icon: Icon(hidePw ? Icons.visibility_outlined : Icons.visibility_off_outlined), onPressed: () => setState(() => hidePw = !hidePw));
}

class LoginScreen extends ConsumerStatefulWidget {
  const LoginScreen({super.key});
  @override
  ConsumerState<LoginScreen> createState() => _LoginState();
}

class _LoginState extends ConsumerState<LoginScreen> with _FormState {
  final _form = GlobalKey<FormState>();
  final email = TextEditingController(), password = TextEditingController();
  @override
  void dispose() { email.dispose(); password.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    final cfg = ref.watch(configProvider).valueOrNull ?? RemoteConfig.defaults;
    return _AuthShell(
      title: 'Welcome back',
      subtitle: 'Sign in to sync your library',
      footer: cfg.registration ? Center(child: Text.rich(TextSpan(text: 'New here? ', style: TextStyle(color: context.pm.muted), children: [WidgetSpan(alignment: PlaceholderAlignment.baseline, baseline: TextBaseline.alphabetic, child: GestureDetector(onTap: () => context.push('/register'), child: Text('Create account', style: TextStyle(color: context.pm.text, fontWeight: FontWeight.w800))))]))) : null,
      children: [
        Form(
          key: _form,
          child: Column(children: [
            _Field(controller: email, label: 'Email', keyboard: TextInputType.emailAddress, validator: validateEmail, serverError: fieldErrors['email']),
            _Field(controller: password, label: 'Password', obscure: hidePw, suffix: eye(), validator: (v) => (v ?? '').isEmpty ? 'Enter your password.' : null, serverError: fieldErrors['password']),
            errorBox(),
            GradientButton(
              label: 'Sign in',
              onPressed: () async {
                if (!_form.currentState!.validate()) return false;
                return attempt(() => ref.read(authProvider.notifier).login(email.text.trim(), password.text));
              },
              onSuccess: () => context.canPop() ? context.pop() : context.go('/'),
            ),
          ]),
        ),
        if (cfg.passwordReset) Center(child: TextButton(onPressed: () => context.push('/forgot'), child: const Text('Forgot password?'))),
      ],
    );
  }
}

class RegisterScreen extends ConsumerStatefulWidget {
  const RegisterScreen({super.key});
  @override
  ConsumerState<RegisterScreen> createState() => _RegisterState();
}

class _RegisterState extends ConsumerState<RegisterScreen> with _FormState {
  final _form = GlobalKey<FormState>();
  final email = TextEditingController(), name = TextEditingController(), password = TextEditingController();
  int _strength = 0;
  @override
  void dispose() { email.dispose(); name.dispose(); password.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    const colors = [Pm.errorRed, Pm.brand, Pm.star, Color(0xFF2BA84F)];
    final filled = password.text.isEmpty ? 0.0 : (_strength + 1) / 4;
    return _AuthShell(
      title: 'Create account',
      subtitle: 'It takes less than a minute',
      compactTop: true,
      children: [
        Form(
          key: _form,
          child: Column(children: [
            _Field(controller: name, label: 'Display name', validator: (v) => (v ?? '').trim().length < 2 ? 'Enter at least 2 characters.' : null, serverError: fieldErrors['display_name']),
            _Field(controller: email, label: 'Email', keyboard: TextInputType.emailAddress, validator: validateEmail, serverError: fieldErrors['email']),
            _Field(controller: password, label: 'Password', obscure: hidePw, suffix: eye(), validator: validatePassword, serverError: fieldErrors['password'], onChanged: (v) => setState(() => _strength = passwordStrength(v))),
            Padding(
              padding: const EdgeInsets.only(bottom: 14, top: 2),
              child: ClipRRect(borderRadius: BorderRadius.circular(3), child: Stack(children: [
                Container(height: 4, color: context.pm.border),
                AnimatedFractionallySizedBox(duration: const Duration(milliseconds: 300), widthFactor: filled, child: AnimatedContainer(duration: const Duration(milliseconds: 300), height: 4, color: colors[_strength])),
              ])),
            ),
            errorBox(),
            GradientButton(
              label: 'Create account',
              onPressed: () async {
                if (!_form.currentState!.validate()) return false;
                return attempt(() => ref.read(authProvider.notifier).register(email.text.trim(), name.text.trim(), password.text));
              },
              onSuccess: () => context.go('/'),
            ),
          ]),
        ),
      ],
      footer: Center(child: Text.rich(TextSpan(text: 'Already have an account? ', style: TextStyle(color: context.pm.muted), children: [WidgetSpan(alignment: PlaceholderAlignment.baseline, baseline: TextBaseline.alphabetic, child: GestureDetector(onTap: () => context.canPop() ? context.pop() : context.go('/login'), child: Text('Sign in', style: TextStyle(color: context.pm.text, fontWeight: FontWeight.w800))))]))),
    );
  }
}

class ForgotScreen extends ConsumerStatefulWidget {
  const ForgotScreen({super.key});
  @override
  ConsumerState<ForgotScreen> createState() => _ForgotState();
}

class _ForgotState extends ConsumerState<ForgotScreen> with _FormState {
  final email = TextEditingController(), code = TextEditingController(), password = TextEditingController();
  bool sent = false;
  @override
  void dispose() { email.dispose(); code.dispose(); password.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    return _AuthShell(
      title: 'Reset password',
      subtitle: sent ? 'Enter the code from your email and a new password.' : 'We will email you a reset code.',
      children: [
        AnimatedSwitcher(
          duration: const Duration(milliseconds: 300),
          child: sent
              ? Column(key: const ValueKey('b'), children: [
                  _Field(controller: code, label: 'Reset code'),
                  _Field(controller: password, label: 'New password', obscure: hidePw, suffix: eye(), serverError: fieldErrors['password']),
                  errorBox(),
                  GradientButton(
                    label: 'Update password',
                    onPressed: () async {
                      final v = validatePassword(password.text);
                      if (v != null) { setState(() => formError = v); return false; }
                      return attempt(() => ref.read(accountRepoProvider).reset(code.text.trim(), password.text));
                    },
                    onSuccess: () { toast(context, 'Password updated. Please sign in.'); context.go('/login'); },
                  ),
                ])
              : Column(key: const ValueKey('a'), children: [
                  _Field(controller: email, label: 'Email', keyboard: TextInputType.emailAddress),
                  errorBox(),
                  GradientButton(
                    label: 'Send code',
                    onPressed: () async {
                      if (validateEmail(email.text) != null) { setState(() => formError = 'Enter a valid email address.'); return false; }
                      return attempt(() => ref.read(accountRepoProvider).forgot(email.text.trim()));
                    },
                    onSuccess: () => setState(() => sent = true),
                  ),
                ]),
        ),
      ],
    );
  }
}
