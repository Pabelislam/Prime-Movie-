import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:media_kit/media_kit.dart';
import 'package:media_kit_video/media_kit_video.dart';
import '../core/languages.dart';
import '../core/theme.dart';
import '../data/downloads.dart';
import '../data/player_args.dart';
import '../data/settings.dart';
import '../providers.dart';
import '../widgets/anim.dart';
import '../widgets/common.dart';

class DownloadsScreen extends ConsumerWidget {
  const DownloadsScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final items = ref.watch(downloadsProvider);
    final n = ref.read(downloadsProvider.notifier);
    final gallery = ref.watch(saveToGalleryProvider).valueOrNull ?? false;
    return Scaffold(
      appBar: AppBar(title: const Text('Downloads')),
      body: items.isEmpty
          ? const EmptyView(icon: Icons.download_for_offline_outlined, title: 'No downloads yet', message: 'Download a movie from its page to watch it later without internet.')
          : ListView(children: [
              Padding(
                padding: EdgeInsets.fromLTRB(16, 4, 16, 0),
                child: Text('Downloads are kept in private app storage and can only be played here.', style: TextStyle(color: context.pm.muted, fontSize: 12)),
              ),
              ListTile(dense: true, leading: const Icon(Icons.settings_outlined), title: const Text('Download settings'), subtitle: const Text('Location, Wi-Fi only, storage used', style: TextStyle(fontSize: 11)), trailing: const Icon(Icons.chevron_right), onTap: () => context.push('/settings')),
              SwitchListTile(
                dense: true,
                title: const Text('Also save new downloads to Movies/PrimeMovie'),
                subtitle: const Text('Lets Gallery, MX Player and PlayIt see them. Other apps can then copy the file.', style: TextStyle(fontSize: 11)),
                value: gallery,
                onChanged: (v) => ref.read(saveToGalleryProvider.notifier).set(v),
              ),
              for (var k = 0; k < items.length; k++) FadeUp(index: k, child: _Tile(d: items[k], n: n)),
            ]),
    );
  }
}

class _Tile extends StatelessWidget {
  final DownloadItem d;
  final DownloadsNotifier n;
  const _Tile({required this.d, required this.n});

  String get _subtitle {
    switch (d.status) {
      case DlStatus.queued:
        return 'Waiting… ${d.sizeLabel ?? ''}'.trim();
      case DlStatus.downloading:
        return '${(d.progress * 100).round()}% • ${d.sizeProgress}'.replaceAll(RegExp(r' • $'), '');
      case DlStatus.paused:
        return 'Paused • ${(d.progress * 100).round()}%';
      case DlStatus.completed:
        return 'Ready to watch • ${d.quality}${(d.sizeLabel ?? '').isNotEmpty ? ' • ${d.sizeLabel}' : ''}';
      case DlStatus.failed:
        return d.error ?? 'Download failed';
    }
  }

  void _play(BuildContext context) {
    final a = d.toPlayerArgs();
    if (a != null) context.push('/player', extra: a);
  }

  @override
  Widget build(BuildContext context) {
    final play = d.status == DlStatus.completed && d.path != null;
    return ListTile(
      onTap: play ? () => _play(context) : null,
      leading: SizedBox(width: 48, child: Poster(url: d.posterUrl, label: d.title, radius: 6)),
      title: Text(d.title, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w700)),
      subtitle: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(_subtitle, maxLines: 3, overflow: TextOverflow.ellipsis, style: TextStyle(color: d.status == DlStatus.failed ? Pm.errorRed : context.pm.muted, fontSize: 12)),
        if (d.active) Padding(padding: const EdgeInsets.only(top: 6), child: d.status == DlStatus.queued ? LinearProgressIndicator(color: Pm.brand, backgroundColor: context.pm.card2) : TweenAnimationBuilder<double>(tween: Tween(end: d.progress), duration: const Duration(milliseconds: 400), builder: (_, v, __) => LinearProgressIndicator(value: v, color: Pm.brand, backgroundColor: context.pm.card2))),
      ]),
      trailing: _actions(context),
    );
  }

  Widget _actions(BuildContext context) {
    switch (d.status) {
      case DlStatus.queued:
      case DlStatus.downloading:
        return Row(mainAxisSize: MainAxisSize.min, children: [
          IconButton(tooltip: 'Pause', icon: const Icon(Icons.pause_circle_outline), onPressed: () => n.pause(d.id)),
          IconButton(tooltip: 'Cancel', icon: const Icon(Icons.close), onPressed: () => _confirmDelete(context, 'Cancel this download?')),
        ]);
      case DlStatus.paused:
        return Row(mainAxisSize: MainAxisSize.min, children: [
          IconButton(tooltip: 'Resume', icon: const Icon(Icons.play_circle_outline), onPressed: () => n.resume(d.id)),
          IconButton(tooltip: 'Cancel', icon: const Icon(Icons.close), onPressed: () => _confirmDelete(context, 'Cancel this download?')),
        ]);
      case DlStatus.failed:
        return Row(mainAxisSize: MainAxisSize.min, children: [
          IconButton(tooltip: 'Retry', icon: const Icon(Icons.refresh), onPressed: () => n.retry(d.id)),
          IconButton(tooltip: 'Remove', icon: const Icon(Icons.delete_outline), onPressed: () => n.remove(d.id)),
        ]);
      case DlStatus.completed:
        return PopupMenuButton<String>(
          onSelected: (v) async {
            if (v == 'play') _play(context);
            if (v == 'ext' && !await n.openExternally(d.id) && context.mounted) toast(context, 'No other video app could open this file (private files can only be played here).');
            if (v == 'del') _confirmDelete(context, 'Delete this movie from your phone?');
          },
          itemBuilder: (_) => const [
            PopupMenuItem(value: 'play', child: Text('Play')),
            PopupMenuItem(value: 'ext', child: Text('Open in another player')),
            PopupMenuItem(value: 'del', child: Text('Delete')),
          ],
        );
    }
  }

  Future<void> _confirmDelete(BuildContext context, String q) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (c) => AlertDialog(
        title: Text(q),
        content: const Text('The downloaded file will be removed from your phone.'),
        actions: [TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('Keep')), TextButton(onPressed: () => Navigator.pop(c, true), child: const Text('Delete'))],
      ),
    );
    if (ok == true) await n.remove(d.id);
  }
}

class _AudioChoice {
  final String label;
  final AudioTrack track;
  const _AudioChoice(this.label, this.track);
}

/// Full-screen player (streaming or downloaded file), modelled on the YouTube player: landscape + immersive, auto-hiding
/// controls, double-tap -/+10 s, 10 s buttons, draggable seek bar, speed, fullscreen toggle, Audio and Subtitle pickers,
/// buffering indicator, error + retry, resume from the last position, pauses when the app goes to the background.
/// Uses media_kit (libmpv): HLS, MKV, multiple embedded tracks and external subtitle files are supported.
class PlayerScreen extends ConsumerStatefulWidget {
  final PlayerArgs args;
  const PlayerScreen({super.key, required this.args});
  @override
  ConsumerState<PlayerScreen> createState() => _PlayerState();
}

class _PlayerState extends ConsumerState<PlayerScreen> with WidgetsBindingObserver {
  late final Player _p = Player();
  late final VideoController _vc = VideoController(_p);
  final _subs = <StreamSubscription<dynamic>>[];
  Duration _pos = Duration.zero, _dur = Duration.zero;
  bool _playing = false, _completed = false, _buffering = false, _show = true, _dragging = false, _sheetOpen = false, _resumed = false;
  Tracks? _tracks;
  AudioTrack? _aSel;
  SubtitleTrack? _sSel;
  String? _err;
  double _dragMs = 0, _speed = 1.0, _lastTapX = 0;
  Timer? _hide, _flashT, _saveT;
  String? _flash;
  bool _flashLeft = false;
  String? _streamUrl;

  PlayerArgs get a => widget.args;
  String get _posKey => 'pos:${a.movieId}:${a.sourceId}';
  bool get _ready => _dur > Duration.zero;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    SystemChrome.setPreferredOrientations([DeviceOrientation.landscapeLeft, DeviceOrientation.landscapeRight]);
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);
    _streamUrl = a.streamUrl;
    _subs.addAll([
      _p.stream.position.listen((v) { if (mounted && !_dragging) setState(() => _pos = v); }),
      _p.stream.duration.listen((v) { if (mounted) { setState(() => _dur = v); _maybeResume(); } }),
      _p.stream.playing.listen((v) { if (mounted) { setState(() => _playing = v); if (v) _scheduleHide(); } }),
      _p.stream.buffering.listen((v) { if (mounted) setState(() => _buffering = v); }),
      _p.stream.completed.listen((v) { if (mounted) setState(() => _completed = v); }),
      _p.stream.tracks.listen((v) { if (mounted) setState(() => _tracks = v); }),
      _p.stream.track.listen((v) { if (mounted) setState(() { _aSel = v.audio; _sSel = v.subtitle; }); }),
      _p.stream.error.listen((e) { if (mounted) setState(() => _err = e); }),
    ]);
    _open();
    _saveT = Timer.periodic(const Duration(seconds: 5), (_) => _savePosition());
    _scheduleHide();
  }

  Future<void> _open() async {
    setState(() => _err = null);
    _resumed = false;
    await _p.open(Media(a.isLocal ? a.localPath! : _streamUrl!));
  }

  /// Seeks to the saved position once, unless the movie was (almost) finished or just started.
  Future<void> _maybeResume() async {
    if (_resumed || !_ready) return;
    _resumed = true;
    final c = await ref.read(cacheProvider).get(_posKey);
    final ms = int.tryParse(c?.json ?? '');
    if (ms != null && ms > 15000 && ms < _dur.inMilliseconds - 30000) await _p.seek(Duration(milliseconds: ms));
  }

  Future<void> _savePosition() async {
    if (!_ready) return;
    final done = _pos.inMilliseconds >= _dur.inMilliseconds - 30000;
    await ref.read(cacheProvider).put(_posKey, '${done ? 0 : _pos.inMilliseconds}');
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.paused || state == AppLifecycleState.inactive) {
      _p.pause(); // do not keep playing in the background; the position is saved and the user can resume
      _savePosition();
    }
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _savePosition();
    _hide?.cancel();
    _flashT?.cancel();
    _saveT?.cancel();
    for (final s in _subs) { s.cancel(); }
    _p.dispose();
    SystemChrome.setPreferredOrientations(DeviceOrientation.values);
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
    super.dispose();
  }

  Future<void> _retry() async {
    if (!a.isLocal && a.refreshUrl != null) {
      final u = await a.refreshUrl!(); // links expire; ask the server for a new one
      if (u == null) {
        if (mounted) toast(context, 'This movie is not available right now.');
        return;
      }
      _streamUrl = u;
    }
    await _open();
  }

  void _scheduleHide() {
    _hide?.cancel();
    _hide = Timer(const Duration(seconds: 3), () {
      if (mounted && _playing && !_dragging && !_sheetOpen) setState(() => _show = false);
    });
  }

  void _toggleControls() {
    setState(() => _show = !_show);
    if (_show) _scheduleHide();
  }

  Future<void> _skip(int seconds) async {
    var t = _pos + Duration(seconds: seconds);
    if (t < Duration.zero) t = Duration.zero;
    if (t > _dur) t = _dur;
    await _p.seek(t);
    setState(() {
      _flash = seconds < 0 ? '−${-seconds}s' : '+${seconds}s';
      _flashLeft = seconds < 0;
    });
    _flashT?.cancel();
    _flashT = Timer(const Duration(milliseconds: 600), () { if (mounted) setState(() => _flash = null); });
    _scheduleHide();
  }

  String _fmt(Duration d) {
    String two(int n) => n.toString().padLeft(2, '0');
    final h = d.inHours;
    return h > 0 ? '$h:${two(d.inMinutes % 60)}:${two(d.inSeconds % 60)}' : '${d.inMinutes}:${two(d.inSeconds % 60)}';
  }

  void _toggleFullscreen() {
    final landscape = MediaQuery.of(context).orientation == Orientation.landscape;
    SystemChrome.setPreferredOrientations(landscape ? [DeviceOrientation.portraitUp] : [DeviceOrientation.landscapeLeft, DeviceOrientation.landscapeRight]);
    _scheduleHide();
  }

  List<AudioTrack> get _embeddedAudio => (_tracks?.audio ?? const <AudioTrack>[]).where((t) => t.id != 'auto' && t.id != 'no').toList();
  List<SubtitleTrack> get _embeddedSubs => (_tracks?.subtitle ?? const <SubtitleTrack>[]).where((t) => t.id != 'auto' && t.id != 'no').toList();

  /// Admin-defined audio labels are mapped onto the file's real tracks by position; external audio files are loaded by URL.
  /// A track the file does not actually contain is never offered.
  List<_AudioChoice> _audioChoices() {
    final emb = _embeddedAudio;
    if (a.audio.isEmpty) {
      return [for (var i = 0; i < emb.length; i++) _AudioChoice(trackLabel(language: emb[i].language, title: emb[i].title, index: i + 1), emb[i])];
    }
    final out = <_AudioChoice>[];
    for (final x in a.audio) {
      if (x.uri != null) {
        out.add(_AudioChoice(x.label, AudioTrack.uri(x.uri!, title: x.label, language: x.language)));
      } else if (x.trackIndex != null && x.trackIndex! >= 1 && x.trackIndex! <= emb.length) {
        out.add(_AudioChoice(x.label, emb[x.trackIndex! - 1]));
      }
    }
    return out;
  }

  Future<void> _pick(String title, List<Widget> rows) async {
    setState(() => _sheetOpen = true);
    _hide?.cancel();
    await showModalBottomSheet<void>(
      context: context,
      backgroundColor: context.pm.surface,
      isScrollControlled: true,
      constraints: BoxConstraints(maxHeight: MediaQuery.of(context).size.height * .8, maxWidth: 420),
      builder: (_) => SafeArea(child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
        Padding(padding: const EdgeInsets.fromLTRB(16, 14, 16, 6), child: Text(title, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w800))),
        Flexible(child: ListView(shrinkWrap: true, children: rows)),
      ])),
    );
    if (mounted) setState(() => _sheetOpen = false);
    _scheduleHide();
  }

  Widget _row(String label, bool selected, VoidCallback onTap) => ListTile(
        dense: true,
        title: Text(label),
        trailing: selected ? const Icon(Icons.check, color: Pm.brand) : null,
        onTap: () { onTap(); Navigator.pop(context); },
      );

  void _pickAudio() {
    final list = _audioChoices();
    if (list.length < 2) {
      toast(context, list.isEmpty ? 'No separate audio tracks in this movie.' : 'This movie has only one audio track.');
      return;
    }
    _pick('Audio', [for (final c in list) _row(c.label, _aSel?.id == c.track.id, () => _p.setAudioTrack(c.track))]);
  }

  void _pickSubtitles() {
    final emb = _embeddedSubs;
    if (a.subtitles.where((x) => x.uri != null || x.embeddedIndex != null).isEmpty && emb.isEmpty) {
      toast(context, 'No subtitles are available for this movie.');
      return;
    }
    final off = _sSel == null || _sSel!.id == 'no';
    _pick('Subtitles', [
      _row('No subtitles', off, () => _p.setSubtitleTrack(SubtitleTrack.no())),
      for (final s in a.subtitles)
        if (s.uri != null)
          _row(s.label, _sSel?.id == s.uri, () => _p.setSubtitleTrack(SubtitleTrack.uri(s.uri!, title: s.label, language: s.language)))
        else if (s.embeddedIndex != null && s.embeddedIndex! >= 1 && s.embeddedIndex! <= emb.length)
          _row(s.label, _sSel?.id == emb[s.embeddedIndex! - 1].id, () => _p.setSubtitleTrack(emb[s.embeddedIndex! - 1])),
      for (var i = 0; i < emb.length; i++)
        if (!a.subtitles.any((x) => x.embeddedIndex == i + 1))
          _row('${trackLabel(language: emb[i].language, title: emb[i].title, index: i + 1)} (in file)', _sSel?.id == emb[i].id, () => _p.setSubtitleTrack(emb[i])),
    ]);
  }

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;
    return Scaffold(
      backgroundColor: Colors.black,
      body: GestureDetector(
        behavior: HitTestBehavior.opaque,
        onTap: _toggleControls,
        onDoubleTapDown: (d) => _lastTapX = d.localPosition.dx,
        onDoubleTap: () { if (_ready) _skip(_lastTapX < size.width / 2 ? -10 : 10); },
        child: Stack(fit: StackFit.expand, children: [
          Video(
            controller: _vc,
            controls: NoVideoControls,
            fit: BoxFit.contain,
            fill: Colors.black,
            subtitleViewConfiguration: SubtitleViewConfiguration(
              style: TextStyle(fontSize: (ref.watch(settingsProvider).valueOrNull ?? const AppSettings()).subtitleFontSize, height: 1.3, color: Colors.white, fontWeight: FontWeight.w600, backgroundColor: const Color(0x99000000)),
              textAlign: TextAlign.center,
              padding: const EdgeInsets.fromLTRB(24, 0, 24, 56),
            ),
          ),
          if (_err != null)
            Container(
              color: Colors.black,
              child: SafeArea(
                child: Stack(children: [
                  Align(alignment: Alignment.topLeft, child: IconButton(tooltip: 'Back', icon: const Icon(Icons.arrow_back), onPressed: () => Navigator.of(context).pop())),
                  EmptyView(
                    icon: Icons.error_outline,
                    title: "Can't play this movie",
                    message: a.isLocal ? 'The downloaded file could not be played. Delete it and download again.' : 'Check your connection, then retry. If it keeps failing the link may have expired.',
                    action: a.isLocal ? null : FilledButton.icon(onPressed: _retry, icon: const Icon(Icons.refresh), label: const Text('Retry')),
                  ),
                ]),
              ),
            )
          else ...[
            if (!_ready || _buffering) const Center(child: CircularProgressIndicator(color: Pm.brand)),
            if (_flash != null)
              Align(
                alignment: _flashLeft ? const Alignment(-.6, 0) : const Alignment(.6, 0),
                child: Container(padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 12), decoration: BoxDecoration(color: Colors.black54, borderRadius: BorderRadius.circular(40)), child: Text(_flash!, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800))),
              ),
            if (_ready)
              IgnorePointer(
                ignoring: !_show,
                child: AnimatedOpacity(opacity: _show ? 1 : 0, duration: const Duration(milliseconds: 200), child: _controls()),
              ),
          ],
        ]),
      ),
    );
  }

  Widget _controls() {
    final total = _dur.inMilliseconds.toDouble().clamp(1, double.infinity).toDouble();
    final posMs = (_dragging ? _dragMs : _pos.inMilliseconds.toDouble()).clamp(0, total).toDouble();
    final ended = _completed;
    final multiAudio = _audioChoices().length > 1;
    return Container(
      color: Colors.black38,
      child: SafeArea(
        child: Column(children: [
          Row(children: [
            IconButton(tooltip: 'Back', icon: const Icon(Icons.keyboard_arrow_down, size: 30), onPressed: () => Navigator.of(context).pop()),
            Expanded(child: Text(a.title, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w700))),
            IconButton(tooltip: 'Audio language', icon: Icon(Icons.audiotrack, color: multiAudio ? context.pm.text : context.pm.muted), onPressed: _pickAudio),
            IconButton(tooltip: 'Subtitles', icon: Icon(_sSel != null && _sSel!.id != 'no' ? Icons.closed_caption : Icons.closed_caption_off), onPressed: _pickSubtitles),
            PopupMenuButton<double>(
              tooltip: 'Playback speed',
              icon: const Icon(Icons.speed),
              initialValue: _speed,
              onSelected: (s) { setState(() => _speed = s); _p.setRate(s); },
              itemBuilder: (_) => [for (final s in const [0.5, 0.75, 1.0, 1.25, 1.5, 2.0]) PopupMenuItem(value: s, child: Text(s == 1.0 ? 'Normal' : '${s}x'))],
            ),
          ]),
          const Spacer(),
          Row(mainAxisAlignment: MainAxisAlignment.center, children: [
            IconButton(iconSize: 40, tooltip: 'Back 10 seconds', icon: const Icon(Icons.replay_10), onPressed: () => _skip(-10)),
            const SizedBox(width: 28),
            IconButton(
              iconSize: 64,
              tooltip: ended ? 'Replay' : (_playing ? 'Pause' : 'Play'),
              icon: Icon(ended ? Icons.replay_circle_filled : (_playing ? Icons.pause_circle_filled : Icons.play_circle_filled)),
              onPressed: () async {
                if (ended) await _p.seek(Duration.zero);
                if (_playing && !ended) { await _p.pause(); } else { await _p.play(); }
                _scheduleHide();
              },
            ),
            const SizedBox(width: 28),
            IconButton(iconSize: 40, tooltip: 'Forward 10 seconds', icon: const Icon(Icons.forward_10), onPressed: () => _skip(10)),
          ]),
          const Spacer(),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Row(children: [
              Text('${_fmt(Duration(milliseconds: posMs.round()))} / ${_fmt(_dur)}', style: const TextStyle(fontSize: 12)),
              const Spacer(),
              IconButton(tooltip: 'Fullscreen / rotate', icon: Icon(MediaQuery.of(context).orientation == Orientation.landscape ? Icons.fullscreen_exit : Icons.fullscreen), onPressed: _toggleFullscreen),
            ]),
          ),
          SliderTheme(
            data: SliderTheme.of(context).copyWith(trackHeight: 3, thumbShape: const RoundSliderThumbShape(enabledThumbRadius: 7), overlayShape: const RoundSliderOverlayShape(overlayRadius: 16), activeTrackColor: Pm.brand, thumbColor: Pm.brand, inactiveTrackColor: Colors.white24),
            child: Slider(
              value: posMs,
              max: total,
              onChangeStart: (x) { _hide?.cancel(); setState(() { _dragging = true; _dragMs = x; }); },
              onChanged: (x) => setState(() => _dragMs = x),
              onChangeEnd: (x) async {
                await _p.seek(Duration(milliseconds: x.round()));
                setState(() { _dragging = false; _pos = Duration(milliseconds: x.round()); });
                _scheduleHide();
              },
            ),
          ),
          const SizedBox(height: 4),
        ]),
      ),
    );
  }
}
