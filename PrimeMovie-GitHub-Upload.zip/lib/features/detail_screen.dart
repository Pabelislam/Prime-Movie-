import 'package:cached_network_image/cached_network_image.dart';
import 'dart:ui' show ImageFilter;
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:url_launcher/url_launcher.dart';
import '../core/api_client.dart';
import '../core/theme.dart';
import '../data/downloads.dart';
import '../data/models.dart';
import '../data/player_args.dart';
import '../providers.dart';
import '../widgets/anim.dart';
import '../widgets/common.dart';

/// Only plain http(s) links are ever opened, always in the external browser (never inside the app).
Future<void> openExternal(BuildContext context, String? url) async {
  final u = url == null ? null : Uri.tryParse(url);
  if (u == null || !(u.scheme == 'https' || u.scheme == 'http') || u.host.isEmpty) {
    toast(context, 'This link is not available.');
    return;
  }
  if (!await launchUrl(u, mode: LaunchMode.externalApplication) && context.mounted) toast(context, "Couldn't open the link.");
}

class DetailScreen extends ConsumerStatefulWidget {
  final String slug;
  const DetailScreen({super.key, required this.slug});
  @override
  ConsumerState<DetailScreen> createState() => _DetailScreenState();
}

class _DetailScreenState extends ConsumerState<DetailScreen> {
  @override
  void initState() {
    super.initState();
    Future.microtask(() => ref.read(contentRepoProvider).recordView(widget.slug));
  }

  @override
  Widget build(BuildContext context) {
    final async = ref.watch(movieDetailProvider(widget.slug));
    return Scaffold(
      body: async.when(
        loading: () => Stack(children: [ListView(physics: const NeverScrollableScrollPhysics(), children: [const Skeleton(height: 330, radius: 0), const SizedBox(height: 16), const Padding(padding: EdgeInsets.symmetric(horizontal: 16), child: Skeleton(height: 50)), const SizedBox(height: 14), const Padding(padding: EdgeInsets.symmetric(horizontal: 16), child: Skeleton(height: 90))]), const _BackButton()]),
        error: (e, _) => Stack(children: [
          isNotFound(e)
              ? const EmptyView(icon: Icons.movie_filter_outlined, title: 'Movie unavailable', message: 'This title was removed or is no longer available.')
              : ErrorView(error: e, onRetry: () => ref.invalidate(movieDetailProvider(widget.slug))),
          const _BackButton(),
        ]),
        data: (c) => _Body(movie: c.data, fromCache: c.fromCache),
      ),
    );
  }
}

bool isNotFound(Object e) => e is ApiError && e.status == 404;

class _BackButton extends StatelessWidget {
  const _BackButton();
  @override
  Widget build(BuildContext context) => SafeArea(child: Padding(padding: const EdgeInsets.all(8), child: _RoundBtn(icon: Icons.arrow_back, tooltip: 'Back', onTap: () => context.canPop() ? context.pop() : context.go('/'))));
}

class _RoundBtn extends StatelessWidget {
  final IconData icon;
  final String tooltip;
  final VoidCallback onTap;
  final Color? color;
  const _RoundBtn({required this.icon, required this.tooltip, required this.onTap, this.color});
  @override
  Widget build(BuildContext context) => Tooltip(
        message: tooltip,
        child: PressScale(onTap: onTap, scale: .88, child: Container(width: 40, height: 40, decoration: const BoxDecoration(shape: BoxShape.circle, color: Color(0x99000000)), child: AnimatedSwitcher(duration: const Duration(milliseconds: 250), transitionBuilder: (c, a) => ScaleTransition(scale: a, child: c), child: Icon(icon, key: ValueKey(icon), color: color ?? Colors.white, size: 22)))),
      );
}

class _Body extends ConsumerStatefulWidget {
  final Movie movie;
  final bool fromCache;
  const _Body({required this.movie, required this.fromCache});
  @override
  ConsumerState<_Body> createState() => _BodyState();
}

class _BodyState extends ConsumerState<_Body> {
  final _sc = ScrollController();
  double _off = 0;

  @override
  void initState() {
    super.initState();
    _sc.addListener(() { if (mounted) setState(() => _off = _sc.offset); });
  }

  @override
  void dispose() {
    _sc.dispose();
    super.dispose();
  }

  Future<void> _toggle(WidgetRef ref, AsyncNotifierProvider<IdSetNotifier, Set<int>> p, String on, String off) async {
    if (!ref.read(authProvider).signedIn) {
      context.push('/login');
      return;
    }
    try {
      final had = (ref.read(p).valueOrNull ?? <int>{}).contains(widget.movie.id);
      await ref.read(p.notifier).toggle(widget.movie.id);
      if (mounted) toast(context, had ? off : on);
    } on ApiError catch (e) {
      if (mounted) toast(context, e.message);
    }
  }

  @override
  Widget build(BuildContext context) {
    final m = widget.movie;
    final p = context.pm;
    final cfg = ref.watch(configProvider).valueOrNull ?? RemoteConfig.defaults;
    final related = ref.watch(relatedProvider(m.slug)).valueOrNull ?? const <Movie>[];
    final inWatch = ref.watch(watchlistIdsProvider).valueOrNull?.contains(m.id) ?? false;
    final inFav = ref.watch(favoriteIdsProvider).valueOrNull?.contains(m.id) ?? false;
    final solid = (_off / 220).clamp(0.0, 1.0);
    var i = 0;
    Widget fade(Widget w) => FadeUp(index: i++, child: w);

    return Stack(children: [
      RefreshIndicator(
        color: Pm.brand,
        edgeOffset: 90,
        onRefresh: () async {
          ref.invalidate(movieDetailProvider(m.slug));
          ref.invalidate(relatedProvider(m.slug));
          ref.invalidate(reviewsProvider(m.slug));
          ref.invalidate(appMediaProvider(m.slug));
        },
        child: ListView(controller: _sc, padding: const EdgeInsets.only(bottom: 120), children: [
          if (widget.fromCache) const OfflineBanner(),
          _DetailHero(movie: m, offset: _off),
          fade(Padding(
            padding: const EdgeInsets.fromLTRB(16, 18, 16, 0),
            child: Row(children: [
              Expanded(child: _PlayButton(movie: m)),
              const SizedBox(width: 10),
              _RoundActionBtn(icon: inWatch ? Icons.check_rounded : Icons.add_rounded, tooltip: inWatch ? 'Remove from watchlist' : 'Add to watchlist', active: inWatch, onTap: () => _toggle(ref, watchlistIdsProvider, 'Added to your watchlist', 'Removed from your watchlist')),
              const SizedBox(width: 8),
              _RoundActionBtn(icon: inFav ? Icons.favorite : Icons.favorite_border, tooltip: inFav ? 'Remove from favorites' : 'Add to favorites', active: inFav, onTap: () => _toggle(ref, favoriteIdsProvider, 'Added to favorites', 'Removed from favorites')),
              if (m.trailerUrl != null) ...[const SizedBox(width: 8), _RoundActionBtn(icon: Icons.smart_display_outlined, tooltip: 'Watch trailer', onTap: () => openExternal(context, m.trailerUrl))],
            ]),
          )),
          if (m.genres.isNotEmpty) fade(Padding(padding: const EdgeInsets.fromLTRB(16, 14, 16, 0), child: Wrap(spacing: 8, runSpacing: 8, children: [for (final g in m.genres) PressScale(onTap: () => context.push('/browse?genre=${g.slug}&title=${Uri.encodeComponent(g.name)}'), child: Container(padding: const EdgeInsets.symmetric(horizontal: 13, vertical: 6), decoration: BoxDecoration(color: p.card2, borderRadius: BorderRadius.circular(20), border: Border.all(color: p.border)), child: Text(g.name, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w600))))]))),
          fade(_AppMediaSection(movie: m)),
          if (m.description != null) fade(Column(crossAxisAlignment: CrossAxisAlignment.start, children: [const SectionHeader('Synopsis'), Padding(padding: const EdgeInsets.symmetric(horizontal: 16), child: ExpandableText(m.description!))])),
          if (m.director != null || m.cast.isNotEmpty) fade(Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const SectionHeader('Cast & crew'),
            SizedBox(
              height: 92,
              child: ListView(scrollDirection: Axis.horizontal, padding: const EdgeInsets.symmetric(horizontal: 16), children: [
                if (m.director != null) _Person(name: m.director!, role: 'Director'),
                for (final c in m.cast.take(12)) _Person(name: c),
              ]),
            ),
          ])),
          if (m.screenshots.isNotEmpty) fade(Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const SectionHeader('Screenshots'),
            SizedBox(
              height: 120,
              child: ListView.separated(
                scrollDirection: Axis.horizontal,
                padding: const EdgeInsets.symmetric(horizontal: 16),
                itemCount: m.screenshots.length,
                separatorBuilder: (_, __) => const SizedBox(width: 8),
                itemBuilder: (_, k) => ClipRRect(borderRadius: BorderRadius.circular(12), child: CachedNetworkImage(imageUrl: m.screenshots[k], width: 200, fit: BoxFit.cover, memCacheWidth: 500, errorWidget: (_, __, ___) => Container(width: 200, color: p.card))),
              ),
            ),
          ])),
          if (m.downloads.isNotEmpty) fade(Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const SectionHeader('Website download links'),
            for (final d in m.downloads)
              ListTile(
                leading: Icon(Icons.open_in_new, color: p.muted),
                title: Text('${d.quality}${d.fileSize != null ? '  •  ${d.fileSize}' : ''}', style: const TextStyle(fontWeight: FontWeight.w700)),
                subtitle: Text('Opens the website download page in your browser', style: TextStyle(color: p.muted, fontSize: 12)),
                onTap: () => openExternal(context, d.url),
              ),
          ])),
          if (cfg.reviews) fade(_Reviews(movie: m)),
          if (related.isNotEmpty) fade(Column(crossAxisAlignment: CrossAxisAlignment.start, children: [const SectionHeader('Related movies'), MovieRow(related)])),
        ]),
      ),
      // Top bar: transparent over the artwork, becomes solid with the title once scrolled
      Positioned(
        top: 0,
        left: 0,
        right: 0,
        child: Container(
          decoration: BoxDecoration(color: p.bg.withOpacity(solid * .96), boxShadow: solid > .95 ? [BoxShadow(color: Colors.black.withOpacity(.25), blurRadius: 10)] : const []),
          child: SafeArea(
            bottom: false,
            child: Padding(
              padding: const EdgeInsets.fromLTRB(8, 6, 8, 6),
              child: Row(children: [
                _RoundBtn(icon: Icons.arrow_back, tooltip: 'Back', onTap: () => context.canPop() ? context.pop() : context.go('/')),
                const SizedBox(width: 10),
                Expanded(child: Opacity(opacity: solid, child: Text(m.title, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w800)))),
              ]),
            ),
          ),
        ),
      ),
    ]);
  }
}

/// Blurred, parallax backdrop from the poster with the poster floating over it and the title block beside it.
class _DetailHero extends StatelessWidget {
  final Movie movie;
  final double offset;
  const _DetailHero({required this.movie, required this.offset});

  @override
  Widget build(BuildContext context) {
    final p = context.pm;
    final img = movie.posterFullUrl ?? movie.posterUrl;
    final meta = [if (movie.releaseYear != null) '${movie.releaseYear}', if (movie.runtime != null) movie.runtime!, if (movie.language != null) movie.language!].join('  •  ');
    final rs = movie.reviewSummary;
    return SizedBox(
      height: 400,
      child: Stack(clipBehavior: Clip.none, children: [
        Positioned.fill(
          child: ClipRect(
            child: Transform.translate(
              offset: Offset(0, offset.clamp(0, 400) * .35),
              child: ImageFiltered(
                imageFilter: ImageFilter.blur(sigmaX: 2.5, sigmaY: 2.5),
                child: Transform.scale(scale: 1.15, child: img == null ? Container(color: p.card) : CachedNetworkImage(imageUrl: img, fit: BoxFit.cover, alignment: Alignment.topCenter, memCacheWidth: 900, errorWidget: (_, __, ___) => Container(color: p.card))),
              ),
            ),
          ),
        ),
        Positioned.fill(child: DecoratedBox(decoration: BoxDecoration(gradient: LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: [Colors.black.withOpacity(.45), p.bg.withOpacity(.2), p.bg], stops: const [0, .45, .98])))),
        Positioned(
          left: 16,
          right: 16,
          bottom: 0,
          child: Row(crossAxisAlignment: CrossAxisAlignment.end, children: [
            TweenAnimationBuilder<double>(
              tween: Tween(begin: 0, end: 1),
              duration: reduceMotion(context) ? Duration.zero : const Duration(milliseconds: 750),
              curve: Curves.easeOutBack,
              builder: (_, v, child) => Opacity(opacity: v.clamp(0, 1), child: Transform.translate(offset: Offset(0, 30 * (1 - v)), child: Transform.rotate(angle: -.1 * (1 - v), child: child))),
              child: Container(
                width: 120,
                decoration: BoxDecoration(borderRadius: BorderRadius.circular(12), boxShadow: [BoxShadow(color: Colors.black.withOpacity(.6), blurRadius: 24, offset: const Offset(0, 12))]),
                child: Poster(url: movie.posterFullUrl ?? movie.posterUrl, label: movie.title, radius: 12),
              ),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: FadeUp(
                index: 2,
                child: Padding(
                  padding: const EdgeInsets.only(bottom: 4),
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisSize: MainAxisSize.min, children: [
                    if (movie.featured) Container(margin: const EdgeInsets.only(bottom: 6), padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 2), decoration: BoxDecoration(border: Border.all(color: Pm.brand), borderRadius: BorderRadius.circular(10)), child: const Text('FEATURED', style: TextStyle(color: Pm.errorRed, fontSize: 10, fontWeight: FontWeight.w800))),
                    Text(movie.title, maxLines: 3, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 23, fontWeight: FontWeight.w800, height: 1.12)),
                    if (meta.isNotEmpty) Padding(padding: const EdgeInsets.only(top: 5), child: Text(meta, style: TextStyle(color: p.muted, fontSize: 12))),
                    const SizedBox(height: 6),
                    Wrap(spacing: 8, crossAxisAlignment: WrapCrossAlignment.center, children: [
                      if (movie.rating != null) Text('★ ${movie.rating!.toStringAsFixed(1)}', style: const TextStyle(color: Pm.star, fontWeight: FontWeight.w800)),
                      if (rs != null && rs.count > 0) Text('${rs.average?.toStringAsFixed(1)}/5 · ${rs.count} reviews', style: TextStyle(color: p.muted, fontSize: 12)),
                      if (movie.quality != null) Container(padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 1), decoration: BoxDecoration(color: Pm.brand, borderRadius: BorderRadius.circular(4)), child: Text(movie.quality!, style: const TextStyle(fontSize: 10, fontWeight: FontWeight.w800, color: Colors.white))),
                    ]),
                  ]),
                ),
              ),
            ),
          ]),
        ),
      ]),
    );
  }
}

class _Person extends StatelessWidget {
  final String name;
  final String? role;
  const _Person({required this.name, this.role});
  @override
  Widget build(BuildContext context) {
    final p = context.pm;
    final initials = name.trim().isEmpty ? '?' : name.trim().split(RegExp(r'\s+')).take(2).map((w) => w[0].toUpperCase()).join();
    return Padding(
      padding: const EdgeInsets.only(right: 14),
      child: SizedBox(
        width: 66,
        child: Column(children: [
          Container(width: 56, height: 56, alignment: Alignment.center, decoration: BoxDecoration(shape: BoxShape.circle, color: p.card2, border: Border.all(color: p.border, width: 2)), child: Text(initials, style: const TextStyle(fontWeight: FontWeight.w800))),
          const SizedBox(height: 5),
          Text(name, maxLines: 2, textAlign: TextAlign.center, overflow: TextOverflow.ellipsis, style: TextStyle(fontSize: 10, color: p.muted, height: 1.2)),
          if (role != null) Text(role!, style: const TextStyle(fontSize: 9, color: Pm.brand2)),
        ]),
      ),
    );
  }
}

/// Circle action button; when [active] it gets a red outline and bounces.
class _RoundActionBtn extends StatelessWidget {
  final IconData icon;
  final String tooltip;
  final bool active;
  final VoidCallback onTap;
  const _RoundActionBtn({required this.icon, required this.tooltip, this.active = false, required this.onTap});
  @override
  Widget build(BuildContext context) {
    final p = context.pm;
    return Tooltip(
      message: tooltip,
      child: PressScale(
        onTap: onTap,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 250),
          width: 50,
          height: 50,
          decoration: BoxDecoration(borderRadius: BorderRadius.circular(14), color: active ? Pm.brand.withOpacity(.16) : p.card2, border: Border.all(color: active ? Pm.brand : p.border)),
          child: AnimatedSwitcher(duration: const Duration(milliseconds: 280), transitionBuilder: (c, a) => ScaleTransition(scale: CurvedAnimation(parent: a, curve: Curves.elasticOut), child: c), child: Icon(icon, key: ValueKey(icon), color: active ? Pm.brand2 : p.text, size: 23)),
        ),
      ),
    );
  }
}

/// Primary call to action: plays the first streamable app version, or says clearly that none is available.
class _PlayButton extends ConsumerWidget {
  final Movie movie;
  const _PlayButton({required this.movie});
  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final list = ref.watch(appMediaProvider(movie.slug)).valueOrNull ?? const <AppMediaSource>[];
    final playable = list.where((s) => s.canStream).toList();
    final locked = list.any((s) => s.locked);
    if (playable.isEmpty) {
      return GradientButton(
        label: locked ? 'Sign in to watch' : (list.isEmpty ? 'Not in the app yet' : 'Unavailable'),
        icon: locked ? Icons.lock_outline : null,
        onPressed: () async {
          if (locked) context.push('/login');
          return false;
        },
      );
    }
    final best = playable.last; // versions are ordered by the admin; the last is normally the highest quality
    return GradientButton(
      label: 'Play ${best.quality}',
      icon: Icons.play_arrow_rounded,
      pulse: true,
      onPressed: () async {
        context.push('/player', extra: _argsFor(ref, movie, best));
        return false;
      },
    );
  }
}

PlayerArgs _argsFor(WidgetRef ref, Movie movie, AppMediaSource s) => PlayerArgs(
      title: movie.title,
      movieId: movie.id,
      sourceId: s.id,
      streamUrl: s.streamUrl,
      audio: [for (final a in s.audio) PlayerAudio(label: a.label, language: a.language, trackIndex: a.trackIndex, uri: a.url)],
      subtitles: [for (final x in s.subtitles) PlayerSubtitle(label: x.label, language: x.language, uri: x.url, embeddedIndex: x.embeddedIndex)],
      refreshUrl: () async {
        final list = await ref.read(contentRepoProvider).appMedia(movie.slug);
        return list.where((x) => x.id == s.id).firstOrNull?.streamUrl;
      },
    );

class _Reviews extends ConsumerWidget {
  final Movie movie;
  const _Reviews({required this.movie});

  Future<void> _write(BuildContext context, WidgetRef ref, {Review? existing}) async {
    if (!ref.read(authProvider).signedIn) {
      context.push('/login');
      return;
    }
    final result = await showModalBottomSheet<bool>(
      context: context,
      isScrollControlled: true,
      backgroundColor: context.pm.surface,
      builder: (_) => _ReviewSheet(slug: movie.slug, existing: existing),
    );
    if (result == true) {
      ref.invalidate(reviewsProvider(movie.slug));
      ref.invalidate(movieDetailProvider(movie.slug));
    }
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final async = ref.watch(reviewsProvider(movie.slug));
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      SectionHeader('Reviews', onMore: null),
      Padding(padding: const EdgeInsets.symmetric(horizontal: 16), child: OutlinedButton.icon(onPressed: () => _write(context, ref), icon: const Icon(Icons.rate_review_outlined), label: const Text('Write a review'))),
      async.when(
        loading: () => const SizedBox(height: 80, child: LoadingView()),
        error: (e, _) => Padding(padding: const EdgeInsets.all(16), child: Text(errText(e), style: TextStyle(color: context.pm.muted))),
        data: (p) => p.items.isEmpty
            ? Padding(padding: EdgeInsets.all(16), child: Text('No reviews yet. Be the first.', style: TextStyle(color: context.pm.muted)))
            : Column(children: [
                for (final r in p.items)
                  ListTile(
                    title: Row(children: [Expanded(child: Text(r.author, style: const TextStyle(fontWeight: FontWeight.w700))), Text('★' * r.rating, style: const TextStyle(color: Pm.star, fontSize: 12))]),
                    subtitle: Padding(padding: const EdgeInsets.only(top: 4), child: Text(r.spoiler ? 'Spoiler: ${r.body}' : r.body, style: TextStyle(color: context.pm.muted))),
                    trailing: PopupMenuButton<String>(
                      onSelected: (v) async {
                        final repo = ref.read(accountRepoProvider);
                        try {
                          if (v == 'edit') await _write(context, ref, existing: r);
                          if (v == 'delete') {
                            await repo.deleteReview(r.id);
                            ref.invalidate(reviewsProvider(movie.slug));
                          }
                          if (v == 'report') {
                            await repo.reportReview(r.id, 'other');
                            if (context.mounted) toast(context, 'Thanks, the review was reported.');
                          }
                        } on ApiError catch (e) {
                          if (context.mounted) toast(context, e.message);
                        }
                      },
                      itemBuilder: (_) => r.mine
                          ? const [PopupMenuItem(value: 'edit', child: Text('Edit')), PopupMenuItem(value: 'delete', child: Text('Delete'))]
                          : const [PopupMenuItem(value: 'report', child: Text('Report'))],
                    ),
                  ),
              ]),
      ),
    ]);
  }
}

class _ReviewSheet extends ConsumerStatefulWidget {
  final String slug;
  final Review? existing;
  const _ReviewSheet({required this.slug, this.existing});
  @override
  ConsumerState<_ReviewSheet> createState() => _ReviewSheetState();
}

class _ReviewSheetState extends ConsumerState<_ReviewSheet> {
  late int rating = widget.existing?.rating ?? 0;
  late final body = TextEditingController(text: widget.existing?.body ?? '');
  late bool spoiler = widget.existing?.spoiler ?? false;
  String? error;
  bool busy = false;

  @override
  void dispose() {
    body.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    if (rating < 1) return setState(() => error = 'Choose a star rating.');
    if (body.text.trim().length < 10) return setState(() => error = 'Write at least 10 characters.');
    setState(() { busy = true; error = null; });
    try {
      final repo = ref.read(accountRepoProvider);
      if (widget.existing != null) {
        await repo.updateReview(widget.existing!.id, rating, body.text.trim(), spoiler);
      } else {
        await repo.createReview(widget.slug, rating, body.text.trim(), spoiler);
      }
      if (mounted) {
        toast(context, 'Review submitted. It may appear after moderation.');
        Navigator.pop(context, true);
      }
    } on ApiError catch (e) {
      setState(() { busy = false; error = e.fieldMessage('body') ?? e.fieldMessage('rating') ?? e.message; });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.fromLTRB(16, 16, 16, 16 + MediaQuery.of(context).viewInsets.bottom),
      child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(widget.existing == null ? 'Write a review' : 'Edit your review', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
        const SizedBox(height: 8),
        Row(children: [for (var i = 1; i <= 5; i++) IconButton(tooltip: '$i star${i > 1 ? 's' : ''}', onPressed: () => setState(() => rating = i), icon: Icon(i <= rating ? Icons.star : Icons.star_border, color: Pm.star))]),
        TextField(controller: body, maxLines: 4, maxLength: 1500, decoration: const InputDecoration(hintText: 'What did you think?', border: OutlineInputBorder())),
        CheckboxListTile(value: spoiler, onChanged: (v) => setState(() => spoiler = v ?? false), title: const Text('Contains spoilers'), contentPadding: EdgeInsets.zero, controlAffinity: ListTileControlAffinity.leading),
        if (error != null) Padding(padding: const EdgeInsets.only(bottom: 8), child: Text(error!, style: const TextStyle(color: Pm.errorRed))),
        SizedBox(width: double.infinity, child: FilledButton(onPressed: busy ? null : _submit, child: busy ? const SizedBox(height: 20, width: 20, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white)) : const Text('Submit'))),
      ]),
    );
  }
}


/// The Android app's own versions of the movie: stream in the in-app player or download for offline viewing.
/// The website's external download links stay in their own section (browser). With several versions a sliding selector switches between them.
class _AppMediaSection extends ConsumerStatefulWidget {
  final Movie movie;
  const _AppMediaSection({required this.movie});
  @override
  ConsumerState<_AppMediaSection> createState() => _AppMediaSectionState();
}

class _AppMediaSectionState extends ConsumerState<_AppMediaSection> {
  int _sel = 0;

  @override
  Widget build(BuildContext context) {
    final movie = widget.movie;
    final async = ref.watch(appMediaProvider(movie.slug));
    final downloads = ref.watch(downloadsProvider);
    return async.when(
      loading: () => const SizedBox.shrink(),
      error: (e, _) => const SizedBox.shrink(), // website links remain usable
      data: (list) {
        if (list.isEmpty) return const SizedBox.shrink();
        final s = list[_sel.clamp(0, list.length - 1)];
        return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const SectionHeader('Watch & download in the app'),
          if (list.length > 1) Padding(padding: const EdgeInsets.fromLTRB(16, 0, 16, 10), child: SlidingSegments(labels: [for (final x in list) x.quality], selected: _sel.clamp(0, list.length - 1), onChanged: (v) => setState(() => _sel = v))),
          AnimatedSwitcher(
            duration: const Duration(milliseconds: 320),
            transitionBuilder: (c, a) => FadeTransition(opacity: a, child: SlideTransition(position: Tween(begin: const Offset(0, .06), end: Offset.zero).animate(a), child: c)),
            child: KeyedSubtree(key: ValueKey(s.id), child: _card(context, s, downloads.where((d) => d.id == 'dl_app_${s.id}').firstOrNull)),
          ),
        ]);
      },
    );
  }

  Widget _chips(BuildContext context, String title, List<String> items) {
    if (items.isEmpty) return const SizedBox.shrink();
    return Padding(
      padding: const EdgeInsets.only(top: 8),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(title, style: TextStyle(color: context.pm.muted, fontSize: 11)),
        const SizedBox(height: 4),
        Wrap(spacing: 6, runSpacing: 6, children: [for (final t in items) Container(padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 3), decoration: BoxDecoration(color: context.pm.card2, borderRadius: BorderRadius.circular(14), border: Border.all(color: context.pm.border)), child: Text(t, style: const TextStyle(fontSize: 11)))]),
      ]),
    );
  }

  Widget _card(BuildContext context, AppMediaSource s, DownloadItem? d) {
    final movie = widget.movie;
    final size = formatBytes(s.fileSize);
    final title = '${s.quality} • ${s.format.toUpperCase()}${size.isNotEmpty ? ' • $size' : ''}';
    final extras = [if (s.label != null) s.label!, if (s.height != null) '${s.width}×${s.height}', if (s.durationSeconds != null) '${(s.durationSeconds! / 60).round()} min'].join(' • ');
    final audio = [for (final a in s.audio) a.label];
    final subs = [for (final x in s.subtitles) x.label];
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 0, 16, 0),
      child: Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(color: context.pm.card, borderRadius: BorderRadius.circular(16), border: Border.all(color: context.pm.border)),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [Expanded(child: Text(title, style: const TextStyle(fontWeight: FontWeight.w800))), if (s.verified) const Tooltip(message: 'Checked by the server', child: Icon(Icons.verified_outlined, size: 18, color: Pm.brand2))]),
          if (extras.isNotEmpty) Text(extras, style: TextStyle(color: context.pm.muted, fontSize: 12)),
          if (!s.locked && s.status == 'active') ...[_chips(context, 'Audio', audio.length > 1 ? audio : const []), _chips(context, 'Subtitles', subs)],
          const SizedBox(height: 12),
          if (s.locked)
            GradientButton(label: 'Sign in to watch', icon: Icons.lock_outline, onPressed: () async { context.push('/login'); return false; })
          else if (s.status != 'active')
            Text(s.unavailableReason ?? 'Temporarily unavailable', style: TextStyle(color: context.pm.muted))
          else
            Row(children: [
              if (s.canStream) Expanded(child: GradientButton(label: 'Play', icon: Icons.play_arrow_rounded, onPressed: () async { context.push('/player', extra: _argsFor(ref, movie, s)); return false; })),
              if (s.canStream && s.canDownload) const SizedBox(width: 10),
              if (s.canDownload) Expanded(child: _downloadButton(context, s, d)),
              if (!s.canStream && !s.canDownload) Text('Not available for the app right now', style: TextStyle(color: context.pm.muted)),
            ]),
          if (!s.locked && s.status == 'active' && s.offlineReason != null) Padding(padding: const EdgeInsets.only(top: 8), child: Text(s.offlineReason!, style: TextStyle(color: context.pm.muted, fontSize: 12))),
        ]),
      ),
    );
  }

  Widget _downloadButton(BuildContext context, AppMediaSource s, DownloadItem? d) {
    final movie = widget.movie;
    Widget btn(IconData icon, String label, VoidCallback onTap, {double? progress}) => PressScale(
          onTap: onTap,
          child: Container(
            height: 50,
            decoration: BoxDecoration(color: context.pm.card2, borderRadius: BorderRadius.circular(14), border: Border.all(color: context.pm.border)),
            child: Stack(alignment: Alignment.center, children: [
              if (progress != null) Align(alignment: Alignment.centerLeft, child: FractionallySizedBox(widthFactor: progress.clamp(0.0, 1.0), child: Container(decoration: BoxDecoration(color: Pm.brand.withOpacity(.25), borderRadius: BorderRadius.circular(14))))),
              Row(mainAxisSize: MainAxisSize.min, children: [Icon(icon, size: 20), const SizedBox(width: 6), Text(label, style: const TextStyle(fontWeight: FontWeight.w700))]),
            ]),
          ),
        );
    if (d != null && d.status == DlStatus.completed) {
      return btn(Icons.offline_pin, 'Play offline', () {
        final a = d.toPlayerArgs();
        if (a != null) context.push('/player', extra: a);
      });
    }
    if (d != null && d.active) return btn(Icons.downloading, '${(d.progress * 100).round()}%', () => context.go('/downloads'), progress: d.progress);
    final failed = d != null && d.status == DlStatus.failed;
    return btn(failed ? Icons.refresh : Icons.download_rounded, failed ? 'Retry' : 'Download', () async {
      final n = ref.read(downloadsProvider.notifier);
      String? problem;
      if (failed) {
        await n.retry(d.id);
      } else {
        problem = await n.start(movie, s);
      }
      if (context.mounted) toast(context, problem ?? 'Download started. Find it in Downloads.');
    });
  }
}
