/// Build-time configuration. Override with:
///   flutter run --dart-define=API_BASE_URL=https://staging.example.com/api/v1
class AppConfig {
  static const String apiBaseUrl =
      String.fromEnvironment('API_BASE_URL', defaultValue: 'https://primemovie.site/api/v1');

  /// Normalised with a trailing slash so relative paths ("movies") resolve under /api/v1/.
  static String get baseUrl => apiBaseUrl.endsWith('/') ? apiBaseUrl : '$apiBaseUrl/';

  /// Site origin used for the public pages (About, Contact, ...), derived from the API URL.
  static String get siteOrigin {
    final u = Uri.parse(apiBaseUrl);
    return '${u.scheme}://${u.authority}';
  }
}
