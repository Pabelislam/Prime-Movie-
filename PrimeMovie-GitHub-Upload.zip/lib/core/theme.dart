import 'package:flutter/material.dart';

/// Brand colours/radii come from the website's assets/css/site.css. The website is dark-only, so the light palette is a
/// light counterpart of the same design (same red accent, same radii) for users who prefer it.
class PmPalette extends ThemeExtension<PmPalette> {
  final Color bg, surface, card, card2, border, text, muted;
  const PmPalette({required this.bg, required this.surface, required this.card, required this.card2, required this.border, required this.text, required this.muted});

  static const dark = PmPalette(bg: Color(0xFF0A0B0F), surface: Color(0xFF111319), card: Color(0xFF171A21), card2: Color(0xFF1D212B), border: Color(0xFF232733), text: Color(0xFFF1F3F6), muted: Color(0xFF9AA3B2));
  static const light = PmPalette(bg: Color(0xFFF5F6F9), surface: Color(0xFFFFFFFF), card: Color(0xFFFFFFFF), card2: Color(0xFFEDEFF4), border: Color(0xFFDCE0E8), text: Color(0xFF14161C), muted: Color(0xFF5B6475));

  @override
  PmPalette copyWith({Color? bg, Color? surface, Color? card, Color? card2, Color? border, Color? text, Color? muted}) => PmPalette(
      bg: bg ?? this.bg, surface: surface ?? this.surface, card: card ?? this.card, card2: card2 ?? this.card2, border: border ?? this.border, text: text ?? this.text, muted: muted ?? this.muted);

  @override
  PmPalette lerp(ThemeExtension<PmPalette>? other, double t) {
    if (other is! PmPalette) return this;
    return PmPalette(bg: Color.lerp(bg, other.bg, t)!, surface: Color.lerp(surface, other.surface, t)!, card: Color.lerp(card, other.card, t)!, card2: Color.lerp(card2, other.card2, t)!, border: Color.lerp(border, other.border, t)!, text: Color.lerp(text, other.text, t)!, muted: Color.lerp(muted, other.muted, t)!);
  }
}

extension PmContext on BuildContext {
  /// Theme-aware colours: use these instead of fixed colours so Dark/Light/System all work.
  PmPalette get pm => Theme.of(this).extension<PmPalette>() ?? PmPalette.dark;
}

class Pm {
  static const brand = Color(0xFFE50914);
  static const brand2 = Color(0xFFFF3B30);
  static const star = Color(0xFFFFC107);
  static const errorRed = Color(0xFFFF6B6B);

  static const double radius = 8;
  static const double cardRadius = 10;
  static const double posterRatio = 2 / 3; // posters are rendered 400x600 on the site

  static const brandGradient = LinearGradient(colors: [brand2, brand], begin: Alignment.topLeft, end: Alignment.bottomRight);

  static ThemeData dark() => _build(PmPalette.dark, Brightness.dark);
  static ThemeData light() => _build(PmPalette.light, Brightness.light);

  static ThemeData _build(PmPalette c, Brightness b) {
    final scheme = ColorScheme.fromSeed(seedColor: brand, brightness: b).copyWith(
      primary: brand,
      onPrimary: Colors.white,
      secondary: brand2,
      surface: c.surface,
      onSurface: c.text,
      outline: c.border,
      error: b == Brightness.dark ? errorRed : const Color(0xFFD32F2F),
    );
    return ThemeData(
      useMaterial3: true,
      brightness: b,
      colorScheme: scheme,
      scaffoldBackgroundColor: c.bg,
      extensions: [c],
      appBarTheme: AppBarTheme(
        backgroundColor: c.bg,
        foregroundColor: c.text,
        elevation: 0,
        scrolledUnderElevation: 0,
        centerTitle: false,
        titleTextStyle: TextStyle(color: c.text, fontSize: 18, fontWeight: FontWeight.w800),
      ),
      navigationBarTheme: NavigationBarThemeData(
        backgroundColor: c.surface,
        indicatorColor: brand.withOpacity(.16),
        labelTextStyle: WidgetStateProperty.all(TextStyle(fontSize: 12, color: c.muted)),
      ),
      filledButtonTheme: FilledButtonThemeData(
        style: FilledButton.styleFrom(backgroundColor: brand, foregroundColor: Colors.white, minimumSize: const Size(48, 48), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(radius)), textStyle: const TextStyle(fontWeight: FontWeight.w700)),
      ),
      outlinedButtonTheme: OutlinedButtonThemeData(
        style: OutlinedButton.styleFrom(foregroundColor: c.text, minimumSize: const Size(48, 48), side: BorderSide(color: c.border), backgroundColor: c.card2, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(radius)), textStyle: const TextStyle(fontWeight: FontWeight.w700)),
      ),
      textButtonTheme: TextButtonThemeData(style: TextButton.styleFrom(foregroundColor: brand2)),
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: c.card2,
        hintStyle: TextStyle(color: c.muted),
        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(20), borderSide: BorderSide(color: c.border)),
        enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(20), borderSide: BorderSide(color: c.border)),
        focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(20), borderSide: const BorderSide(color: brand)),
      ),
      chipTheme: ChipThemeData(backgroundColor: c.card2, side: BorderSide(color: c.border), labelStyle: TextStyle(color: c.text, fontSize: 12)),
      dividerColor: c.border,
      listTileTheme: ListTileThemeData(iconColor: c.muted, textColor: c.text),
      snackBarTheme: SnackBarThemeData(behavior: SnackBarBehavior.floating, backgroundColor: c.card2, contentTextStyle: TextStyle(color: c.text)),
    );
  }
}
