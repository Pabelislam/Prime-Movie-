/// Maps the language codes found inside video files (ISO 639-1/2/3, as reported by mpv) to display names.
const _names = {
  'en': 'English', 'eng': 'English',
  'bn': 'Bangla', 'ben': 'Bangla', 'bng': 'Bangla',
  'hi': 'Hindi', 'hin': 'Hindi',
  'ur': 'Urdu', 'urd': 'Urdu',
  'ta': 'Tamil', 'tam': 'Tamil',
  'te': 'Telugu', 'tel': 'Telugu',
  'ml': 'Malayalam', 'mal': 'Malayalam',
  'kn': 'Kannada', 'kan': 'Kannada',
  'mr': 'Marathi', 'mar': 'Marathi',
  'pa': 'Punjabi', 'pan': 'Punjabi',
  'gu': 'Gujarati', 'guj': 'Gujarati',
  'ne': 'Nepali', 'nep': 'Nepali',
  'ar': 'Arabic', 'ara': 'Arabic',
  'es': 'Spanish', 'spa': 'Spanish',
  'fr': 'French', 'fra': 'French', 'fre': 'French',
  'de': 'German', 'deu': 'German', 'ger': 'German',
  'ja': 'Japanese', 'jpn': 'Japanese',
  'ko': 'Korean', 'kor': 'Korean',
  'zh': 'Chinese', 'zho': 'Chinese', 'chi': 'Chinese',
  'ru': 'Russian', 'rus': 'Russian',
  'pt': 'Portuguese', 'por': 'Portuguese',
  'it': 'Italian', 'ita': 'Italian',
  'tr': 'Turkish', 'tur': 'Turkish',
  'th': 'Thai', 'tha': 'Thai',
  'id': 'Indonesian', 'ind': 'Indonesian',
  'ms': 'Malay', 'msa': 'Malay', 'may': 'Malay',
};

String? languageName(String? code) {
  if (code == null) return null;
  final c = code.trim().toLowerCase();
  if (c.isEmpty || c == 'und' || c == 'auto' || c == 'no') return null;
  return _names[c] ?? _names[c.split(RegExp(r'[-_]')).first];
}

/// Label for a track picker row: "Hindi", "English - Commentary", or "Track 2" when the file has no metadata.
String trackLabel({String? language, String? title, required int index}) {
  final lang = languageName(language);
  final t = (title ?? '').trim();
  if (lang != null) {
    return (t.isNotEmpty && t.toLowerCase() != lang.toLowerCase() && t.toLowerCase() != (language ?? '').toLowerCase()) ? '$lang - $t' : lang;
  }
  if (t.isNotEmpty) return t;
  return 'Track $index';
}
