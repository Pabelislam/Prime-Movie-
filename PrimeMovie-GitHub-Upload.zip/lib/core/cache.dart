import 'package:path/path.dart' as p;
import 'package:sqflite/sqflite.dart';

/// Key/value JSON cache for non-sensitive API responses. Auth tokens are NOT stored here.
abstract class CacheStore {
  Future<CacheEntry?> get(String key);
  Future<void> put(String key, String json);
  Future<void> clearPrefix(String prefix);
  Future<void> clearAll();
}

class CacheEntry {
  final String json;
  final DateTime savedAt;
  const CacheEntry(this.json, this.savedAt);
  Duration get age => DateTime.now().difference(savedAt);
}

class SqliteCache implements CacheStore {
  Database? _db;

  Future<Database> _open() async {
    return _db ??= await openDatabase(
      p.join(await getDatabasesPath(), 'primemovie_cache.db'),
      version: 1,
      onCreate: (db, v) => db.execute('CREATE TABLE cache (k TEXT PRIMARY KEY, v TEXT NOT NULL, t INTEGER NOT NULL)'),
    );
  }

  @override
  Future<CacheEntry?> get(String key) async {
    final rows = await (await _open()).query('cache', where: 'k = ?', whereArgs: [key], limit: 1);
    if (rows.isEmpty) return null;
    return CacheEntry(rows.first['v'] as String, DateTime.fromMillisecondsSinceEpoch(rows.first['t'] as int));
  }

  @override
  Future<void> put(String key, String json) async {
    await (await _open()).insert('cache', {'k': key, 'v': json, 't': DateTime.now().millisecondsSinceEpoch}, conflictAlgorithm: ConflictAlgorithm.replace);
  }

  @override
  Future<void> clearPrefix(String prefix) async => (await _open()).delete('cache', where: 'k LIKE ?', whereArgs: ['$prefix%']);

  @override
  Future<void> clearAll() async => (await _open()).delete('cache');
}

class MemoryCache implements CacheStore {
  final Map<String, CacheEntry> _m = {};
  @override
  Future<CacheEntry?> get(String key) async => _m[key];
  @override
  Future<void> put(String key, String json) async => _m[key] = CacheEntry(json, DateTime.now());
  @override
  Future<void> clearPrefix(String prefix) async => _m.removeWhere((k, _) => k.startsWith(prefix));
  @override
  Future<void> clearAll() async => _m.clear();
}
