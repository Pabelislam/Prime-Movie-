import 'dart:async';
import 'dart:convert';
import 'package:dio/dio.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'config.dart';

class ApiResponse {
  final dynamic data;
  final Map<String, dynamic> meta;
  const ApiResponse(this.data, this.meta);
}

class ApiError implements Exception {
  final int? status; // null = no HTTP response (offline / timeout)
  final String code;
  final String message;
  final Map<String, dynamic> details;
  const ApiError(this.status, this.code, this.message, [this.details = const {}]);

  bool get isNetwork => status == null;
  bool get isRetryable => status == null || status! >= 500;
  bool get isUnauthorized => status == 401;
  bool get isRateLimited => status == 429;
  int? get retryAfter => details['retry_after'] is int ? details['retry_after'] as int : null;
  String? fieldMessage(String field) => details[field]?.toString();

  @override
  String toString() => 'ApiError($status, $code, $message)';
}

class Tokens {
  final String access;
  final String refresh;
  const Tokens(this.access, this.refresh);
}

abstract class TokenStore {
  Future<Tokens?> read();
  Future<void> write(Tokens t);
  Future<void> clear();
}

/// Tokens live in Android Keystore-backed encrypted storage - never in the SQLite cache.
class SecureTokenStore implements TokenStore {
  static const _a = 'pm_access';
  static const _r = 'pm_refresh';
  final FlutterSecureStorage _s;
  SecureTokenStore([FlutterSecureStorage? s]) : _s = s ?? const FlutterSecureStorage(aOptions: AndroidOptions(encryptedSharedPreferences: true));

  @override
  Future<Tokens?> read() async {
    final a = await _s.read(key: _a);
    final r = await _s.read(key: _r);
    return (a == null || r == null) ? null : Tokens(a, r);
  }

  @override
  Future<void> write(Tokens t) async {
    await _s.write(key: _a, value: t.access);
    await _s.write(key: _r, value: t.refresh);
  }

  @override
  Future<void> clear() async {
    await _s.delete(key: _a);
    await _s.delete(key: _r);
  }
}

class MemoryTokenStore implements TokenStore {
  Tokens? _t;
  @override
  Future<Tokens?> read() async => _t;
  @override
  Future<void> write(Tokens t) async => _t = t;
  @override
  Future<void> clear() async => _t = null;
}

class ApiClient {
  final Dio _dio;
  final Dio _bare; // refresh calls bypass auth handling (no loops)
  final TokenStore tokens;
  void Function()? onSessionExpired;
  Future<bool>? _refreshing; // single-flight: concurrent 401s share one refresh

  ApiClient({required this.tokens, Dio? dio, Dio? bare, String? baseUrl})
      : _dio = dio ?? _make(baseUrl),
        _bare = bare ?? _make(baseUrl);

  static Dio _make(String? baseUrl) => Dio(BaseOptions(
        baseUrl: baseUrl ?? AppConfig.baseUrl,
        connectTimeout: const Duration(seconds: 10),
        receiveTimeout: const Duration(seconds: 20),
        sendTimeout: const Duration(seconds: 20),
        headers: {'Accept': 'application/json'},
        validateStatus: (_) => true, // errors are mapped from the API envelope
      ));

  Future<Response<dynamic>> _send(String method, String path, Map<String, dynamic>? query, Object? body, bool auth, CancelToken? cancel) async {
    final headers = <String, dynamic>{};
    if (auth) {
      final t = await tokens.read();
      if (t != null) headers['Authorization'] = 'Bearer ${t.access}';
    }
    return _dio.request<dynamic>(path,
        queryParameters: _clean(query),
        data: body,
        cancelToken: cancel,
        options: Options(method: method, headers: headers, contentType: body == null ? null : Headers.jsonContentType));
  }

  Future<ApiResponse> request(String method, String path, {Map<String, dynamic>? query, Object? body, bool auth = true, CancelToken? cancel}) async {
    try {
      final sentWith = auth ? (await tokens.read())?.access : null;
      var res = await _send(method, path, query, body, auth, cancel);
      if (res.statusCode == 401 && auth && sentWith != null) {
        final now = await tokens.read();
        // If another request already refreshed while this one was in flight, just retry with the new token.
        final usable = (now != null && now.access != sentWith) || await _refresh();
        if (usable) res = await _send(method, path, query, body, auth, cancel); // retried exactly once
      }
      return _unwrap(res);
    } on DioException catch (e) {
      throw _network(e);
    }
  }

  Future<ApiResponse> get(String path, {Map<String, dynamic>? query, bool auth = true, CancelToken? cancel}) => request('GET', path, query: query, auth: auth, cancel: cancel);
  Future<ApiResponse> post(String path, {Object? body, bool auth = true}) => request('POST', path, body: body ?? <String, dynamic>{}, auth: auth);
  Future<ApiResponse> put(String path, {Object? body}) => request('PUT', path, body: body ?? <String, dynamic>{});
  Future<ApiResponse> patch(String path, {Object? body}) => request('PATCH', path, body: body ?? <String, dynamic>{});
  Future<ApiResponse> delete(String path) => request('DELETE', path);

  Future<bool> _refresh() {
    return _refreshing ??= () async {
      try {
        final t = await tokens.read();
        if (t == null) return false;
        final res = await _bare.post<dynamic>('auth/refresh', data: {'refresh_token': t.refresh}, options: Options(contentType: Headers.jsonContentType));
        await saveTokensFrom(_unwrap(res).data);
        return true;
      } on ApiError catch (e) {
        if (e.status != null && e.status! >= 400 && e.status! < 500) {
          await tokens.clear(); // refresh token rejected: the session is over
          onSessionExpired?.call();
        }
        return false;
      } on DioException {
        return false; // network failure keeps stored tokens so a later attempt can succeed
      } finally {
        _refreshing = null;
      }
    }();
  }

  /// Persists the pair returned by login/register/refresh (`data.tokens`).
  Future<void> saveTokensFrom(dynamic data) async {
    final t = (data is Map ? data['tokens'] : null);
    if (t is! Map || t['access_token'] is! String || t['refresh_token'] is! String) {
      throw const ApiError(null, 'bad_response', 'Unexpected server response.');
    }
    await tokens.write(Tokens(t['access_token'] as String, t['refresh_token'] as String));
  }

  static Map<String, dynamic>? _clean(Map<String, dynamic>? q) {
    if (q == null) return null;
    final m = <String, dynamic>{};
    q.forEach((k, v) {
      if (v != null && v.toString().isNotEmpty) m[k] = v;
    });
    return m;
  }

  ApiResponse _unwrap(Response<dynamic> res) {
    dynamic body = res.data;
    if (body is String) {
      try {
        body = jsonDecode(body);
      } catch (_) {
        body = null;
      }
    }
    final status = res.statusCode ?? 0;
    if (body is! Map) {
      throw ApiError(status == 0 ? null : status, 'bad_response', status >= 500 ? 'The server had a problem. Try again.' : 'Unexpected server response.');
    }
    if (body['success'] == true && status < 300) {
      final meta = body['meta'] is Map ? Map<String, dynamic>.from(body['meta'] as Map) : <String, dynamic>{};
      return ApiResponse(body['data'], meta);
    }
    final err = body['error'] is Map ? body['error'] as Map : const {};
    throw ApiError(status, (err['code'] ?? 'error').toString(), (err['message'] ?? 'Something went wrong.').toString(),
        err['details'] is Map ? Map<String, dynamic>.from(err['details'] as Map) : const {});
  }

  ApiError _network(DioException e) {
    if (e.type == DioExceptionType.cancel) return const ApiError(null, 'cancelled', 'Request cancelled.');
    if (e.type == DioExceptionType.connectionTimeout || e.type == DioExceptionType.receiveTimeout || e.type == DioExceptionType.sendTimeout) {
      return const ApiError(null, 'timeout', 'The connection timed out. Check your internet and try again.');
    }
    return const ApiError(null, 'offline', "Can't reach the server. Check your internet connection.");
  }
}
