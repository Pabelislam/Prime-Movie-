import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'core/theme.dart';
import 'data/player_args.dart';
import 'data/repositories.dart';
import 'features/account_screens.dart';
import 'features/auth_screens.dart';
import 'features/browse_screens.dart';
import 'features/detail_screen.dart';
import 'features/downloads_screen.dart';
import 'features/home_screen.dart';
import 'features/settings_screen.dart';
import 'widgets/anim.dart';
import 'widgets/common.dart';

final _root = GlobalKey<NavigatorState>();

/// Slugs from deep links are validated before they reach the API.
final _slugRe = RegExp(r'^[A-Za-z0-9\-]{1,255}$');

final routerProvider = Provider<GoRouter>((ref) {
  return GoRouter(
    navigatorKey: _root,
    initialLocation: '/',
    errorBuilder: (_, __) => Scaffold(appBar: AppBar(), body: const EmptyView(icon: Icons.explore_off_outlined, title: 'Page not found')),
    routes: [
      StatefulShellRoute.indexedStack(
        builder: (context, state, shell) => Scaffold(
          extendBody: true,
          body: shell,
          bottomNavigationBar: _GlassNav(index: shell.currentIndex, onTap: (i) => shell.goBranch(i, initialLocation: i == shell.currentIndex)),
        ),
        branches: [
          StatefulShellBranch(routes: [GoRoute(path: '/', builder: (_, __) => const HomeScreen())]),
          StatefulShellBranch(routes: [GoRoute(path: '/search', builder: (_, __) => const SearchScreen())]),
          StatefulShellBranch(routes: [GoRoute(path: '/downloads', builder: (_, __) => const DownloadsScreen())]),
          StatefulShellBranch(routes: [GoRoute(path: '/library', builder: (_, __) => const LibraryScreen())]),
          StatefulShellBranch(routes: [GoRoute(path: '/profile', builder: (_, __) => const ProfileScreen())]),
        ],
      ),
      GoRoute(
        path: '/movie/:slug',
        parentNavigatorKey: _root,
        redirect: (_, s) => _slugRe.hasMatch(s.pathParameters['slug'] ?? '') ? null : '/',
        builder: (_, s) => DetailScreen(slug: s.pathParameters['slug']!),
      ),
      GoRoute(
        path: '/browse',
        parentNavigatorKey: _root,
        builder: (_, s) {
          final p = s.uri.queryParameters;
          const sorts = {'latest', 'popularity', 'rating', 'release_date', 'title'};
          final genre = p['genre'];
          return BrowseScreen(
            title: (p['title'] ?? 'Movies').substring(0, (p['title'] ?? 'Movies').length.clamp(0, 60)),
            query: MovieQuery(genre: genre != null && _slugRe.hasMatch(genre) ? genre : null, sort: sorts.contains(p['sort']) ? p['sort'] : 'latest'),
          );
        },
      ),
      GoRoute(
        path: '/player',
        parentNavigatorKey: _root,
        redirect: (_, s) => s.extra is PlayerArgs ? null : '/downloads',
        builder: (_, s) => PlayerScreen(args: s.extra as PlayerArgs),
      ),
      GoRoute(path: '/settings', parentNavigatorKey: _root, builder: (_, __) => const SettingsScreen()),
      GoRoute(path: '/login', parentNavigatorKey: _root, builder: (_, __) => const LoginScreen()),
      GoRoute(path: '/register', parentNavigatorKey: _root, builder: (_, __) => const RegisterScreen()),
      GoRoute(path: '/forgot', parentNavigatorKey: _root, builder: (_, __) => const ForgotScreen()),
      GoRoute(path: '/my-reviews', parentNavigatorKey: _root, builder: (_, __) => const MyReviewsScreen()),
    ],
  );
});


/// Floating frosted navigation bar; the active tab gets a soft pill and its icon scales up.
class _GlassNav extends StatelessWidget {
  final int index;
  final ValueChanged<int> onTap;
  const _GlassNav({required this.index, required this.onTap});

  static const _items = [
    (Icons.home_outlined, Icons.home_rounded, 'Home'),
    (Icons.search, Icons.search, 'Search'),
    (Icons.download_for_offline_outlined, Icons.download_for_offline, 'Downloads'),
    (Icons.bookmarks_outlined, Icons.bookmarks, 'Library'),
    (Icons.person_outline, Icons.person, 'Profile'),
  ];

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      minimum: const EdgeInsets.fromLTRB(14, 0, 14, 10),
      child: Glass(
        radius: 24,
        padding: const EdgeInsets.all(6),
        child: Row(children: [
          for (var i = 0; i < _items.length; i++)
            Expanded(
              child: Semantics(
                button: true,
                selected: i == index,
                label: _items[i].$3,
                child: GestureDetector(
                  behavior: HitTestBehavior.opaque,
                  onTap: () => onTap(i),
                  child: AnimatedContainer(
                    duration: const Duration(milliseconds: 260),
                    curve: Curves.easeOutCubic,
                    padding: const EdgeInsets.symmetric(vertical: 7),
                    decoration: BoxDecoration(color: i == index ? Pm.brand.withOpacity(.16) : Colors.transparent, borderRadius: BorderRadius.circular(18)),
                    child: Column(mainAxisSize: MainAxisSize.min, children: [
                      AnimatedScale(scale: i == index ? 1.14 : 1, duration: const Duration(milliseconds: 260), curve: Curves.easeOutBack, child: Icon(i == index ? _items[i].$2 : _items[i].$1, size: 23, color: i == index ? Pm.brand2 : context.pm.muted)),
                      const SizedBox(height: 2),
                      AnimatedDefaultTextStyle(duration: const Duration(milliseconds: 260), style: TextStyle(fontSize: 10, fontWeight: i == index ? FontWeight.w700 : FontWeight.w500, color: i == index ? context.pm.text : context.pm.muted), child: Text(_items[i].$3)),
                    ]),
                  ),
                ),
              ),
            ),
        ]),
      ),
    );
  }
}
