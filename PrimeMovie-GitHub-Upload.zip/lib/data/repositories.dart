import 'dart:convert';
import '../core/api_client.dart';
import '../core/cache.dart';
import 'models.dart';

/// Result wrapper telling the UI whether data came from the offline cache.
class Cached<T> {
  final T data;
  final bool fromCache;
  const Cached(this.data, {this.fromCache = false});
}

class MovieQuery {
  final String? q, genre, language, country, sort, order;
  final int? year;
  final int page;
  const MovieQuery({this.q, this.genre, this.language, this.country, this.sort, this.order, this.year, this.page = 1});
  MovieQuery withPage(int p) => MovieQuery(q: q, genre: genre, language: language, country: country, sort: sort, order: order, year: year, page: p);
  Map<String, dynamic> toParams() => {'q': q, 'genre': genre, 'language': language, 'country': country, 'sort': sort, 'order': order, 'year': year, 'page': page, 'per_page': 20};
  String get key => 'movies:${jsonEncode(toParams())}';
  @override
  bool operator ==(Object o) => o is MovieQuery && o.key == key;
  @override
  int get hashCode => key.hashCode;
}

class ContentRepository {
  final ApiClient api;
  final CacheStore cache;
  ContentRepository(this.api, this.cache);

  /// Network first so admin changes on the website show up immediately; the SQLite copy is only used when the
  /// network is unavailable or the server has a 5xx problem. 4xx errors (e.g. 404 for a deleted movie) are never masked.
  Future<Cached<ApiResponse>> _cachedGet(String key, String path, {Map<String, dynamic>? query, bool auth = false}) async {
    try {
      final r = await api.get(path, query: query, auth: auth);
      await cache.put(key, jsonEncode({'data': r.data, 'meta': r.meta}));
      return Cached(r);
    } on ApiError catch (e) {
      if (!e.isRetryable) {
        if (e.status == 404) await cache.put(key, jsonEncode({'gone': true}));
        rethrow;
      }
      final c = await cache.get(key);
      if (c == null) rethrow;
      final j = jsonDecode(c.json);
      if (j is! Map || j['gone'] == true) rethrow;
      return Cached(ApiResponse(j['data'], Map<String, dynamic>.from(j['meta'] as Map? ?? {})), fromCache: true);
    }
  }

  Paged<Movie> _paged(Cached<ApiResponse> c) {
    final items = c.data.data is List ? (c.data.data as List).whereType<Map>().map((e) => Movie.fromJson(Map<String, dynamic>.from(e))).toList() : <Movie>[];
    final m = c.data.meta;
    return Paged(items: items, page: (m['page'] as num?)?.toInt() ?? 1, total: (m['total'] as num?)?.toInt() ?? items.length, hasMore: m['has_more'] == true, fromCache: c.fromCache);
  }

  Future<RemoteConfig> config() async {
    try {
      final c = await _cachedGet('config', 'config');
      return RemoteConfig.fromJson(c.data.data);
    } catch (_) {
      return RemoteConfig.defaults; // never block the app on a config failure
    }
  }

  Future<Paged<Movie>> movies(MovieQuery q) async => _paged(await _cachedGet(q.key, 'movies', query: q.toParams()));

  /// kind: trending | popular | latest | featured
  Future<Paged<Movie>> collection(String kind, {int perPage = 12}) async =>
      _paged(await _cachedGet('collection:$kind:$perPage', 'movies/$kind', query: {'per_page': perPage}));

  Future<Cached<Movie>> movie(String slug) async {
    final c = await _cachedGet('movie:$slug', 'movies/${Uri.encodeComponent(slug)}');
    return Cached(Movie.fromJson(Map<String, dynamic>.from(c.data.data as Map)), fromCache: c.fromCache);
  }

  Future<List<Movie>> related(String slug) async {
    final c = await _cachedGet('related:$slug', 'movies/${Uri.encodeComponent(slug)}/related');
    return _paged(c).items;
  }

  Future<List<Genre>> categories() async {
    final c = await _cachedGet('categories', 'categories');
    final d = c.data.data;
    return d is List ? d.whereType<Map>().map((e) => Genre.fromJson(Map<String, dynamic>.from(e))).toList() : <Genre>[];
  }

  Future<List<String>> _names(String key, String path) async {
    final c = await _cachedGet(key, path);
    final d = c.data.data;
    return d is List ? d.whereType<Map>().map((e) => (e['name'] ?? '').toString()).where((n) => n.isNotEmpty).toList() : <String>[];
  }

  Future<List<String>> languages() => _names('languages', 'languages');
  Future<List<String>> countries() => _names('countries', 'countries');

  Future<List<String>> suggest(String q) async {
    final r = await api.get('search/suggest', query: {'q': q}, auth: false);
    final d = r.data;
    return d is List ? d.whereType<Map>().map((e) => (e['title'] ?? '').toString()).where((s) => s.isNotEmpty).toList() : <String>[];
  }

  Future<Paged<Review>> reviews(String slug, {int page = 1}) async {
    final r = await api.get('movies/${Uri.encodeComponent(slug)}/reviews', query: {'page': page, 'per_page': 20});
    final items = (r.data as List).whereType<Map>().map((e) => Review.fromJson(Map<String, dynamic>.from(e))).toList();
    return Paged(items: items, page: page, total: (r.meta['total'] as num?)?.toInt() ?? items.length, hasMore: r.meta['has_more'] == true);
  }

  /// Signed URLs expire, so this is never cached; call it right before streaming or downloading.
  Future<List<AppMediaSource>> appMedia(String slug) async {
    final r = await api.get('movies/${Uri.encodeComponent(slug)}/app-media');
    final d = r.data;
    return d is List ? d.whereType<Map>().map((e) => AppMediaSource.fromJson(Map<String, dynamic>.from(e))).toList() : <AppMediaSource>[];
  }

  Future<void> recordView(String slug) async {
    try {
      await api.post('movies/${Uri.encodeComponent(slug)}/view');
    } catch (_) {/* analytics only; never surfaces to the user */}
  }

  /// Called on pull-to-refresh / app resume so the next reads hit the server.
  Future<void> invalidateContent() async {
    await cache.clearPrefix('collection:');
    await cache.clearPrefix('movies:');
  }
}

class AccountRepository {
  final ApiClient api;
  final CacheStore cache;
  AccountRepository(this.api, this.cache);

  Future<UserProfile> login(String email, String password, {String device = 'Android'}) async {
    final r = await api.post('auth/login', body: {'email': email, 'password': password, 'device_name': device}, auth: false);
    await api.saveTokensFrom(r.data);
    return UserProfile.fromJson(Map<String, dynamic>.from((r.data as Map)['user'] as Map));
  }

  Future<UserProfile> register(String email, String name, String password, {String device = 'Android'}) async {
    final r = await api.post('auth/register', body: {'email': email, 'display_name': name, 'password': password, 'device_name': device}, auth: false);
    await api.saveTokensFrom(r.data);
    return UserProfile.fromJson(Map<String, dynamic>.from((r.data as Map)['user'] as Map));
  }

  Future<UserProfile?> restore() async {
    if (await api.tokens.read() == null) return null;
    try {
      final r = await api.get('me');
      return UserProfile.fromJson(Map<String, dynamic>.from(r.data as Map));
    } on ApiError catch (e) {
      if (e.isNetwork || e.status! >= 500) rethrow; // keep tokens, let the UI retry
      await api.tokens.clear();
      return null;
    }
  }

  Future<void> logout() async {
    try {
      await api.post('auth/logout');
    } catch (_) {/* revoke is best-effort; local tokens are cleared regardless */}
    await clearLocal();
  }

  Future<void> logoutAll() async {
    try {
      await api.post('auth/logout-all');
    } catch (_) {}
    await clearLocal();
  }

  Future<void> clearLocal() async {
    await api.tokens.clear();
    await cache.clearPrefix('me:');
  }

  Future<void> forgot(String email) => api.post('auth/password/forgot', body: {'email': email}, auth: false);
  Future<void> reset(String token, String password) => api.post('auth/password/reset', body: {'token': token, 'password': password}, auth: false);
  Future<UserProfile> updateName(String name) async => UserProfile.fromJson(Map<String, dynamic>.from((await api.patch('me', body: {'display_name': name})).data as Map));
  Future<void> changePassword(String current, String next) => api.post('me/password', body: {'current_password': current, 'new_password': next});

  Future<Map<String, dynamic>> preferences() async => Map<String, dynamic>.from(((await api.get('me/preferences')).data as Map?) ?? {});
  Future<void> savePreferences(Map<String, dynamic> p) => api.put('me/preferences', body: p);

  // lists: 'watchlist' | 'favorites'
  Future<Paged<Movie>> list(String type, {int page = 1}) async {
    final r = await api.get('me/$type', query: {'page': page, 'per_page': 50});
    final items = (r.data as List).whereType<Map>().map((e) => Movie.fromJson(Map<String, dynamic>.from(e))).toList();
    return Paged(items: items, page: page, total: (r.meta['total'] as num?)?.toInt() ?? items.length, hasMore: r.meta['has_more'] == true);
  }

  Future<Set<int>> listIds(String type) async {
    final ids = <int>{};
    for (var page = 1; page <= 10; page++) {
      final p = await list(type, page: page);
      ids.addAll(p.items.map((m) => m.id));
      if (!p.hasMore) break;
    }
    return ids;
  }

  Future<void> addToList(String type, int movieId) => api.put('me/$type/$movieId');
  Future<void> removeFromList(String type, int movieId) => api.delete('me/$type/$movieId');
  Future<Paged<Movie>> recent({int page = 1}) => list('recent', page: page);
  Future<void> clearRecent() => api.delete('me/recent');
  Future<List<Movie>> recommendations() async {
    final r = await api.get('me/recommendations', query: {'limit': 20});
    return (r.data as List).whereType<Map>().map((e) => Movie.fromJson(Map<String, dynamic>.from(e))).toList();
  }

  Future<List<Review>> myReviews() async {
    final r = await api.get('me/reviews', query: {'per_page': 50});
    return (r.data as List).whereType<Map>().map((e) => Review.fromJson(Map<String, dynamic>.from(e))).toList();
  }

  Future<void> createReview(String slug, int rating, String body, bool spoiler) =>
      api.post('movies/${Uri.encodeComponent(slug)}/reviews', body: {'rating': rating, 'body': body, 'is_spoiler': spoiler});
  Future<void> updateReview(int id, int rating, String body, bool spoiler) => api.put('reviews/$id', body: {'rating': rating, 'body': body, 'is_spoiler': spoiler});
  Future<void> deleteReview(int id) => api.delete('reviews/$id');
  Future<void> reportReview(int id, String reason) => api.post('reviews/$id/report', body: {'reason': reason});
}
