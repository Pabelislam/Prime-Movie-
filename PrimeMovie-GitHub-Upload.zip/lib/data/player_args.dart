/// Everything the player needs. Either [localPath] (downloaded file, works offline) or [streamUrl] is set.
class PlayerSubtitle {
  final String label;
  final String? language;
  final String? uri; // https URL (streaming) or local file path (downloaded); null when the subtitle is inside the media file
  final int? embeddedIndex; // 1-based among the file's own subtitle tracks
  const PlayerSubtitle({required this.label, this.language, this.uri, this.embeddedIndex});
}

class PlayerAudio {
  final String label;
  final String? language;
  final int? trackIndex; // 1-based among the file's own audio tracks
  final String? uri; // external audio file
  const PlayerAudio({required this.label, this.language, this.trackIndex, this.uri});
}

class PlayerArgs {
  final String title;
  final int movieId;
  final int sourceId;
  final String? localPath;
  final String? streamUrl;
  final List<PlayerAudio> audio;
  final List<PlayerSubtitle> subtitles;

  /// Returns a fresh signed stream URL (used by "Retry" after a link expired or the connection failed).
  final Future<String?> Function()? refreshUrl;

  const PlayerArgs({required this.title, required this.movieId, required this.sourceId, this.localPath, this.streamUrl, this.audio = const [], this.subtitles = const [], this.refreshUrl});

  bool get isLocal => localPath != null;
}
