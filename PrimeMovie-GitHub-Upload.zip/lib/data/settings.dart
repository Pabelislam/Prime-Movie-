import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter_cache_manager/flutter_cache_manager.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:path_provider/path_provider.dart';
import '../providers.dart';

enum SubtitleSize { small, medium, large }

class AppSettings {
  final ThemeMode themeMode;
  final String downloadLocation; // 'phone' (app-private internal storage) | 'sd' (app folder on the SD card)
  final bool wifiOnly;
  final SubtitleSize subtitleSize;
  const AppSettings({this.themeMode = ThemeMode.dark, this.downloadLocation = 'phone', this.wifiOnly = false, this.subtitleSize = SubtitleSize.medium});

  double get subtitleFontSize => switch (subtitleSize) { SubtitleSize.small => 18, SubtitleSize.medium => 24, SubtitleSize.large => 30 };

  AppSettings copyWith({ThemeMode? themeMode, String? downloadLocation, bool? wifiOnly, SubtitleSize? subtitleSize}) =>
      AppSettings(themeMode: themeMode ?? this.themeMode, downloadLocation: downloadLocation ?? this.downloadLocation, wifiOnly: wifiOnly ?? this.wifiOnly, subtitleSize: subtitleSize ?? this.subtitleSize);

  Map<String, dynamic> toJson() => {'theme': themeMode.name, 'loc': downloadLocation, 'wifi': wifiOnly, 'sub': subtitleSize.name};

  /// Tolerant parser: unknown or malformed values fall back to defaults.
  factory AppSettings.fromJson(dynamic j) {
    if (j is! Map) return const AppSettings();
    return AppSettings(
      themeMode: ThemeMode.values.where((e) => e.name == j['theme']).firstOrNull ?? ThemeMode.dark,
      downloadLocation: j['loc'] == 'sd' ? 'sd' : 'phone',
      wifiOnly: j['wifi'] == true,
      subtitleSize: SubtitleSize.values.where((e) => e.name == j['sub']).firstOrNull ?? SubtitleSize.medium,
    );
  }
}

class SettingsNotifier extends AsyncNotifier<AppSettings> {
  static const _key = 'settings:v1';

  @override
  Future<AppSettings> build() async {
    final c = await ref.read(cacheProvider).get(_key);
    if (c == null) return const AppSettings();
    try {
      return AppSettings.fromJson(jsonDecode(c.json));
    } catch (_) {
      return const AppSettings();
    }
  }

  Future<void> updateSettings(AppSettings Function(AppSettings) f) async {
    final next = f(state.valueOrNull ?? const AppSettings());
    state = AsyncData(next);
    await ref.read(cacheProvider).put(_key, jsonEncode(next.toJson()));
  }
}

final settingsProvider = AsyncNotifierProvider<SettingsNotifier, AppSettings>(SettingsNotifier.new);

/// Where downloads can be stored. Both locations are app-specific folders, so no storage permission is needed and other
/// apps cannot read them.
class StorageVolume {
  final String id; // 'phone' | 'sd'
  final String label;
  final String? basePath; // null = default private app folder (BaseDirectory.applicationSupport)
  const StorageVolume(this.id, this.label, this.basePath);
}

Future<List<StorageVolume>> detectVolumes() async {
  final out = <StorageVolume>[const StorageVolume('phone', 'Phone storage', null)];
  try {
    final dirs = await getExternalStorageDirectories(); // [0] = primary (phone), [1..] = SD card / USB
    if (dirs != null && dirs.length > 1) {
      final sd = Directory('${dirs[1].path}/downloads');
      await sd.create(recursive: true);
      out.add(StorageVolume('sd', 'SD card', sd.path));
    }
  } catch (_) {/* no removable storage */}
  return out;
}

final storageVolumesProvider = FutureProvider<List<StorageVolume>>((ref) => detectVolumes());

/// Clears downloaded-metadata and image caches. Settings, resume positions and downloads are NOT touched.
Future<void> clearContentCache(WidgetRef ref) async {
  final cache = ref.read(cacheProvider);
  for (final prefix in const ['movies:', 'collection:', 'movie:', 'related:', 'categories', 'languages', 'countries', 'config']) {
    await cache.clearPrefix(prefix);
  }
  PaintingBinding.instance.imageCache.clear();
  await DefaultCacheManager().emptyCache();
}

Future<void> clearWatchPositions(WidgetRef ref) => ref.read(cacheProvider).clearPrefix('pos:');
