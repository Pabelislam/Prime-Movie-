import 'package:disk_space_plus/disk_space_plus.dart';

/// Free internal storage in bytes, or null when the platform cannot tell. (SD-card space is not checked.)
Future<int?> freeSpaceBytes() async {
  try {
    final mb = await DiskSpacePlus().getFreeDiskSpace; // reported in megabytes
    return mb == null ? null : (mb * 1024 * 1024).round();
  } catch (_) {
    return null;
  }
}
