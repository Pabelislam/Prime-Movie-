String? _s(dynamic v) {
  if (v == null) return null;
  final s = v.toString().trim();
  return s.isEmpty ? null : s;
}

int _i(dynamic v, [int d = 0]) => v is int ? v : (v is num ? v.toInt() : int.tryParse('$v') ?? d);
double? _d(dynamic v) => v is num ? v.toDouble() : double.tryParse('${v ?? ''}');
List<T> _list<T>(dynamic v, T Function(Map<String, dynamic>) f) =>
    v is List ? v.whereType<Map>().map((e) => f(Map<String, dynamic>.from(e))).toList() : <T>[];
List<String> _strings(dynamic v) => v is List ? v.map((e) => e.toString()).toList() : <String>[];

class Genre {
  final int id;
  final String name;
  final String slug;
  final int movieCount;
  const Genre({required this.id, required this.name, required this.slug, this.movieCount = 0});
  factory Genre.fromJson(Map<String, dynamic> j) => Genre(id: _i(j['id']), name: _s(j['name']) ?? '', slug: _s(j['slug']) ?? '', movieCount: _i(j['movie_count']));
}

class DownloadOption {
  final int id;
  final String quality;
  final String? fileSize;
  final String? server;
  final String url;
  const DownloadOption({required this.id, required this.quality, this.fileSize, this.server, required this.url});
  factory DownloadOption.fromJson(Map<String, dynamic> j) =>
      DownloadOption(id: _i(j['id']), quality: _s(j['quality']) ?? '', fileSize: _s(j['file_size']), server: _s(j['server']), url: _s(j['url']) ?? '');
}

class ReviewSummary {
  final int count;
  final double? average;
  const ReviewSummary(this.count, this.average);
}

class Movie {
  final int id;
  final String slug;
  final String title;
  final String? url;
  final String? posterUrl;
  final String? posterFullUrl;
  final int? releaseYear;
  final List<Genre> genres;
  final String? language;
  final String? country;
  final String? quality;
  final String? runtime;
  final double? rating;
  final int views;
  final bool featured;
  final String? summary;
  final String? description;
  final List<String> cast;
  final String? director;
  final String? trailerUrl;
  final List<String> screenshots;
  final List<DownloadOption> downloads;
  final ReviewSummary? reviewSummary;
  final List<String> reasons;
  final bool isDetail;

  const Movie({
    required this.id,
    required this.slug,
    required this.title,
    this.url,
    this.posterUrl,
    this.posterFullUrl,
    this.releaseYear,
    this.genres = const [],
    this.language,
    this.country,
    this.quality,
    this.runtime,
    this.rating,
    this.views = 0,
    this.featured = false,
    this.summary,
    this.description,
    this.cast = const [],
    this.director,
    this.trailerUrl,
    this.screenshots = const [],
    this.downloads = const [],
    this.reviewSummary,
    this.reasons = const [],
    this.isDetail = false,
  });

  factory Movie.fromJson(Map<String, dynamic> j) {
    final rs = j['review_summary'];
    return Movie(
      id: _i(j['id']),
      slug: _s(j['slug']) ?? '',
      title: _s(j['title']) ?? '',
      url: _s(j['url']),
      posterUrl: _s(j['poster_url']),
      posterFullUrl: _s(j['poster_full_url']),
      releaseYear: j['release_year'] == null ? null : _i(j['release_year']),
      genres: _list(j['genres'], Genre.fromJson),
      language: _s(j['language']),
      country: _s(j['country']),
      quality: _s(j['quality']),
      runtime: _s(j['runtime']),
      rating: _d(j['rating']),
      views: _i(j['views']),
      featured: j['featured'] == true,
      summary: _s(j['summary']),
      description: _s(j['description']),
      cast: _strings(j['cast']),
      director: _s(j['director']),
      trailerUrl: _s(j['trailer_url']),
      screenshots: _strings(j['screenshots']),
      downloads: _list(j['downloads'], DownloadOption.fromJson),
      reviewSummary: rs is Map ? ReviewSummary(_i(rs['count']), _d(rs['average'])) : null,
      reasons: _strings(j['reasons']),
      isDetail: j.containsKey('downloads') || j.containsKey('description'),
    );
  }
}

class Review {
  final int id;
  final String author;
  final int rating;
  final String body;
  final bool spoiler;
  final int helpful;
  final String createdAt;
  final bool mine;
  final String? status;
  final String? movieTitle;
  final String? movieSlug;
  const Review({required this.id, required this.author, required this.rating, required this.body, this.spoiler = false, this.helpful = 0, this.createdAt = '', this.mine = false, this.status, this.movieTitle, this.movieSlug});
  factory Review.fromJson(Map<String, dynamic> j) {
    final m = j['movie'];
    return Review(
      id: _i(j['id']),
      author: _s(j['author']) ?? '',
      rating: _i(j['rating']),
      body: _s(j['body']) ?? '',
      spoiler: j['is_spoiler'] == true,
      helpful: _i(j['helpful_count']),
      createdAt: _s(j['created_at']) ?? '',
      mine: j['is_mine'] == true,
      status: _s(j['status']),
      movieTitle: m is Map ? _s(m['title']) : null,
      movieSlug: m is Map ? _s(m['slug']) : null,
    );
  }
}

class UserProfile {
  final String id;
  final String email;
  final String displayName;
  const UserProfile({required this.id, required this.email, required this.displayName});
  factory UserProfile.fromJson(Map<String, dynamic> j) => UserProfile(id: _s(j['id']) ?? '', email: _s(j['email']) ?? '', displayName: _s(j['display_name']) ?? '');
}

class Paged<T> {
  final List<T> items;
  final int page;
  final int total;
  final bool hasMore;
  final bool fromCache;
  const Paged({required this.items, this.page = 1, this.total = 0, this.hasMore = false, this.fromCache = false});
}

/// Server-driven settings from GET /config. Everything is validated; unknown/malformed values fall back to safe defaults.
class RemoteConfig {
  final String siteName;
  final bool maintenance;
  final bool registration;
  final bool reviews;
  final bool recommendations;
  final bool passwordReset;
  final bool searchSuggest;
  final String minAppVersion;
  final int maxPerPage;

  const RemoteConfig({
    this.siteName = 'PrimeMovie',
    this.maintenance = false,
    this.registration = true,
    this.reviews = true,
    this.recommendations = true,
    this.passwordReset = true,
    this.searchSuggest = true,
    this.minAppVersion = '1.0.0',
    this.maxPerPage = 50,
  });

  static const defaults = RemoteConfig();

  factory RemoteConfig.fromJson(dynamic raw) {
    if (raw is! Map) return defaults;
    final f = raw['features'] is Map ? raw['features'] as Map : const {};
    final api = raw['api'] is Map ? raw['api'] as Map : const {};
    final lim = raw['limits'] is Map ? raw['limits'] as Map : const {};
    bool b(String k, bool d) => f[k] is bool ? f[k] as bool : d;
    final ver = api['min_supported_app_version']?.toString() ?? '';
    final per = lim['max_per_page'];
    return RemoteConfig(
      siteName: (raw['site_name'] is String && (raw['site_name'] as String).trim().isNotEmpty) ? (raw['site_name'] as String).trim() : 'PrimeMovie',
      maintenance: raw['maintenance'] == true,
      registration: b('registration', true),
      reviews: b('reviews', true),
      recommendations: b('recommendations', true),
      passwordReset: b('password_reset', true),
      searchSuggest: b('search_suggest', true),
      minAppVersion: RegExp(r'^\d{1,3}(\.\d{1,3}){0,2}$').hasMatch(ver) ? ver : '1.0.0',
      maxPerPage: per is int && per >= 1 && per <= 100 ? per : 50,
    );
  }

  /// True when [current] is older than the server's minimum supported app version.
  bool requiresUpdate(String current) {
    List<int> p(String v) => v.split('.').map((e) => int.tryParse(e) ?? 0).toList()..addAll([0, 0, 0]);
    final a = p(current), m = p(minAppVersion);
    for (var i = 0; i < 3; i++) {
      if (a[i] != m[i]) return a[i] < m[i];
    }
    return false;
  }
}


class AppAudio {
  final int id;
  final String label;
  final String? language, codec;
  final int? trackIndex; // 1-based position among the audio tracks inside the media file (null for external audio)
  final bool isDefault;
  final String origin; // detected (read from the file) | manual (typed by an admin)
  final String? url; // signed URL for an external audio file
  const AppAudio({required this.id, required this.label, this.language, this.codec, this.trackIndex, this.isDefault = false, this.origin = 'manual', this.url});
  factory AppAudio.fromJson(Map<String, dynamic> j) => AppAudio(
      id: _i(j['id']), label: _s(j['label']) ?? 'Audio', language: _s(j['language']), codec: _s(j['codec']), trackIndex: j['track_index'] == null ? null : _i(j['track_index']),
      isDefault: j['default'] == true, origin: _s(j['origin']) ?? 'manual', url: _s(j['url']));
}

class AppSubtitle {
  final int id;
  final String label;
  final String? language;
  final String format;
  final String? url; // null for subtitles that live inside the media file
  final int? embeddedIndex; // 1-based among the file's subtitle tracks
  final String origin;
  const AppSubtitle({required this.id, required this.label, this.language, required this.format, this.url, this.embeddedIndex, this.origin = 'manual'});
  factory AppSubtitle.fromJson(Map<String, dynamic> j) => AppSubtitle(
      id: _i(j['id']), label: _s(j['label']) ?? 'Subtitles', language: _s(j['language']), format: _s(j['format']) ?? 'vtt', url: _s(j['url']),
      embeddedIndex: j['embedded_index'] == null ? null : _i(j['embedded_index']), origin: _s(j['origin']) ?? 'manual');
}

/// One Android-app version of a movie (separate from the website's download links). URLs are signed and expire.
class AppMediaSource {
  final int id;
  final String? label;
  final String quality, format, protocol;
  final String? mimeType, unavailableReason, offlineReason, verifyMessage;
  final int? fileSize, width, height, durationSeconds;
  final bool streamEnabled, downloadEnabled, requiresLogin, locked;
  final String status; // active | unavailable
  final String verifyStatus; // verified | unverified | failed
  final String? streamUrl, downloadUrl;
  final List<AppAudio> audio;
  final List<AppSubtitle> subtitles;
  const AppMediaSource({
    required this.id,
    this.label,
    required this.quality,
    required this.format,
    this.protocol = 'file',
    this.mimeType,
    this.fileSize,
    this.width,
    this.height,
    this.durationSeconds,
    this.streamEnabled = false,
    this.downloadEnabled = false,
    this.requiresLogin = true,
    this.locked = false,
    this.status = 'active',
    this.verifyStatus = 'unverified',
    this.verifyMessage,
    this.unavailableReason,
    this.offlineReason,
    this.streamUrl,
    this.downloadUrl,
    this.audio = const [],
    this.subtitles = const [],
  });

  bool get available => status == 'active' && !locked;
  bool get canStream => available && streamEnabled && streamUrl != null;
  bool get canDownload => available && downloadEnabled && downloadUrl != null && protocol == 'file' && format != 'hls' && format != 'dash';
  bool get verified => verifyStatus == 'verified';

  factory AppMediaSource.fromJson(Map<String, dynamic> j) {
    final res = j['resolution'] is Map ? j['resolution'] as Map : const {};
    final ver = j['verification'] is Map ? j['verification'] as Map : const {};
    final cap = j['capabilities'] is Map ? j['capabilities'] as Map : const {};
    return AppMediaSource(
      id: _i(j['id']),
      label: _s(j['label']),
      quality: _s(j['quality']) ?? '',
      format: _s(j['format']) ?? 'mp4',
      protocol: _s(j['protocol']) ?? 'file',
      mimeType: _s(j['mime_type']),
      fileSize: j['file_size'] == null ? null : _i(j['file_size']),
      width: res['width'] == null ? null : _i(res['width']),
      height: res['height'] == null ? null : _i(res['height']),
      durationSeconds: j['duration_seconds'] == null ? null : _i(j['duration_seconds']),
      streamEnabled: j['stream_enabled'] == true,
      downloadEnabled: j['download_enabled'] == true,
      requiresLogin: j['requires_login'] != false,
      locked: j['locked'] == true,
      status: _s(j['status']) ?? 'unavailable',
      verifyStatus: _s(ver['status']) ?? 'unverified',
      verifyMessage: _s(ver['message']),
      unavailableReason: _s(j['unavailable_reason']),
      offlineReason: _s(cap['offline_unavailable_reason']),
      streamUrl: _s(j['stream_url']),
      downloadUrl: _s(j['download_url']),
      audio: _list(j['audio'], AppAudio.fromJson),
      subtitles: _list(j['subtitles'], AppSubtitle.fromJson),
    );
  }
}

String formatBytes(int? b) {
  if (b == null || b <= 0) return '';
  const u = ['B', 'KB', 'MB', 'GB', 'TB'];
  var v = b.toDouble();
  var i = 0;
  while (v >= 1024 && i < u.length - 1) {
    v /= 1024;
    i++;
  }
  return '${v.toStringAsFixed(v >= 100 || i == 0 ? 0 : 1)} ${u[i]}';
}
