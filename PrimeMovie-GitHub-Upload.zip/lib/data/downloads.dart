import 'dart:convert';
import 'dart:io';
import 'package:background_downloader/background_downloader.dart' hide Database;
import 'package:dio/dio.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:path/path.dart' as p;
import 'package:sqflite/sqflite.dart';
import '../providers.dart';
import 'models.dart';
import 'player_args.dart';
import 'settings.dart';
import 'storage_info.dart';

enum DlStatus { queued, downloading, paused, completed, failed }

class DownloadItem {
  final String id; // dl_app_<app media source id>
  final int movieId, sourceId;
  final String slug, title, quality, url;
  final String? posterUrl, sizeLabel, path, error, meta;
  final int? totalBytes;
  final DlStatus status;
  final double progress;
  final int createdAt;

  const DownloadItem({
    required this.id,
    required this.movieId,
    required this.sourceId,
    required this.slug,
    required this.title,
    required this.quality,
    required this.url,
    this.posterUrl,
    this.sizeLabel,
    this.path,
    this.error,
    this.meta,
    this.totalBytes,
    this.status = DlStatus.queued,
    this.progress = 0,
    required this.createdAt,
  });

  DownloadItem copyWith({DlStatus? status, double? progress, String? path, String? error, String? url, String? meta, bool clearError = false}) => DownloadItem(
        id: id, movieId: movieId, sourceId: sourceId, slug: slug, title: title, quality: quality, posterUrl: posterUrl, sizeLabel: sizeLabel, totalBytes: totalBytes, createdAt: createdAt,
        url: url ?? this.url, meta: meta ?? this.meta,
        status: status ?? this.status, progress: progress ?? this.progress, path: path ?? this.path, error: clearError ? null : (error ?? this.error),
      );

  Map<String, Object?> toMap() => {'id': id, 'movie_id': movieId, 'source_id': sourceId, 'slug': slug, 'title': title, 'quality': quality, 'url': url, 'poster': posterUrl, 'size': sizeLabel, 'total': totalBytes, 'meta': meta, 'path': path, 'error': error, 'status': status.name, 'progress': progress, 'created': createdAt};

  factory DownloadItem.fromMap(Map<String, Object?> m) => DownloadItem(
        id: m['id'] as String, movieId: m['movie_id'] as int, sourceId: (m['source_id'] as int?) ?? 0, slug: m['slug'] as String, title: m['title'] as String, quality: m['quality'] as String, url: m['url'] as String,
        posterUrl: m['poster'] as String?, sizeLabel: m['size'] as String?, totalBytes: m['total'] as int?, meta: m['meta'] as String?, path: m['path'] as String?, error: m['error'] as String?,
        status: DlStatus.values.firstWhere((s) => s.name == m['status'], orElse: () => DlStatus.failed), progress: (m['progress'] as num?)?.toDouble() ?? 0, createdAt: m['created'] as int,
      );

  bool get active => status == DlStatus.queued || status == DlStatus.downloading || status == DlStatus.paused;

  /// "420 MB of 1.8 GB" when the total is known.
  String get sizeProgress {
    if (totalBytes == null || totalBytes! <= 0) return sizeLabel ?? '';
    return '${formatBytes((totalBytes! * progress).round())} of ${formatBytes(totalBytes)}';
  }

  Map<String, dynamic> get _metaMap {
    try {
      final d = jsonDecode(meta ?? '{}');
      return d is Map<String, dynamic> ? d : <String, dynamic>{};
    } catch (_) {
      return <String, dynamic>{};
    }
  }

  /// Player arguments for offline playback: the local file plus the subtitle files saved with it.
  PlayerArgs? toPlayerArgs() {
    if (path == null) return null;
    final m = _metaMap;
    return PlayerArgs(
      title: title,
      movieId: movieId,
      sourceId: sourceId,
      localPath: path,
      audio: [for (final a in (m['audio'] as List? ?? const [])) PlayerAudio(label: '${a['label']}', language: a['language'] as String?, trackIndex: a['track_index'] as int?)],
      subtitles: [
        for (final s in (m['subs'] as List? ?? const []))
          if (s['embedded'] is int) PlayerSubtitle(label: '${s['label']}', language: s['language'] as String?, embeddedIndex: s['embedded'] as int)
          else if (s['local'] is String && File(s['local'] as String).existsSync()) PlayerSubtitle(label: '${s['label']}', language: s['language'] as String?, uri: s['local'] as String)
      ],
    );
  }
}

class DownloadStore {
  Database? _db;
  Future<Database> _open() async => _db ??= await openDatabase(
        p.join(await getDatabasesPath(), 'primemovie_downloads.db'),
        version: 2,
        onCreate: (db, v) => db.execute('CREATE TABLE downloads (id TEXT PRIMARY KEY, movie_id INTEGER, source_id INTEGER, slug TEXT, title TEXT, quality TEXT, url TEXT, poster TEXT, size TEXT, total INTEGER, meta TEXT, path TEXT, error TEXT, status TEXT, progress REAL, created INTEGER)'),
        onUpgrade: (db, from, to) async {
          if (from < 2) {
            await db.execute('ALTER TABLE downloads ADD COLUMN source_id INTEGER');
            await db.execute('ALTER TABLE downloads ADD COLUMN total INTEGER');
            await db.execute('ALTER TABLE downloads ADD COLUMN meta TEXT');
          }
        },
      );

  Future<List<DownloadItem>> all() async => (await (await _open()).query('downloads', orderBy: 'created DESC')).map(DownloadItem.fromMap).toList();
  Future<void> save(DownloadItem d) async => (await _open()).insert('downloads', d.toMap(), conflictAlgorithm: ConflictAlgorithm.replace);
  Future<void> remove(String id) async => (await _open()).delete('downloads', where: 'id = ?', whereArgs: [id]);
}

/// Optional: also copy finished downloads into Movies/PrimeMovie so Gallery/MX Player can see them. OFF by default,
/// because app-private storage is what protects the downloaded content.
class SaveToGalleryNotifier extends AsyncNotifier<bool> {
  static const _key = 'setting:save_to_gallery';
  @override
  Future<bool> build() async => (await ref.read(cacheProvider).get(_key))?.json == '1';

  Future<void> set(bool v) async {
    await ref.read(cacheProvider).put(_key, v ? '1' : '0');
    state = AsyncData(v);
  }
}

final saveToGalleryProvider = AsyncNotifierProvider<SaveToGalleryNotifier, bool>(SaveToGalleryNotifier.new);

/// In-app downloads of the app's authorised media (never the website's external links).
/// background_downloader runs the transfer natively: notification with progress, pause/resume, continues in the background.
/// Files go to app-private storage; moving them to public storage happens only if the user turns that setting on.
class DownloadsNotifier extends Notifier<List<DownloadItem>> {
  final _store = DownloadStore();
  final _tasks = <String, DownloadTask>{};
  static const folder = 'PrimeMovie';

  @override
  List<DownloadItem> build() {
    _init();
    return const [];
  }

  Future<void> _init() async {
    final d = FileDownloader();
    d.configureNotificationForGroup(FileDownloader.defaultGroup,
        running: const TaskNotification('Downloading {displayName}', '{progress}'),
        complete: const TaskNotification('Download complete', '{displayName}'),
        error: const TaskNotification('Download failed', '{displayName}'),
        paused: const TaskNotification('Paused', '{displayName}'),
        progressBar: true);
    d.registerCallbacks(taskStatusCallback: _onStatus, taskProgressCallback: _onProgress);
    var items = await _store.all();
    items = [
      for (final i in items)
        (i.status == DlStatus.completed && (i.path == null || !File(i.path!).existsSync())) ? i.copyWith(status: DlStatus.failed, error: 'The file was removed from your device.') : i
    ];
    state = items;
    await d.resumeFromBackground();
  }

  Future<bool> requestNotifications() async {
    final perms = FileDownloader().permissions;
    final st = await perms.status(PermissionType.notifications);
    if (st == PermissionStatus.granted) return true;
    return await perms.request(PermissionType.notifications) == PermissionStatus.granted;
  }

  DownloadItem? bySource(int sourceId) {
    for (final i in state) {
      if (i.id == 'dl_app_$sourceId') return i;
    }
    return null;
  }

  static String _safeName(String s) => s.replaceAll(RegExp(r'[^A-Za-z0-9 ._()-]'), '_').trim();

  /// Resolved when a download starts (settings: storage location and Wi-Fi only). Kept per task so pause/resume stays consistent.
  final _targets = <String, ({String? sdPath, bool wifi})>{};

  DownloadTask _task(DownloadItem i) {
    final t = _targets[i.id] ?? (sdPath: null, wifi: false);
    return _tasks.putIfAbsent(
        i.id,
        () => DownloadTask(
              taskId: i.id,
              url: i.url, // signed, expiring link to the app's authorised source
              filename: '${_safeName('${i.title} ${i.quality}')}.part',
              directory: t.sdPath ?? folder, // absolute SD-card app folder, or a sub-folder of the private app storage
              baseDirectory: t.sdPath != null ? BaseDirectory.root : BaseDirectory.applicationSupport,
              updates: Updates.statusAndProgress,
              allowPause: true,
              retries: 2,
              requiresWiFi: t.wifi,
              displayName: i.title,
            ));
  }

  /// Reads the user's settings for a new download. Returns an error message when the chosen location is not usable.
  Future<String?> _prepareTarget(String id) async {
    final s = ref.read(settingsProvider).valueOrNull ?? const AppSettings();
    String? sd;
    if (s.downloadLocation == 'sd') {
      final vols = await detectVolumes();
      sd = vols.where((v) => v.id == 'sd').firstOrNull?.basePath;
      if (sd == null) return 'The SD card is not available. Insert it or choose Phone storage in Settings.';
    }
    _targets[id] = (sdPath: sd, wifi: s.wifiOnly);
    return null;
  }

  /// Returns an error message to show the user, or null when the download was queued.
  Future<String?> start(Movie m, AppMediaSource s) async {
    final existing = bySource(s.id);
    if (existing != null && (existing.active || existing.status == DlStatus.completed)) return null;
    if (!s.canDownload) return 'This version cannot be downloaded.';
    final problem = await _prepareTarget('dl_app_${s.id}');
    if (problem != null) return problem;
    if (_targets['dl_app_${s.id}']?.sdPath == null && s.fileSize != null) {
      final free = await freeSpaceBytes(); // null when the device does not report it: then the download simply tries
      final need = (s.fileSize! * 1.05).round() + 200 * 1024 * 1024;
      if (free != null && free < need) return 'Not enough free space. This download needs about ${formatBytes(need)} and your phone has ${formatBytes(free)} free.';
    }
    await requestNotifications(); // downloading still works if declined; only the notification is skipped
    final meta = jsonEncode({
      'format': s.format,
      'audio': [for (final a in s.audio) if (a.url == null) {'label': a.label, 'language': a.language, 'track_index': a.trackIndex}],
      'subs': [for (final x in s.subtitles) x.url != null ? {'label': x.label, 'language': x.language, 'format': x.format, 'url': x.url} : {'label': x.label, 'language': x.language, 'embedded': x.embeddedIndex}],
    });
    final item = DownloadItem(id: 'dl_app_${s.id}', movieId: m.id, sourceId: s.id, slug: m.slug, title: m.title, quality: s.quality, url: s.downloadUrl!, posterUrl: m.posterUrl, sizeLabel: formatBytes(s.fileSize), totalBytes: s.fileSize, meta: meta, createdAt: DateTime.now().millisecondsSinceEpoch);
    _tasks.remove(item.id);
    await _put(item);
    if (!await FileDownloader().enqueue(_task(item))) await _put(item.copyWith(status: DlStatus.failed, error: 'Could not start the download.'));
    return null;
  }

  Future<void> _put(DownloadItem i) async {
    await _store.save(i);
    state = [i, ...state.where((x) => x.id != i.id)]..sort((a, b) => b.createdAt.compareTo(a.createdAt));
  }

  void _patch(String id, DownloadItem Function(DownloadItem) f, {bool persist = true}) {
    final i = state.where((x) => x.id == id).firstOrNull;
    if (i == null) return;
    final n = f(i);
    state = [for (final x in state) x.id == id ? n : x];
    if (persist) _store.save(n);
  }

  void _onProgress(TaskProgressUpdate u) {
    if (u.progress < 0 || u.progress > 1) return;
    _patch(u.task.taskId, (i) => i.copyWith(progress: u.progress, status: DlStatus.downloading), persist: false);
  }

  Future<void> _onStatus(TaskStatusUpdate u) async {
    final id = u.task.taskId;
    switch (u.status) {
      case TaskStatus.enqueued:
      case TaskStatus.waitingToRetry:
        _patch(id, (i) => i.copyWith(status: DlStatus.queued, clearError: true));
      case TaskStatus.running:
        _patch(id, (i) => i.copyWith(status: DlStatus.downloading, clearError: true));
      case TaskStatus.paused:
        _patch(id, (i) => i.copyWith(status: DlStatus.paused));
      case TaskStatus.complete:
        await _finish(id, u.task as DownloadTask);
      case TaskStatus.notFound:
        _patch(id, (i) => i.copyWith(status: DlStatus.failed, error: 'This download is no longer available. Tap retry to request a new link.'));
      case TaskStatus.failed:
        _patch(id, (i) => i.copyWith(status: DlStatus.failed, error: 'Download interrupted. Check your connection and free storage, then tap retry.'));
      case TaskStatus.canceled:
        break;
    }
  }

  Future<void> _finish(String id, DownloadTask task) async {
    var path = await task.filePath();
    final file = File(path);
    final item = state.where((x) => x.id == id).firstOrNull;
    final sniffed = await _sniffExtension(file);
    if (sniffed == null) {
      try { await file.delete(); } catch (_) {}
      _patch(id, (i) => i.copyWith(status: DlStatus.failed, error: 'The server did not return a video file. Please try again later.'));
      return;
    }
    final fmt = (item?._metaMap['format'] as String?) ?? '';
    final ext = const {'mp4': '.mp4', 'mkv': '.mkv', 'webm': '.webm'}[fmt] ?? sniffed;
    final renamed = p.setExtension(path, ext);
    try {
      await file.rename(renamed);
      path = renamed;
    } catch (_) {}

    var meta = item?.meta;
    if (item != null) meta = await _saveSubtitles(item, path);

    if (ref.read(saveToGalleryProvider).valueOrNull == true) {
      try {
        final shared = await FileDownloader().moveFileToSharedStorage(path, SharedStorage.video, directory: folder);
        if (shared != null) path = shared;
      } catch (_) {/* stays private */}
    }
    _patch(id, (i) => i.copyWith(status: DlStatus.completed, progress: 1, path: path, meta: meta, clearError: true));
  }

  /// Subtitle files are small: fetch them now so subtitles also work offline. Failures just skip that subtitle.
  Future<String?> _saveSubtitles(DownloadItem item, String moviePath) async {
    final m = item._metaMap;
    final subs = (m['subs'] as List?) ?? const [];
    if (subs.isEmpty) return item.meta;
    final dio = Dio(BaseOptions(connectTimeout: const Duration(seconds: 10), receiveTimeout: const Duration(seconds: 20), responseType: ResponseType.bytes, validateStatus: (s) => s != null && s < 400));
    final out = <Map<String, dynamic>>[];
    for (var n = 0; n < subs.length; n++) {
      final s = Map<String, dynamic>.from(subs[n] as Map);
      if (s['url'] is! String) { out.add(s); continue; } // embedded subtitle: nothing to fetch
      try {
        final r = await dio.get<List<int>>(s['url'] as String);
        final f = File(p.join(p.dirname(moviePath), '${item.id}_sub_$n.${(s['format'] as String?) ?? 'vtt'}'));
        await f.writeAsBytes(r.data ?? const []);
        s['local'] = f.path;
      } catch (_) {/* skip */}
      s.remove('url'); // expired signed URL is useless later
      out.add(s);
    }
    m['subs'] = out;
    return jsonEncode(m);
  }

  static Future<String?> _sniffExtension(File f) async {
    try {
      final len = await f.length();
      final raf = await f.open();
      final head = await raf.read(16);
      await raf.close();
      if (head.length >= 4 && head[0] == 0x1A && head[1] == 0x45 && head[2] == 0xDF && head[3] == 0xA3) return '.mkv';
      if (head.length >= 8 && utf8.decode(head.sublist(4, 8), allowMalformed: true) == 'ftyp') return '.mp4';
      final text = utf8.decode(head, allowMalformed: true).trimLeft().toLowerCase();
      if (text.startsWith('<') || text.startsWith('{')) return null; // an error page, not a video
      return len > 5 * 1024 * 1024 ? '.mp4' : null;
    } catch (_) {
      return null;
    }
  }

  Future<void> pause(String id) async {
    final i = state.where((x) => x.id == id).firstOrNull;
    if (i != null) await FileDownloader().pause(_task(i));
  }

  Future<void> resume(String id) async {
    final i = state.where((x) => x.id == id).firstOrNull;
    if (i == null) return;
    if (!await FileDownloader().resume(_task(i))) await retry(id); // link expired or task lost: request a fresh link
  }

  /// Requests a fresh signed link (the old one may have expired) and starts the download again.
  Future<void> retry(String id) async {
    final i = state.where((x) => x.id == id).firstOrNull;
    if (i == null) return;
    String? url;
    try {
      final list = await ref.read(contentRepoProvider).appMedia(i.slug);
      url = list.where((x) => x.id == i.sourceId).firstOrNull?.downloadUrl;
    } catch (_) {}
    if (url == null) {
      _patch(id, (x) => x.copyWith(status: DlStatus.failed, error: 'Could not get a new download link. Check your connection and that you are signed in.'));
      return;
    }
    _tasks.remove(id);
    final problem = await _prepareTarget(id);
    if (problem != null) {
      _patch(id, (x) => x.copyWith(status: DlStatus.failed, error: problem));
      return;
    }
    final fresh = i.copyWith(status: DlStatus.queued, progress: 0, url: url, clearError: true);
    await _put(fresh);
    await FileDownloader().enqueue(_task(fresh));
  }

  /// Cancels (if running) and deletes the movie file, its subtitle files and the record.
  Future<void> remove(String id) async {
    final i = state.where((x) => x.id == id).firstOrNull;
    if (i == null) return;
    await FileDownloader().cancelTaskWithId(id);
    final files = <String>[if (i.path != null) i.path!, for (final s in (i._metaMap['subs'] as List? ?? const [])) if (s['local'] is String) s['local'] as String];
    for (final f in files) {
      try { await File(f).delete(); } catch (_) {}
    }
    _tasks.remove(id);
    await _store.remove(id);
    state = state.where((x) => x.id != id).toList();
  }

  Future<bool> openExternally(String id) async {
    final i = state.where((x) => x.id == id).firstOrNull;
    if (i?.path == null) return false;
    return FileDownloader().openFile(filePath: i!.path!);
  }
}

final downloadsProvider = NotifierProvider<DownloadsNotifier, List<DownloadItem>>(DownloadsNotifier.new);
