import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:media_kit/media_kit.dart';
import 'core/theme.dart';
import 'data/settings.dart';
import 'providers.dart';
import 'router.dart';
import 'widgets/common.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  MediaKit.ensureInitialized();
  SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
  runApp(const ProviderScope(child: PrimeMovieApp()));
}

class PrimeMovieApp extends ConsumerStatefulWidget {
  const PrimeMovieApp({super.key});
  @override
  ConsumerState<PrimeMovieApp> createState() => _AppState();
}

class _AppState extends ConsumerState<PrimeMovieApp> with WidgetsBindingObserver {
  DateTime _paused = DateTime.now();

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  /// Returning to the app after 5+ minutes refetches server-controlled content and settings.
  @override
  void didChangeAppLifecycleState(AppLifecycleState s) {
    if (s == AppLifecycleState.paused) _paused = DateTime.now();
    if (s == AppLifecycleState.resumed && DateTime.now().difference(_paused) > const Duration(minutes: 5)) {
      ref.read(contentRepoProvider).invalidateContent();
      ref.invalidate(configProvider);
      ref.invalidate(categoriesProvider);
      for (final k in const ['featured', 'trending', 'popular', 'latest']) {
        ref.invalidate(collectionProvider(k));
      }
      ref.invalidate(recommendationsProvider);
    }
  }

  @override
  Widget build(BuildContext context) {
    final cfg = ref.watch(configProvider).valueOrNull;
    return MaterialApp.router(
      title: 'PrimeMovie',
      debugShowCheckedModeBanner: false,
      theme: Pm.light(),
      darkTheme: Pm.dark(),
      themeMode: ref.watch(settingsProvider).valueOrNull?.themeMode ?? ThemeMode.dark,
      routerConfig: ref.watch(routerProvider),
      builder: (context, child) {
        if (cfg != null && cfg.maintenance) {
          return const Scaffold(body: EmptyView(icon: Icons.build_circle_outlined, title: "We'll be right back", message: 'PrimeMovie is under maintenance. Please try again shortly.'));
        }
        final dark = Theme.of(context).brightness == Brightness.dark;
        return AnnotatedRegion<SystemUiOverlayStyle>(
          value: SystemUiOverlayStyle(
            statusBarColor: Colors.transparent,
            statusBarIconBrightness: dark ? Brightness.light : Brightness.dark,
            systemNavigationBarColor: context.pm.surface,
            systemNavigationBarIconBrightness: dark ? Brightness.light : Brightness.dark,
          ),
          child: child ?? const SizedBox.shrink(),
        );
      },
    );
  }
}
